from __future__ import annotations

import torch


def choose_device(requested: str = "auto") -> torch.device:
    requested = requested.lower()
    if requested == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if requested == "cuda" and not torch.cuda.is_available():
        raise RuntimeError(
            "CUDA was explicitly requested but torch.cuda.is_available() is False. "
            "Run scripts/check_cuda.py with the project interpreter."
        )
    return torch.device(requested)


def choose_batch_size(requested: int | str, device: torch.device) -> int:
    if requested != "auto":
        value = int(requested)
        if value <= 0:
            raise ValueError(f"batch_size must be positive, got {requested!r}")
        return value
    if device.type != "cuda":
        return 32
    memory_gib = torch.cuda.get_device_properties(device).total_memory / 1024**3
    if memory_gib < 6:
        return 16
    if memory_gib < 10:
        return 32
    return 64

