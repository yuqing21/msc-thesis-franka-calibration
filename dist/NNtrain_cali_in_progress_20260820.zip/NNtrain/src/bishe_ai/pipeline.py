from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path
from typing import Any

import numpy as np
import torch
import yaml
from torch.utils.data import DataLoader

from bishe_ai.config import resolve_project_path
from bishe_ai.data.datasets import (
    MultimodalWindowDataset,
    arrays_from_npz,
    make_synthetic_arrays,
)
from bishe_ai.evaluation.plots import save_prediction_plot, save_training_plot
from bishe_ai.evaluation.joint_fk import TorchJoint8FK, endpoint_metrics
from bishe_ai.models import build_model
from bishe_ai.training import evaluate, fit
from bishe_ai.utils import choose_batch_size, choose_device, seed_everything


def _datasets(
    config: dict[str, Any],
) -> tuple[
    dict[str, MultimodalWindowDataset],
    dict[str, int],
    dict[str, np.ndarray | None],
]:
    data_config = config["data"]
    kind = str(data_config["kind"]).lower()
    arrays: dict[str, np.ndarray] = {}
    if kind == "synthetic":
        dimensions = {
            "time_steps": int(data_config["window_steps"]),
            "semg_channels": int(data_config["semg_channels"]),
            "imu_channels": int(data_config["imu_channels"]),
            "output_dim": int(data_config["output_dim"]),
        }
        split_sizes = {
            split: int(data_config[f"{split}_samples"])
            for split in ("train", "val", "test")
        }
        semg, imu, target = make_synthetic_arrays(
            samples=sum(split_sizes.values()),
            seed=int(config["run"]["seed"]),
            **dimensions,
        )
        start = 0
        for split, size in split_sizes.items():
            stop = start + size
            arrays[f"semg_{split}"] = semg[start:stop]
            arrays[f"imu_{split}"] = imu[start:stop]
            arrays[f"target_{split}"] = target[start:stop]
            start = stop
    elif kind == "prepared_npz":
        path = resolve_project_path(data_config["path"])
        if not path.is_file():
            raise FileNotFoundError(
                f"Prepared dataset not found: {path}. Run the preparation step for the configured dataset first."
            )
        arrays = arrays_from_npz(str(path))
    else:
        raise ValueError(f"Unknown data.kind {kind!r}; choose synthetic or prepared_npz")

    datasets = {
        split: MultimodalWindowDataset(
            arrays[f"semg_{split}"],
            arrays[f"imu_{split}"],
            arrays[f"target_{split}"],
            xyz=arrays.get(f"xyz_{split}"),
            subject_index=arrays.get(f"subject_index_{split}"),
        )
        for split in ("train", "val", "test")
    }
    train = datasets["train"]
    inferred = {
        "semg_channels": int(train.semg.shape[-1]),
        "imu_channels": int(train.imu.shape[-1]),
        "output_dim": int(train.targets.shape[-1]),
    }
    for key, actual in inferred.items():
        configured = data_config.get(key)
        if configured is not None and int(configured) != actual:
            raise ValueError(f"Configured {key}={configured}, but prepared data contains {actual}")
        data_config[key] = actual
    preprocessing = {
        name: arrays.get(name)
        for name in (
            "semg_mean",
            "semg_scale",
            "imu_mean",
            "imu_scale",
            "target_mean",
            "target_scale",
            "xyz_mean",
            "xyz_scale",
        )
    }
    preprocessing.update({key: value for key, value in arrays.items() if key.startswith("fk_")})
    return datasets, inferred, preprocessing


def _joint_fk_metrics(
    dataset: MultimodalWindowDataset,
    target_deg: np.ndarray,
    prediction_deg: np.ndarray,
    preprocessing: dict[str, np.ndarray | None],
) -> dict[str, object]:
    if dataset.xyz is None or dataset.subject_index is None:
        return {}
    if preprocessing.get("xyz_mean") is None or preprocessing.get("xyz_scale") is None:
        raise ValueError("Joint FK evaluation requires XYZ normalization arrays")
    fk = TorchJoint8FK(
        {key: value for key, value in preprocessing.items() if key.startswith("fk_")}
    )
    with torch.inference_mode():
        subject_index = dataset.subject_index
        oracle = fk(torch.from_numpy(target_deg.astype(np.float32)), subject_index).numpy()
        prediction = fk(torch.from_numpy(prediction_deg.astype(np.float32)), subject_index).numpy()
    xyz = dataset.xyz.numpy() * preprocessing["xyz_scale"] + preprocessing["xyz_mean"]
    return {
        "fk_oracle_vs_vicon": endpoint_metrics(xyz, oracle),
        "fk_prediction_vs_vicon": endpoint_metrics(xyz, prediction),
    }


def _loaders(
    datasets: dict[str, MultimodalWindowDataset],
    batch_size: int,
    workers: int,
    device: torch.device,
) -> dict[str, DataLoader]:
    common = {
        "batch_size": batch_size,
        "num_workers": workers,
        "pin_memory": device.type == "cuda",
    }
    return {
        "train": DataLoader(datasets["train"], shuffle=True, **common),
        "val": DataLoader(datasets["val"], shuffle=False, **common),
        "test": DataLoader(datasets["test"], shuffle=False, **common),
    }


def _json_ready(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {str(key): _json_ready(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_ready(item) for item in value]
    if isinstance(value, np.generic):
        return value.item()
    return value


def run_training(config: dict[str, Any]) -> dict[str, Any]:
    config = deepcopy(config)
    seed = int(config["run"].get("seed", 42))
    seed_everything(seed)
    device = choose_device(str(config["training"].get("device", "auto")))
    batch_size = choose_batch_size(config["training"].get("batch_size", "auto"), device)
    datasets, dimensions, preprocessing = _datasets(config)
    loaders = _loaders(
        datasets,
        batch_size,
        int(config["data"].get("num_workers", 0)),
        device,
    )
    model = build_model(config["model"], **dimensions).to(device)
    first_parameter = next(model.parameters())
    first_batch = next(iter(loaders["train"]))
    batch_on_device = {key: value.to(device) for key, value in first_batch.items()}
    print(f"torch={torch.__version__} cuda_runtime={torch.version.cuda}")
    print(f"device={device} model_parameter_device={first_parameter.device}")
    print(
        "batch_devices="
        + ", ".join(f"{key}:{value.device}" for key, value in batch_on_device.items())
    )
    with torch.no_grad():
        smoke_output = model(batch_on_device)
    print(f"forward_output_shape={tuple(smoke_output.shape)}")

    output_root = resolve_project_path(config["run"].get("output_root", "outputs"))
    run_name = str(config["run"].get("name", "run"))
    model_name = str(config["model"].get("type", "dual_branch"))
    stem = f"{run_name}_{model_name}"
    paths = {
        "checkpoint": output_root / "checkpoints" / f"{stem}_best.pt",
        "history": output_root / "metrics" / f"{stem}_history.json",
        "metrics": output_root / "metrics" / f"{stem}_test.json",
        "training_figure": output_root / "figures" / f"{stem}_training.png",
        "prediction_figure": output_root / "figures" / f"{stem}_prediction.png",
        "config": output_root / "logs" / f"{stem}_config.yaml",
    }
    for path in paths.values():
        path.parent.mkdir(parents=True, exist_ok=True)
    config["resolved"] = {
        "device": str(device),
        "batch_size": batch_size,
        "dimensions": dimensions,
    }
    with paths["config"].open("w", encoding="utf-8") as handle:
        yaml.safe_dump(_json_ready(config), handle, allow_unicode=True, sort_keys=False)

    history, training_seconds = fit(
        model,
        loaders["train"],
        loaders["val"],
        config["training"],
        device,
        paths["checkpoint"],
        config,
        preprocessing,
    )
    metrics, target, prediction = evaluate(
        model,
        loaders["test"],
        device,
        target_mean=preprocessing["target_mean"],
        target_scale=preprocessing["target_scale"],
    )
    metrics.update(_joint_fk_metrics(datasets["test"], target, prediction, preprocessing))
    metrics.update(
        {
            "training_seconds": training_seconds,
            "device": str(device),
            "batch_size": batch_size,
            "model_type": model_name,
            "checkpoint": str(paths["checkpoint"]),
        }
    )
    with paths["history"].open("w", encoding="utf-8") as handle:
        json.dump(_json_ready(history), handle, indent=2, ensure_ascii=False)
    with paths["metrics"].open("w", encoding="utf-8") as handle:
        json.dump(_json_ready(metrics), handle, indent=2, ensure_ascii=False)
    save_training_plot(history, paths["training_figure"])
    save_prediction_plot(target, prediction, paths["prediction_figure"])
    print(json.dumps(_json_ready(metrics), indent=2, ensure_ascii=False))
    return {"metrics": metrics, "paths": paths, "history": history}


def evaluate_checkpoint(checkpoint_path: str | Path) -> dict[str, object]:
    path = resolve_project_path(checkpoint_path)
    if not path.is_file():
        raise FileNotFoundError(f"Checkpoint not found: {path}")
    payload = torch.load(path, map_location="cpu", weights_only=False)
    config = deepcopy(payload["config"])
    device = choose_device(str(config["training"].get("device", "auto")))
    datasets, dimensions, preprocessing = _datasets(config)
    batch_size = choose_batch_size(config["training"].get("batch_size", "auto"), device)
    loaders = _loaders(
        datasets,
        batch_size,
        int(config["data"].get("num_workers", 0)),
        device,
    )
    model = build_model(config["model"], **dimensions).to(device)
    model.load_state_dict(payload["model_state"])
    metrics, target, prediction = evaluate(
        model,
        loaders["test"],
        device,
        target_mean=preprocessing["target_mean"],
        target_scale=preprocessing["target_scale"],
    )
    metrics.update(_joint_fk_metrics(datasets["test"], target, prediction, preprocessing))
    return metrics
