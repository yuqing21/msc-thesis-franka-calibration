from __future__ import annotations

from collections.abc import Mapping

import torch
from torch import nn


class TemporalEncoder(nn.Module):
    def __init__(
        self,
        input_channels: int,
        conv_channels: int,
        gru_hidden: int,
        feature_dim: int,
        dropout: float,
    ) -> None:
        super().__init__()
        if min(input_channels, conv_channels, gru_hidden, feature_dim) <= 0:
            raise ValueError("Encoder dimensions must all be positive")
        self.convolution = nn.Sequential(
            nn.Conv1d(input_channels, conv_channels, kernel_size=5, padding=2),
            nn.BatchNorm1d(conv_channels),
            nn.ReLU(),
            nn.Conv1d(conv_channels, conv_channels, kernel_size=3, padding=1),
            nn.BatchNorm1d(conv_channels),
            nn.ReLU(),
        )
        self.gru = nn.GRU(
            input_size=conv_channels,
            hidden_size=gru_hidden,
            num_layers=1,
            batch_first=True,
        )
        self.projection = nn.Sequential(
            nn.Linear(gru_hidden, feature_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
        )

    def forward(self, values: torch.Tensor) -> torch.Tensor:
        if values.ndim != 3:
            raise ValueError(f"Expected [batch, time, channels], got {tuple(values.shape)}")
        encoded = self.convolution(values.transpose(1, 2)).transpose(1, 2)
        _, hidden = self.gru(encoded)
        return self.projection(hidden[-1])


class AttentionTemporalEncoder(nn.Module):
    """Encode all time steps and learn which ones matter for the window label."""

    def __init__(
        self,
        input_channels: int,
        conv_channels: int,
        gru_hidden: int,
        feature_dim: int,
        dropout: float,
    ) -> None:
        super().__init__()
        if min(input_channels, conv_channels, gru_hidden, feature_dim) <= 0:
            raise ValueError("Encoder dimensions must all be positive")
        self.convolution = nn.Sequential(
            nn.Conv1d(input_channels, conv_channels, kernel_size=5, padding=2),
            nn.BatchNorm1d(conv_channels),
            nn.ReLU(),
            nn.Conv1d(conv_channels, conv_channels, kernel_size=3, padding=1),
            nn.BatchNorm1d(conv_channels),
            nn.ReLU(),
        )
        self.gru = nn.GRU(
            input_size=conv_channels,
            hidden_size=gru_hidden,
            num_layers=1,
            batch_first=True,
        )
        self.attention = nn.Sequential(
            nn.LayerNorm(gru_hidden),
            nn.Linear(gru_hidden, gru_hidden),
            nn.Tanh(),
            nn.Linear(gru_hidden, 1),
        )
        self.projection = nn.Sequential(
            nn.Linear(gru_hidden, feature_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
        )

    def forward(self, values: torch.Tensor) -> torch.Tensor:
        if values.ndim != 3:
            raise ValueError(f"Expected [batch, time, channels], got {tuple(values.shape)}")
        encoded = self.convolution(values.transpose(1, 2)).transpose(1, 2)
        sequence, _ = self.gru(encoded)
        weights = torch.softmax(self.attention(sequence), dim=1)
        context = torch.sum(weights * sequence, dim=1)
        return self.projection(context)


class RegressionHead(nn.Module):
    def __init__(self, input_dim: int, output_dim: int, dropout: float) -> None:
        super().__init__()
        hidden = max(32, input_dim // 2)
        self.layers = nn.Sequential(
            nn.Linear(input_dim, input_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(input_dim, hidden),
            nn.ReLU(),
            nn.Linear(hidden, output_dim),
        )

    def forward(self, values: torch.Tensor) -> torch.Tensor:
        return self.layers(values)


class AxisSpecificRegressionHead(nn.Module):
    """Use shared fused features followed by one small regression head per XYZ axis."""

    def __init__(self, input_dim: int, output_dim: int, dropout: float) -> None:
        super().__init__()
        if output_dim <= 0:
            raise ValueError("output_dim must be positive")
        shared_dim = max(32, input_dim // 2)
        axis_dim = max(16, shared_dim // 2)
        self.shared = nn.Sequential(
            nn.Linear(input_dim, input_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(input_dim, shared_dim),
            nn.ReLU(),
        )
        self.axis_heads = nn.ModuleList(
            nn.Sequential(
                nn.Linear(shared_dim, axis_dim),
                nn.ReLU(),
                nn.Dropout(dropout),
                nn.Linear(axis_dim, 1),
            )
            for _ in range(output_dim)
        )

    def forward(self, values: torch.Tensor) -> torch.Tensor:
        shared = self.shared(values)
        return torch.cat([head(shared) for head in self.axis_heads], dim=-1)


class SingleModalRegressor(nn.Module):
    def __init__(self, modality: str, encoder: TemporalEncoder, head: RegressionHead) -> None:
        super().__init__()
        self.modality = modality
        self.encoder = encoder
        self.head = head

    def forward(self, batch: Mapping[str, torch.Tensor]) -> torch.Tensor:
        if self.modality not in batch:
            raise KeyError(f"Model requires '{self.modality}' in the input batch")
        return self.head(self.encoder(batch[self.modality]))


class EarlyFusionRegressor(nn.Module):
    def __init__(self, encoder: TemporalEncoder, head: RegressionHead) -> None:
        super().__init__()
        self.encoder = encoder
        self.head = head

    def forward(self, batch: Mapping[str, torch.Tensor]) -> torch.Tensor:
        semg, imu = batch["semg"], batch["imu"]
        if semg.shape[:2] != imu.shape[:2]:
            raise ValueError(
                "Early fusion requires equal batch and time dimensions, got "
                f"semg={tuple(semg.shape)}, imu={tuple(imu.shape)}"
            )
        return self.head(self.encoder(torch.cat((semg, imu), dim=-1)))


class DualBranchRegressor(nn.Module):
    def __init__(
        self,
        semg_encoder: TemporalEncoder,
        imu_encoder: TemporalEncoder,
        head: RegressionHead,
    ) -> None:
        super().__init__()
        self.semg_encoder = semg_encoder
        self.imu_encoder = imu_encoder
        self.head = head

    def forward(self, batch: Mapping[str, torch.Tensor]) -> torch.Tensor:
        semg_feature = self.semg_encoder(batch["semg"])
        imu_feature = self.imu_encoder(batch["imu"])
        return self.head(torch.cat((semg_feature, imu_feature), dim=-1))


class IMUGuidedEMGRegressor(nn.Module):
    """Use IMU context to gate the sEMG latent feature before late fusion."""

    def __init__(
        self,
        semg_encoder: TemporalEncoder,
        imu_encoder: TemporalEncoder,
        feature_dim: int,
        head: RegressionHead,
    ) -> None:
        super().__init__()
        self.semg_encoder = semg_encoder
        self.imu_encoder = imu_encoder
        self.emg_gate = nn.Sequential(
            nn.Linear(feature_dim, feature_dim),
            nn.ReLU(),
            nn.Linear(feature_dim, feature_dim),
            nn.Sigmoid(),
        )
        self.head = head

    def forward_with_gate(
        self, batch: Mapping[str, torch.Tensor]
    ) -> tuple[torch.Tensor, torch.Tensor]:
        semg_feature = self.semg_encoder(batch["semg"])
        imu_feature = self.imu_encoder(batch["imu"])
        gate = self.emg_gate(imu_feature)
        guided_semg = semg_feature * gate
        prediction = self.head(torch.cat((imu_feature, guided_semg), dim=-1))
        return prediction, gate

    def forward(self, batch: Mapping[str, torch.Tensor]) -> torch.Tensor:
        prediction, _ = self.forward_with_gate(batch)
        return prediction


class IMUCoarseEMGResidualRegressor(nn.Module):
    """Freeze an IMU-only teacher and let sEMG predict its angle residual."""

    def __init__(
        self,
        imu_coarse_model: nn.Module,
        semg_encoder: TemporalEncoder,
        feature_dim: int,
        output_dim: int,
        dropout: float,
    ) -> None:
        super().__init__()
        self.imu_coarse_model = imu_coarse_model
        self.semg_encoder = semg_encoder
        self.residual_head = nn.Sequential(
            nn.Linear(feature_dim + output_dim, feature_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(feature_dim, max(32, feature_dim // 2)),
            nn.ReLU(),
            nn.Linear(max(32, feature_dim // 2), output_dim),
        )
        self.freeze_coarse_model()

    def freeze_coarse_model(self) -> None:
        self.imu_coarse_model.eval()
        for parameter in self.imu_coarse_model.parameters():
            parameter.requires_grad = False

    def train(self, mode: bool = True) -> "IMUCoarseEMGResidualRegressor":
        super().train(mode)
        # Keep BatchNorm and dropout in the fixed teacher in evaluation mode.
        self.imu_coarse_model.eval()
        return self

    def forward_with_components(
        self, batch: Mapping[str, torch.Tensor]
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        self.imu_coarse_model.eval()
        with torch.no_grad():
            coarse = self.imu_coarse_model(batch)
        semg_feature = self.semg_encoder(batch["semg"])
        delta = self.residual_head(torch.cat((semg_feature, coarse), dim=-1))
        return coarse + delta, coarse, delta

    def forward(self, batch: Mapping[str, torch.Tensor]) -> torch.Tensor:
        final, _, _ = self.forward_with_components(batch)
        return final


class AttentionGatedAxisRegressor(nn.Module):
    """Attention-pooled branches, learned modality gates, and independent axis heads."""

    def __init__(
        self,
        semg_encoder: AttentionTemporalEncoder,
        imu_encoder: AttentionTemporalEncoder,
        feature_dim: int,
        output_dim: int,
        dropout: float,
    ) -> None:
        super().__init__()
        self.semg_encoder = semg_encoder
        self.imu_encoder = imu_encoder
        fused_dim = 2 * feature_dim
        self.fusion_gate = nn.Sequential(
            nn.Linear(fused_dim, fused_dim),
            nn.ReLU(),
            nn.Linear(fused_dim, fused_dim),
            nn.Sigmoid(),
        )
        self.head = AxisSpecificRegressionHead(fused_dim, output_dim, dropout)

    def forward(self, batch: Mapping[str, torch.Tensor]) -> torch.Tensor:
        semg_feature = self.semg_encoder(batch["semg"])
        imu_feature = self.imu_encoder(batch["imu"])
        fused = torch.cat((semg_feature, imu_feature), dim=-1)
        gated = fused * self.fusion_gate(fused)
        return self.head(gated)


def build_model(
    model_config: Mapping[str, object],
    semg_channels: int,
    imu_channels: int,
    output_dim: int,
) -> nn.Module:
    model_type = str(model_config.get("type", "dual_branch")).lower()
    conv_channels = int(model_config.get("conv_channels", 32))
    gru_hidden = int(model_config.get("gru_hidden", 48))
    feature_dim = int(model_config.get("feature_dim", 64))
    dropout = float(model_config.get("dropout", 0.1))

    def encoder(channels: int) -> TemporalEncoder:
        return TemporalEncoder(channels, conv_channels, gru_hidden, feature_dim, dropout)

    def attention_encoder(channels: int) -> AttentionTemporalEncoder:
        return AttentionTemporalEncoder(
            channels, conv_channels, gru_hidden, feature_dim, dropout
        )

    if model_type == "imu_only":
        return SingleModalRegressor(
            "imu", encoder(imu_channels), RegressionHead(feature_dim, output_dim, dropout)
        )
    if model_type == "semg_only":
        return SingleModalRegressor(
            "semg", encoder(semg_channels), RegressionHead(feature_dim, output_dim, dropout)
        )
    if model_type == "early_fusion":
        return EarlyFusionRegressor(
            encoder(semg_channels + imu_channels),
            RegressionHead(feature_dim, output_dim, dropout),
        )
    if model_type == "dual_branch":
        return DualBranchRegressor(
            encoder(semg_channels),
            encoder(imu_channels),
            RegressionHead(2 * feature_dim, output_dim, dropout),
        )
    if model_type == "imu_guided_emg_gate":
        return IMUGuidedEMGRegressor(
            encoder(semg_channels),
            encoder(imu_channels),
            feature_dim,
            RegressionHead(2 * feature_dim, output_dim, dropout),
        )
    if model_type == "attention_gated_axis_heads":
        return AttentionGatedAxisRegressor(
            attention_encoder(semg_channels),
            attention_encoder(imu_channels),
            feature_dim,
            output_dim,
            dropout,
        )
    raise ValueError(
        f"Unknown model type {model_type!r}; choose imu_only, semg_only, "
        "early_fusion, dual_branch, imu_guided_emg_gate, or attention_gated_axis_heads"
    )
