from __future__ import annotations

import time
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader

from bishe_ai.evaluation.metrics import regression_metrics
from bishe_ai.evaluation.joint_fk import TorchJoint8FK


def _move_batch(batch: dict[str, torch.Tensor], device: torch.device) -> dict[str, torch.Tensor]:
    return {name: value.to(device, non_blocking=True) for name, value in batch.items()}


class _RegressionBatchLoss(nn.Module):
    def __init__(self, loss: nn.Module) -> None:
        super().__init__()
        self.loss = loss

    def forward(self, prediction: torch.Tensor, batch: dict[str, torch.Tensor]) -> torch.Tensor:
        return self.loss(prediction, batch["target"])


class JointFKMultitaskLoss(nn.Module):
    def __init__(
        self,
        preprocessing: dict[str, np.ndarray | None],
        angle_weight: float,
        xyz_weight: float,
    ) -> None:
        super().__init__()
        if angle_weight < 0 or xyz_weight < 0 or angle_weight + xyz_weight <= 0:
            raise ValueError("Multitask loss weights must be non-negative with a positive sum")
        required = ("target_mean", "target_scale", "xyz_mean", "xyz_scale")
        missing = [name for name in required if preprocessing.get(name) is None]
        fk_parameters = {
            name: value for name, value in preprocessing.items() if name.startswith("fk_")
        }
        if missing or not fk_parameters:
            raise ValueError(f"Joint FK loss is missing preprocessing arrays: {missing}")
        self.register_buffer("target_mean", torch.as_tensor(preprocessing["target_mean"], dtype=torch.float32))
        self.register_buffer("target_scale", torch.as_tensor(preprocessing["target_scale"], dtype=torch.float32))
        self.register_buffer("xyz_mean", torch.as_tensor(preprocessing["xyz_mean"], dtype=torch.float32))
        self.register_buffer("xyz_scale", torch.as_tensor(preprocessing["xyz_scale"], dtype=torch.float32))
        self.fk = TorchJoint8FK(fk_parameters)
        self.angle_weight = float(angle_weight)
        self.xyz_weight = float(xyz_weight)
        self.huber = nn.HuberLoss()

    def forward(self, prediction: torch.Tensor, batch: dict[str, torch.Tensor]) -> torch.Tensor:
        if "xyz" not in batch or "subject_index" not in batch:
            raise KeyError("Joint FK loss requires xyz and subject_index in every batch")
        angle_loss = self.huber(prediction, batch["target"])
        prediction_deg = prediction * self.target_scale + self.target_mean
        prediction_xyz_m = self.fk(prediction_deg, batch["subject_index"])
        prediction_xyz = (prediction_xyz_m - self.xyz_mean) / self.xyz_scale
        xyz_loss = self.huber(prediction_xyz, batch["xyz"])
        return self.angle_weight * angle_loss + self.xyz_weight * xyz_loss


def _criterion(
    name: str,
    config: dict[str, Any],
    preprocessing: dict[str, np.ndarray | None],
) -> nn.Module:
    if name.lower() == "mse":
        return _RegressionBatchLoss(nn.MSELoss())
    if name.lower() == "huber":
        return _RegressionBatchLoss(nn.HuberLoss())
    if name.lower() == "joint_fk_multitask":
        return JointFKMultitaskLoss(
            preprocessing,
            angle_weight=float(config.get("angle_loss_weight", 0.4)),
            xyz_weight=float(config.get("xyz_loss_weight", 0.6)),
        )
    raise ValueError(f"Unknown loss {name!r}; choose mse, huber, or joint_fk_multitask")


def _epoch(
    model: nn.Module,
    loader: DataLoader[dict[str, torch.Tensor]],
    criterion: nn.Module,
    device: torch.device,
    optimizer: torch.optim.Optimizer | None,
) -> float:
    training = optimizer is not None
    model.train(training)
    total_loss = 0.0
    total_samples = 0
    context = torch.enable_grad() if training else torch.inference_mode()
    with context:
        for batch in loader:
            batch = _move_batch(batch, device)
            if training:
                optimizer.zero_grad(set_to_none=True)
            prediction = model(batch)
            loss = criterion(prediction, batch)
            if training:
                loss.backward()
                optimizer.step()
            count = batch["target"].shape[0]
            total_loss += float(loss.detach()) * count
            total_samples += count
    if total_samples == 0:
        raise ValueError("DataLoader produced no samples")
    return total_loss / total_samples


def fit(
    model: nn.Module,
    train_loader: DataLoader[dict[str, torch.Tensor]],
    val_loader: DataLoader[dict[str, torch.Tensor]],
    config: dict[str, Any],
    device: torch.device,
    checkpoint_path: str | Path,
    full_config: dict[str, Any],
    preprocessing: dict[str, np.ndarray | None] | None = None,
) -> tuple[list[dict[str, float]], float]:
    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=float(config.get("learning_rate", 1e-3)),
        weight_decay=float(config.get("weight_decay", 0.0)),
    )
    preprocessing = preprocessing or {}
    criterion = _criterion(str(config.get("loss", "huber")), config, preprocessing).to(device)
    epochs = int(config.get("epochs", 20))
    patience = int(config.get("early_stopping_patience", 5))
    best_loss = float("inf")
    stale_epochs = 0
    history: list[dict[str, float]] = []
    checkpoint = Path(checkpoint_path)
    checkpoint.parent.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    for epoch in range(1, epochs + 1):
        train_loss = _epoch(model, train_loader, criterion, device, optimizer)
        val_loss = _epoch(model, val_loader, criterion, device, None)
        row = {"epoch": float(epoch), "train_loss": train_loss, "val_loss": val_loss}
        history.append(row)
        print(
            f"epoch={epoch:03d} train_loss={train_loss:.6f} "
            f"val_loss={val_loss:.6f} device={device}"
        )
        if val_loss < best_loss:
            best_loss = val_loss
            stale_epochs = 0
            torch.save(
                {
                    "model_state": model.state_dict(),
                    "optimizer_state": optimizer.state_dict(),
                    "epoch": epoch,
                    "best_val_loss": best_loss,
                    "config": full_config,
                    "preprocessing": preprocessing or {},
                },
                checkpoint,
            )
        else:
            stale_epochs += 1
            if stale_epochs >= patience:
                print(f"early_stopping epoch={epoch} patience={patience}")
                break
    duration = time.perf_counter() - started
    saved = torch.load(checkpoint, map_location=device, weights_only=False)
    model.load_state_dict(saved["model_state"])
    return history, duration


def evaluate(
    model: nn.Module,
    loader: DataLoader[dict[str, torch.Tensor]],
    device: torch.device,
    target_mean: np.ndarray | None = None,
    target_scale: np.ndarray | None = None,
) -> tuple[dict[str, object], np.ndarray, np.ndarray]:
    model.eval()
    predictions: list[np.ndarray] = []
    targets: list[np.ndarray] = []
    batch_latencies: list[float] = []
    with torch.inference_mode():
        for batch in loader:
            batch = _move_batch(batch, device)
            if device.type == "cuda":
                torch.cuda.synchronize(device)
            started = time.perf_counter()
            prediction = model(batch)
            if device.type == "cuda":
                torch.cuda.synchronize(device)
            batch_latencies.append(time.perf_counter() - started)
            predictions.append(prediction.cpu().numpy())
            targets.append(batch["target"].cpu().numpy())
    prediction_array = np.concatenate(predictions)
    target_array = np.concatenate(targets)
    if target_mean is not None or target_scale is not None:
        if target_mean is None or target_scale is None:
            raise ValueError("target_mean and target_scale must be supplied together")
        target_array = target_array * target_scale + target_mean
        prediction_array = prediction_array * target_scale + target_mean
    metrics = regression_metrics(target_array, prediction_array)
    total_samples = len(target_array)
    metrics["inference_total_seconds"] = float(sum(batch_latencies))
    metrics["inference_ms_per_sample"] = float(sum(batch_latencies) * 1000 / total_samples)
    return metrics, target_array, prediction_array
