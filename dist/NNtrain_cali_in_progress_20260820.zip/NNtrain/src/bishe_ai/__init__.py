"""Core package for the sEMG-IMU regression project."""

__version__ = "0.1.0"

