from __future__ import annotations

import numpy as np


def regression_metrics(target: np.ndarray, prediction: np.ndarray) -> dict[str, object]:
    target = np.asarray(target, dtype=np.float64)
    prediction = np.asarray(prediction, dtype=np.float64)
    if target.shape != prediction.shape or target.ndim != 2:
        raise ValueError(
            "target and prediction must share shape [samples, output_dim], got "
            f"{target.shape} and {prediction.shape}"
        )
    error = prediction - target
    mae_dim = np.mean(np.abs(error), axis=0)
    rmse_dim = np.sqrt(np.mean(error**2, axis=0))
    target_centered = target - np.mean(target, axis=0, keepdims=True)
    ss_total = np.sum(target_centered**2, axis=0)
    ss_residual = np.sum(error**2, axis=0)
    r2_dim: list[float | None] = [
        None if total < 1e-12 else float(1.0 - residual / total)
        for residual, total in zip(ss_residual, ss_total, strict=True)
    ]
    correlations: list[float | None] = []
    for index in range(target.shape[1]):
        if np.std(target[:, index]) < 1e-12 or np.std(prediction[:, index]) < 1e-12:
            correlations.append(None)
        else:
            correlations.append(float(np.corrcoef(target[:, index], prediction[:, index])[0, 1]))
    valid_correlations = [value for value in correlations if value is not None]
    valid_r2 = [value for value in r2_dim if value is not None]
    result: dict[str, object] = {
        "mae": float(np.mean(np.abs(error))),
        "rmse": float(np.sqrt(np.mean(error**2))),
        "mae_per_dim": mae_dim.tolist(),
        "rmse_per_dim": rmse_dim.tolist(),
        "r2_per_dim": r2_dim,
        "r2_mean": float(np.mean(valid_r2)) if valid_r2 else None,
        "pearson_per_dim": correlations,
        "pearson_mean": float(np.mean(valid_correlations)) if valid_correlations else None,
        "samples": int(target.shape[0]),
        "output_dim": int(target.shape[1]),
    }
    if target.shape[1] == 3:
        distances = np.linalg.norm(error, axis=1)
        result["euclidean_mean"] = float(np.mean(distances))
        result["euclidean_median"] = float(np.median(distances))
    return result
