from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from xml.etree import ElementTree as ET

import numpy as np
import torch
from torch import nn


def _vector(element: ET.Element, tag: str) -> np.ndarray:
    child = element.find(f".//{tag}")
    if child is None or child.text is None:
        raise KeyError(f"Missing {tag} in OpenSim element {element.get('name')!r}")
    value = np.fromstring(child.text, sep=" ", dtype=np.float64)
    if value.shape != (3,):
        raise ValueError(f"Expected a Vec3 for {tag}, got {value}")
    return value


def _named(root: ET.Element, tag: str, name: str) -> ET.Element:
    element = root.find(f".//{tag}[@name='{name}']")
    if element is None:
        raise KeyError(f"OpenSim model is missing {tag} {name!r}")
    return element


def _frame_translation(joint: ET.Element, frame_name: str) -> np.ndarray:
    frame = joint.find(f"./frames/PhysicalOffsetFrame[@name='{frame_name}']")
    if frame is None:
        raise KeyError(f"Joint {joint.get('name')!r} is missing frame {frame_name!r}")
    return _vector(frame, "translation")


def _marker_location(root: ET.Element, marker_name: str) -> np.ndarray:
    return _vector(_named(root, "Marker", marker_name), "location")


def _axis(joint: ET.Element, transform_name: str) -> np.ndarray:
    transform = joint.find(f"./SpatialTransform/TransformAxis[@name='{transform_name}']")
    if transform is None:
        raise KeyError(f"Joint {joint.get('name')!r} is missing {transform_name!r}")
    value = _vector(transform, "axis")
    norm = np.linalg.norm(value)
    if norm < 1e-12:
        raise ValueError(f"Zero rotation axis in {joint.get('name')!r}/{transform_name}")
    return value / norm


def _rotate(axis: np.ndarray, angle_rad: np.ndarray) -> np.ndarray:
    """Batch Rodrigues rotations, returned as [sample, 3, 3]."""
    axis = np.asarray(axis, dtype=np.float64)
    angle = np.asarray(angle_rad, dtype=np.float64).reshape(-1)
    x, y, z = axis
    skew = np.array([[0.0, -z, y], [z, 0.0, -x], [-y, x, 0.0]])
    outer = np.outer(axis, axis)
    identity = np.eye(3)
    cosine = np.cos(angle)[:, None, None]
    sine = np.sin(angle)[:, None, None]
    return cosine * identity + (1.0 - cosine) * outer + sine * skew


def _apply(rotation: np.ndarray, vector: np.ndarray) -> np.ndarray:
    return np.einsum("nij,j->ni", rotation, np.asarray(vector, dtype=np.float64))


@dataclass(frozen=True)
class SubjectArmKinematics:
    """Four-DOF right-arm FK from a subject-scaled ULTRA OpenSim model.

    All non-modelled coordinates (torso, sternoclavicular, pronation and wrist)
    are fixed at the OpenSim model's zero pose. Output uses the same anatomical
    axes and RSHO origin as the prepared dynamic Vicon wrist target.
    """

    shoulder_origin: np.ndarray
    rsho: np.ndarray
    camera_from_body: np.ndarray
    right_clavicle_origin: np.ndarray
    left_clavicle_origin: np.ndarray
    scapula_offset: np.ndarray
    shoulder_offset: np.ndarray
    rsho_marker: np.ndarray
    lsho_marker: np.ndarray
    stur_marker: np.ndarray
    elbow_offset: np.ndarray
    radioulnar_offset: np.ndarray
    rradius_marker: np.ndarray
    rulna_marker: np.ndarray
    shoulder_axes: tuple[np.ndarray, np.ndarray, np.ndarray]
    elbow_axis: np.ndarray
    right_sc_axes: tuple[np.ndarray, np.ndarray, np.ndarray]
    left_sc_axes: tuple[np.ndarray, np.ndarray, np.ndarray]
    pronation_axis: np.ndarray

    @classmethod
    def from_osim(cls, path: str | Path) -> "SubjectArmKinematics":
        root = ET.parse(Path(path)).getroot()
        sc1 = _named(root, "CustomJoint", "sc1")
        sc1_l = _named(root, "CustomJoint", "sc1_l")
        sc2 = _named(root, "CustomJoint", "sc2")
        sc3 = _named(root, "CustomJoint", "sc3")
        sc2_l = _named(root, "CustomJoint", "sc2_l")
        sc3_l = _named(root, "CustomJoint", "sc3_l")
        ac1 = _named(root, "WeldJoint", "AC1")
        acromial = _named(root, "CustomJoint", "acromial_r")
        elbow = _named(root, "CustomJoint", "elbow_r")
        radioulnar = _named(root, "CustomJoint", "radioulnar_r")

        right_clavicle = _frame_translation(sc1, "torso_offset")
        left_clavicle = _frame_translation(sc1_l, "torso_offset")
        scapula = right_clavicle + _frame_translation(ac1, "clavicle_r_offset")
        shoulder = scapula + _frame_translation(acromial, "scapula_r_offset")
        rsho = right_clavicle + _marker_location(root, "RSHO")
        lsho = left_clavicle + _marker_location(root, "LSHO")
        stur = _marker_location(root, "STUR")

        x_axis = rsho - lsho
        x_axis /= np.linalg.norm(x_axis)
        up = 0.5 * (rsho + lsho) - stur
        y_axis = up - np.dot(up, x_axis) * x_axis
        y_axis /= np.linalg.norm(y_axis)
        z_axis = np.cross(x_axis, y_axis)
        z_axis /= np.linalg.norm(z_axis)
        y_axis = np.cross(z_axis, x_axis)
        camera_from_body = np.column_stack((x_axis, y_axis, z_axis))

        return cls(
            shoulder_origin=shoulder,
            rsho=rsho,
            camera_from_body=camera_from_body,
            right_clavicle_origin=right_clavicle,
            left_clavicle_origin=left_clavicle,
            scapula_offset=_frame_translation(ac1, "clavicle_r_offset"),
            shoulder_offset=_frame_translation(acromial, "scapula_r_offset"),
            rsho_marker=_marker_location(root, "RSHO"),
            lsho_marker=_marker_location(root, "LSHO"),
            stur_marker=stur,
            elbow_offset=_frame_translation(elbow, "humerus_r_offset"),
            radioulnar_offset=_frame_translation(radioulnar, "ulna_r_offset"),
            rradius_marker=_marker_location(root, "RRAD"),
            rulna_marker=_marker_location(root, "RULN"),
            shoulder_axes=tuple(_axis(acromial, f"rotation{i}") for i in (1, 2, 3)),
            elbow_axis=_axis(elbow, "rotation1"),
            right_sc_axes=(
                _axis(sc1, "rotation1"),
                _axis(sc2, "rotation3"),
                _axis(sc3, "rotation2"),
            ),
            left_sc_axes=(
                _axis(sc1_l, "rotation1"),
                _axis(sc2_l, "rotation3"),
                _axis(sc3_l, "rotation2"),
            ),
            pronation_axis=_axis(radioulnar, "rotation1"),
        )

    def wrist_xyz(self, joint_angles_deg: np.ndarray) -> np.ndarray:
        angles = np.asarray(joint_angles_deg, dtype=np.float64)
        if angles.ndim != 2 or angles.shape[1] != 4 or not np.isfinite(angles).all():
            raise ValueError(f"joint_angles_deg must be finite [samples, 4], got {angles.shape}")
        radians = np.deg2rad(angles)
        shoulder_rotation = np.broadcast_to(np.eye(3), (len(angles), 3, 3)).copy()
        for index, axis in enumerate(self.shoulder_axes):
            shoulder_rotation = shoulder_rotation @ _rotate(axis, radians[:, index])
        elbow_rotation = _rotate(self.elbow_axis, radians[:, 3])
        ulna_rotation = shoulder_rotation @ elbow_rotation

        elbow = self.shoulder_origin + _apply(shoulder_rotation, self.elbow_offset)
        ruln = elbow + _apply(ulna_rotation, self.rulna_marker)
        radius_origin = elbow + _apply(ulna_rotation, self.radioulnar_offset)
        rrad = radius_origin + _apply(ulna_rotation, self.rradius_marker)
        wrist = 0.5 * (rrad + ruln)
        return ((wrist - self.rsho) @ self.camera_from_body).astype(np.float32)

    @staticmethod
    def _three_rotations(axes: tuple[np.ndarray, np.ndarray, np.ndarray], angles: np.ndarray) -> np.ndarray:
        rotation = np.broadcast_to(np.eye(3), (len(angles), 3, 3)).copy()
        for index, axis in enumerate(axes):
            rotation = rotation @ _rotate(axis, angles[:, index])
        return rotation

    def wrist_xyz_full_ik(
        self,
        joint_angles_deg: np.ndarray,
        right_sc_deg: np.ndarray,
        left_sc_deg: np.ndarray,
        pronation_deg: np.ndarray,
    ) -> np.ndarray:
        """Diagnostic full-IK FK used only to validate transform conventions."""
        joint = np.deg2rad(np.asarray(joint_angles_deg, dtype=np.float64))
        right_sc = np.deg2rad(np.asarray(right_sc_deg, dtype=np.float64))
        left_sc = np.deg2rad(np.asarray(left_sc_deg, dtype=np.float64))
        pronation = np.deg2rad(np.asarray(pronation_deg, dtype=np.float64).reshape(-1))
        if joint.ndim != 2 or joint.shape[1] != 4:
            raise ValueError(f"joint_angles_deg must be [samples, 4], got {joint.shape}")
        if right_sc.shape != (len(joint), 3) or left_sc.shape != (len(joint), 3):
            raise ValueError("SC angle arrays must be [samples, 3]")

        right_sc_rotation = self._three_rotations(self.right_sc_axes, right_sc)
        left_sc_rotation = self._three_rotations(self.left_sc_axes, left_sc)
        shoulder_origin = (
            self.right_clavicle_origin
            + _apply(right_sc_rotation, self.scapula_offset + self.shoulder_offset)
        )
        rsho = self.right_clavicle_origin + _apply(right_sc_rotation, self.rsho_marker)
        lsho = self.left_clavicle_origin + _apply(left_sc_rotation, self.lsho_marker)

        shoulder_rotation = right_sc_rotation @ self._three_rotations(
            self.shoulder_axes, joint[:, :3]
        )
        ulna_rotation = shoulder_rotation @ _rotate(self.elbow_axis, joint[:, 3])
        elbow = shoulder_origin + _apply(shoulder_rotation, self.elbow_offset)
        ruln = elbow + _apply(ulna_rotation, self.rulna_marker)
        radius_origin = elbow + _apply(ulna_rotation, self.radioulnar_offset)
        radius_rotation = ulna_rotation @ _rotate(self.pronation_axis, pronation)
        rrad = radius_origin + _apply(radius_rotation, self.rradius_marker)
        wrist = 0.5 * (rrad + ruln)

        x_axis = rsho - lsho
        x_axis /= np.linalg.norm(x_axis, axis=1, keepdims=True)
        shoulder_center = 0.5 * (rsho + lsho)
        up = shoulder_center - self.stur_marker
        y_axis = up - np.sum(up * x_axis, axis=1, keepdims=True) * x_axis
        y_axis /= np.linalg.norm(y_axis, axis=1, keepdims=True)
        z_axis = np.cross(x_axis, y_axis)
        z_axis /= np.linalg.norm(z_axis, axis=1, keepdims=True)
        y_axis = np.cross(z_axis, x_axis)
        relative = wrist - rsho
        return np.column_stack(
            (
                np.sum(relative * x_axis, axis=1),
                np.sum(relative * y_axis, axis=1),
                np.sum(relative * z_axis, axis=1),
            )
        ).astype(np.float32)


def endpoint_metrics(target_m: np.ndarray, prediction_m: np.ndarray) -> dict[str, object]:
    target = np.asarray(target_m, dtype=np.float64)
    prediction = np.asarray(prediction_m, dtype=np.float64)
    if target.shape != prediction.shape or target.ndim != 2 or target.shape[1] != 3:
        raise ValueError(f"Endpoint arrays must share [samples, 3], got {target.shape}/{prediction.shape}")
    difference_cm = (prediction - target) * 100.0
    distance_cm = np.linalg.norm(difference_cm, axis=1)
    return {
        "mean_euclidean_cm": float(np.mean(distance_cm)),
        "rmse_euclidean_cm": float(np.sqrt(np.mean(distance_cm**2))),
        "median_euclidean_cm": float(np.median(distance_cm)),
        "p95_euclidean_cm": float(np.percentile(distance_cm, 95)),
        "axis_mae_cm": np.mean(np.abs(difference_cm), axis=0).tolist(),
        "samples": int(len(target)),
    }


def _torch_rotate(axis: torch.Tensor, angle: torch.Tensor) -> torch.Tensor:
    axis = torch.nn.functional.normalize(axis, dim=-1)
    x, y, z = axis.unbind(dim=-1)
    zero = torch.zeros_like(x)
    skew = torch.stack(
        (zero, -z, y, z, zero, -x, -y, x, zero), dim=-1
    ).reshape(-1, 3, 3)
    outer = axis.unsqueeze(-1) * axis.unsqueeze(-2)
    identity = torch.eye(3, device=axis.device, dtype=axis.dtype).expand(len(axis), -1, -1)
    cosine = torch.cos(angle).reshape(-1, 1, 1)
    sine = torch.sin(angle).reshape(-1, 1, 1)
    return cosine * identity + (1.0 - cosine) * outer + sine * skew


def _torch_apply(rotation: torch.Tensor, vector: torch.Tensor) -> torch.Tensor:
    return torch.bmm(rotation, vector.unsqueeze(-1)).squeeze(-1)


class TorchJoint8FK(nn.Module):
    """Differentiable subject-scaled right-arm FK for the eight target angles."""

    vector_fields = FK_VECTOR_FIELDS = (
        "right_clavicle_origin",
        "left_clavicle_origin",
        "scapula_offset",
        "shoulder_offset",
        "rsho_marker",
        "lsho_marker",
        "stur_marker",
        "elbow_offset",
        "radioulnar_offset",
        "rradius_marker",
        "rulna_marker",
        "elbow_axis",
        "pronation_axis",
    )

    def __init__(self, parameters: dict[str, np.ndarray | torch.Tensor]) -> None:
        super().__init__()
        for field in self.vector_fields:
            self.register_buffer(field, torch.as_tensor(parameters[f"fk_{field}"], dtype=torch.float32))
        self.register_buffer(
            "shoulder_axes", torch.as_tensor(parameters["fk_shoulder_axes"], dtype=torch.float32)
        )
        self.register_buffer(
            "right_sc_axes", torch.as_tensor(parameters["fk_right_sc_axes"], dtype=torch.float32)
        )

    def _select(self, name: str, subject_index: torch.Tensor) -> torch.Tensor:
        return getattr(self, name).index_select(0, subject_index.long())

    def forward(self, angles_deg: torch.Tensor, subject_index: torch.Tensor) -> torch.Tensor:
        if angles_deg.ndim != 2 or angles_deg.shape[1] != 8:
            raise ValueError(f"Expected angles [batch, 8], got {tuple(angles_deg.shape)}")
        index = subject_index.reshape(-1).long()
        if len(index) != len(angles_deg):
            raise ValueError("subject_index and angles batch sizes differ")
        radians = torch.deg2rad(angles_deg)

        right_sc = torch.eye(3, device=angles_deg.device, dtype=angles_deg.dtype).expand(
            len(angles_deg), -1, -1
        ).clone()
        sc_axes = self.right_sc_axes.index_select(0, index)
        for axis_index in range(3):
            right_sc = right_sc @ _torch_rotate(sc_axes[:, axis_index], radians[:, axis_index])

        shoulder_local = torch.eye(
            3, device=angles_deg.device, dtype=angles_deg.dtype
        ).expand(len(angles_deg), -1, -1).clone()
        shoulder_axes = self.shoulder_axes.index_select(0, index)
        for axis_index in range(3):
            shoulder_local = shoulder_local @ _torch_rotate(
                shoulder_axes[:, axis_index], radians[:, 3 + axis_index]
            )
        shoulder_rotation = right_sc @ shoulder_local
        elbow_rotation = _torch_rotate(self._select("elbow_axis", index), radians[:, 6])
        ulna_rotation = shoulder_rotation @ elbow_rotation

        right_clavicle = self._select("right_clavicle_origin", index)
        shoulder_offset = self._select("scapula_offset", index) + self._select(
            "shoulder_offset", index
        )
        shoulder_origin = right_clavicle + _torch_apply(right_sc, shoulder_offset)
        elbow = shoulder_origin + _torch_apply(
            shoulder_rotation, self._select("elbow_offset", index)
        )
        ruln = elbow + _torch_apply(ulna_rotation, self._select("rulna_marker", index))
        radius_origin = elbow + _torch_apply(
            ulna_rotation, self._select("radioulnar_offset", index)
        )
        radius_rotation = ulna_rotation @ _torch_rotate(
            self._select("pronation_axis", index), radians[:, 7]
        )
        rrad = radius_origin + _torch_apply(
            radius_rotation, self._select("rradius_marker", index)
        )
        wrist = 0.5 * (rrad + ruln)

        rsho = right_clavicle + _torch_apply(right_sc, self._select("rsho_marker", index))
        lsho = self._select("left_clavicle_origin", index) + self._select("lsho_marker", index)
        stur = self._select("stur_marker", index)
        x_axis = torch.nn.functional.normalize(rsho - lsho, dim=-1)
        up = 0.5 * (rsho + lsho) - stur
        y_axis = torch.nn.functional.normalize(
            up - torch.sum(up * x_axis, dim=-1, keepdim=True) * x_axis, dim=-1
        )
        z_axis = torch.nn.functional.normalize(torch.cross(x_axis, y_axis, dim=-1), dim=-1)
        y_axis = torch.nn.functional.normalize(torch.cross(z_axis, x_axis, dim=-1), dim=-1)
        relative = wrist - rsho
        return torch.stack(
            (
                torch.sum(relative * x_axis, dim=-1),
                torch.sum(relative * y_axis, dim=-1),
                torch.sum(relative * z_axis, dim=-1),
            ),
            dim=-1,
        )
