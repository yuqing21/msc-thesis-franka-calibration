from __future__ import annotations

import os
from pathlib import Path
from typing import Sequence

_PROJECT_ROOT = Path(__file__).resolve().parents[3]
_MPL_CACHE = _PROJECT_ROOT / ".cache" / "matplotlib"
_MPL_CACHE.mkdir(parents=True, exist_ok=True)
os.environ.setdefault("MPLCONFIGDIR", str(_MPL_CACHE))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def save_training_plot(history: Sequence[dict[str, float]], path: str | Path) -> Path:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    epochs = [int(row["epoch"]) for row in history]
    plt.figure(figsize=(7, 4))
    plt.plot(epochs, [row["train_loss"] for row in history], label="train")
    plt.plot(epochs, [row["val_loss"] for row in history], label="validation")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.legend()
    plt.tight_layout()
    plt.savefig(output, dpi=160)
    plt.close()
    return output


def save_prediction_plot(
    target: np.ndarray,
    prediction: np.ndarray,
    path: str | Path,
    max_samples: int = 300,
) -> Path:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    count = min(max_samples, len(target))
    dimensions = target.shape[1]
    figure, axes = plt.subplots(dimensions, 1, figsize=(9, 2.5 * dimensions), sharex=True)
    axes = np.atleast_1d(axes)
    for index, axis in enumerate(axes):
        axis.plot(target[:count, index], label="target", linewidth=1.5)
        axis.plot(prediction[:count, index], label="prediction", linewidth=1.1)
        axis.set_ylabel(f"dim {index}")
        axis.legend(loc="upper right")
    axes[-1].set_xlabel("Ordered test window")
    figure.tight_layout()
    figure.savefig(output, dpi=160)
    plt.close(figure)
    return output
