# ULTRA-MoCap 公开数据验证场

本文件夹只用于 ULTRA-MoCap 公开数据上的方法验证，不是最终自采数据集。最终项目
会在 `NNtrain/src/bishe_ai/` 上使用自采六路 sEMG、IMU和深度相机关节角标签训练。
这里的职责是先验证模型结构、受试者独立划分和模态消融是否可靠。

当前验证实验的索引、哪些结果可引用以及哪些结果需要重跑，见
[`CURRENT_STATUS_ZH.md`](CURRENT_STATUS_ZH.md)。

这个文件夹不复制神经网络；`run_baseline.py` 会直接导入
`NNtrain/src/bishe_ai` 中现有的双分支模型。下述内容主要记录历史XYZ基准：

```text
sEMG [B,50,3] → sEMG编码器 ─┐
                             ├→ 拼接 [B,128] → MLP → 预测XYZ [B,3]
IMU [B,50,36] → IMU编码器  ─┘

Vicon真实XYZ [B,3] → Huber Loss → 反向传播
```

本基准不会加入 FFT、拉普拉斯或其他改进模块。以后只有在基准结果保存好以后，
才建立改进模型进行公平对照。

## 已固定的正式结果

第一次正式基准已经保存到：

```text
fixed_results/Baseline_v1_20260817_144111/
```

从 [`fixed_results/README.md`](fixed_results/README.md) 进入，可以查看固定权重、
指标、曲线、数据版本、问题排查清单和后续实验比较表。不要修改或覆盖该目录。

第一轮系统诊断保存在 [`diagnostics/README.md`](diagnostics/README.md)。目前已经完成
坐标系对照、逐trial误差、输入分布漂移、时间滞后、模态消融和Late Fusion验证。

## 文件作用

- `baseline_ultra_mocap.yaml`：固定正式基准参数；
- `prepare_ultra_mocap.py`：把真实 EMG/IMU/Vicon 文件转换为训练 NPZ；
- `run_baseline.py`：检查数据并调用 `NNtrain` 训练；
- `run_baseline.ps1`：使用项目唯一 Python 环境的简易入口。

数据、权重和结果全部保存在 `BaselineTest_Mocap`：

```text
NNtrain/BaselineTest_Mocap/data/ultra_full_xyz_dynamic_v2.npz
NNtrain/BaselineTest_Mocap/data/ultra_full_xyz_dynamic_v2_audit.json
NNtrain/BaselineTest_Mocap/outputs/
```

## 第一步：验证“启动器能够调用模型”

在 PowerShell 中运行：

```powershell
Set-Location F:\bishe_ai_project
.\NNtrain\BaselineTest_Mocap\run_baseline.ps1 -Smoke
```

这只使用少量合成数据，通常几分钟内结束。输出名称包含
`not_an_experiment`，不能把它当成 ULTRA-MoCap 实验结果。

## 第二步：生成真实训练数据

三个 ZIP 解压完成后运行：

```powershell
Set-Location F:\bishe_ai_project\NNtrain
.\.venv\Scripts\python.exe .\BaselineTest_Mocap\prepare_ultra_mocap.py
```

适配器只读取 `data/raw/ultra_mocap/ULTRA-MoCap`，不会修改原始数据。它会执行：

- 读取3通道原始 sEMG，完成去均值、20～450 Hz带通、60 Hz陷波和50 ms RMS；
- 读取6个IMU的36维特征并低通滤波；
- 将传感器从2000 Hz抗混叠降采样到100 Hz；
- 从 `RRAD` 与 `RULN` 中点生成右腕位置；
- 每一帧使用当前 `LSHO`、`RSHO`、`STUR` 建立动态身体坐标轴；
- 将腕中心相对当前 `RSHO` 投影到动态身体轴，并把毫米转换成米；
- 按 P01～P09 / P10～P11 / P12～P13 分割；
- 仅用训练受试者拟合标准化器；
- 生成500 ms窗口，步长250 ms。

生成结果和完整审计报告都在本文件夹的 `data` 子目录。
旧的 `ultra_full_xyz_v1.npz` 和已冻结Baseline v1会保留，不会被覆盖。

## 第三步：正式数据预检查

准备好正式 NPZ 后运行：

```powershell
.\NNtrain\BaselineTest_Mocap\run_baseline.ps1 -CheckOnly
```

程序必须确认：

- sEMG 为 `[N,50,3]`；
- IMU 为 `[N,50,36]`；
- 标签为 `[N,3]`；
- P01～P09 属于 train；
- P10～P11 属于 validation；
- P12～P13 属于 test。

为了审核受试者划分，NPZ 还必须满足以下任意一种形式：

1. `metadata_json` 中包含 `subject_splits`；
2. 包含 `subject_train`、`subject_val`、`subject_test` 三个字符串数组。

推荐的 `metadata_json` 内容示例：

```json
{
  "dataset_version": "dynamic_body_frame_v2",
  "subject_splits": {
    "train": ["P01", "P02", "P03", "P04", "P05", "P06", "P07", "P08", "P09"],
    "val": ["P10", "P11"],
    "test": ["P12", "P13"]
  },
  "target_definition": {
    "body_frame_mode": "per_frame_dynamic"
  }
}
```

## 第四步：开始正式基准测试

预检查通过后运行：

```powershell
.\NNtrain\BaselineTest_Mocap\run_baseline.ps1
```

训练配置固定为：

- 双分支 `dual_branch`；
- 随机种子 42；
- Huber Loss；
- Adam，学习率 0.001；
- 最多 50 epochs；
- validation 连续 10 epochs 不改善时提前停止。

完成后主要查看：

```text
NNtrain/BaselineTest_Mocap/outputs/formal/dynamic_v2/checkpoints/
NNtrain/BaselineTest_Mocap/outputs/formal/dynamic_v2/metrics/
NNtrain/BaselineTest_Mocap/outputs/formal/dynamic_v2/figures/
NNtrain/BaselineTest_Mocap/outputs/formal/dynamic_v2/logs/
```

每次启动都会给文件名自动添加日期和时间，例如
`ultra_mocap_baseline_20260817_140500`。这样重复实验不会覆盖前一次结果。

## 已完成的注意力门控改进实验

在不覆盖 `dual_branch` 基准的前提下，工程已增加独立模型类型
`attention_gated_axis_heads`，包含时间注意力池化、sEMG/IMU门控融合和XYZ独立
回归头。Dropout 0.1、0.2、0.3 的配置、统一入口及说明位于：

```text
BaselineTest_Mocap/experiments/attention_gated_axis_heads/
```

三组实验中按最低 validation loss 选择了 Dropout 0.3。固定权重、代码快照、配置、
曲线和完整分析保存在：

```text
BaselineTest_Mocap/fixed_results/AttentionGatedAxisHeads_dropout0p3_20260817_154353/
```

## 数据可追溯性

`ultra_full_xyz_dynamic_v2_audit.json` 记录每条 trial 的原文件、采样率、标记缺口、目标
范围、传感器通道、坐标定义、受试者划分和窗口数量。正式训练前不要删除该文件。
