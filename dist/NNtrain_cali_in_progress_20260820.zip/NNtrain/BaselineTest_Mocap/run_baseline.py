from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np


BASELINE_ROOT = Path(__file__).resolve().parent
NNTRAIN_ROOT = BASELINE_ROOT.parent
WORKSPACE_ROOT = NNTRAIN_ROOT.parent
NNTRAIN_SRC = NNTRAIN_ROOT / "src"
DEFAULT_CONFIG = BASELINE_ROOT / "baseline_ultra_mocap.yaml"
DEFAULT_SMOKE_CONFIG = NNTRAIN_ROOT / "configs" / "synthetic_smoke.yaml"
ALLOWED_OUTPUT_ROOT = BASELINE_ROOT / "outputs"

if not NNTRAIN_SRC.is_dir():
    raise RuntimeError(f"找不到 NNtrain 源代码目录：{NNTRAIN_SRC}")
sys.path.insert(0, str(NNTRAIN_SRC))

from bishe_ai.config import load_config, resolve_project_path  # noqa: E402
from bishe_ai.pipeline import run_training  # noqa: E402


EXPECTED_SUBJECT_SPLITS = {
    "train": [f"P{index:02d}" for index in range(1, 10)],
    "val": ["P10", "P11"],
    "test": ["P12", "P13"],
}


def _configure_console() -> None:
    """Keep Chinese status messages printable in Windows terminals."""
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if callable(reconfigure):
            reconfigure(encoding="utf-8", errors="replace")


def _add_run_timestamp(config: dict[str, Any]) -> str:
    """Give each run unique artifact names so an older experiment is never overwritten."""
    base_name = str(config["run"].get("name", "baseline"))
    run_name = f"{base_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    config["run"]["name"] = run_name
    return run_name


def _validate_output_root(config: dict[str, Any]) -> Path:
    """Require every baseline artifact to stay inside BaselineTest_Mocap/outputs."""
    value = config.get("run", {}).get("output_root")
    if value is None:
        raise ValueError("配置缺少 run.output_root")
    output_root = resolve_project_path(value).resolve()
    allowed_root = ALLOWED_OUTPUT_ROOT.resolve()
    if output_root != allowed_root and allowed_root not in output_root.parents:
        raise ValueError(
            "run.output_root 必须位于 BaselineTest_Mocap/outputs 内，实际为："
            f"{output_root}"
        )
    return output_root
REQUIRED_ARRAYS = {
    f"{modality}_{split}"
    for modality in ("semg", "imu", "target")
    for split in ("train", "val", "test")
}


def _normalise_subject_split(value: Any) -> dict[str, list[str]] | None:
    """Extract a train/val/test subject map from common metadata layouts."""
    if not isinstance(value, dict):
        return None
    for key in ("subject_splits", "split_subjects", "subjects_by_split"):
        candidate = value.get(key)
        if isinstance(candidate, dict):
            result: dict[str, list[str]] = {}
            for split in ("train", "val", "test"):
                subjects = candidate.get(split)
                if not isinstance(subjects, list):
                    return None
                result[split] = sorted(str(subject).upper() for subject in subjects)
            return result
    return None


def _metadata_from_archive(archive: np.lib.npyio.NpzFile) -> dict[str, Any] | None:
    if "metadata_json" not in archive.files:
        return None
    raw = archive["metadata_json"]
    if raw.size != 1:
        raise ValueError("metadata_json 必须是只包含一个 JSON 字符串的标量数组")
    try:
        metadata = json.loads(str(raw.reshape(-1)[0]))
    except json.JSONDecodeError as exc:
        raise ValueError("metadata_json 不是有效 JSON") from exc
    if not isinstance(metadata, dict):
        raise ValueError("metadata_json 顶层必须是JSON对象")
    return metadata


def _subject_split_from_archive(
    archive: np.lib.npyio.NpzFile,
) -> dict[str, list[str]] | None:
    metadata = _metadata_from_archive(archive)
    if metadata is not None:
        split = _normalise_subject_split(metadata)
        if split is not None:
            return split

    subject_keys = {f"subject_{split}" for split in ("train", "val", "test")}
    if subject_keys.issubset(archive.files):
        return {
            split: sorted(
                {
                    str(subject).upper()
                    for subject in archive[f"subject_{split}"].reshape(-1).tolist()
                }
            )
            for split in ("train", "val", "test")
        }
    return None


def validate_prepared_dataset(
    path: Path,
    *,
    window_steps: int,
    semg_channels: int,
    imu_channels: int,
    output_dim: int,
) -> dict[str, Any]:
    """Validate the prepared NPZ before a formal baseline is allowed to start."""
    if not path.is_file():
        raise FileNotFoundError(
            "尚未找到正式 ULTRA-MoCap 训练数据：\n"
            f"  {path}\n"
            "需要先用真实原始文件生成该 NPZ；不要用 synthetic_smoke 的结果交差。"
        )

    summary: dict[str, Any] = {"path": str(path), "splits": {}}
    with np.load(path, allow_pickle=False) as archive:
        missing = REQUIRED_ARRAYS.difference(archive.files)
        if missing:
            raise KeyError(f"NPZ 缺少数组：{sorted(missing)}")

        for split in ("train", "val", "test"):
            semg = archive[f"semg_{split}"]
            imu = archive[f"imu_{split}"]
            target = archive[f"target_{split}"]
            if semg.ndim != 3 or imu.ndim != 3 or target.ndim != 2:
                raise ValueError(
                    f"{split} 形状不正确：sEMG={semg.shape}, IMU={imu.shape}, "
                    f"target={target.shape}"
                )
            sample_counts = {semg.shape[0], imu.shape[0], target.shape[0]}
            if len(sample_counts) != 1 or semg.shape[0] == 0:
                raise ValueError(
                    f"{split} 样本数量不一致或为空：sEMG={semg.shape[0]}, "
                    f"IMU={imu.shape[0]}, target={target.shape[0]}"
                )
            expected_shapes = {
                "sEMG": (window_steps, semg_channels),
                "IMU": (window_steps, imu_channels),
                "target": (output_dim,),
            }
            actual_shapes = {
                "sEMG": semg.shape[1:],
                "IMU": imu.shape[1:],
                "target": target.shape[1:],
            }
            for name, expected in expected_shapes.items():
                if actual_shapes[name] != expected:
                    raise ValueError(
                        f"{split}/{name} 单样本形状应为 {expected}，"
                        f"实际为 {actual_shapes[name]}"
                    )
            for name, array in (("sEMG", semg), ("IMU", imu), ("target", target)):
                if not np.issubdtype(array.dtype, np.number):
                    raise TypeError(f"{split}/{name} 必须是数值数组，实际 dtype={array.dtype}")
                if not np.isfinite(array).all():
                    raise ValueError(f"{split}/{name} 含有 NaN 或 Inf，禁止启动正式训练")

            summary["splits"][split] = {
                "samples": int(target.shape[0]),
                "semg_shape": list(semg.shape),
                "imu_shape": list(imu.shape),
                "target_shape": list(target.shape),
            }

        actual_subject_splits = _subject_split_from_archive(archive)
        if actual_subject_splits is None:
            raise ValueError(
                "NPZ 中没有可审核的受试者划分。请在 metadata_json 中写入 "
                "subject_splits，或保存 subject_train/subject_val/subject_test 数组。"
            )
        expected = {
            split: sorted(subjects) for split, subjects in EXPECTED_SUBJECT_SPLITS.items()
        }
        if actual_subject_splits != expected:
            raise ValueError(
                "受试者划分不符合基准方案：\n"
                f"  期望：{expected}\n"
                f"  实际：{actual_subject_splits}"
            )
        summary["subject_splits"] = actual_subject_splits
        metadata = _metadata_from_archive(archive)
        if metadata is None:
            raise ValueError("dynamic_v2正式数据必须包含metadata_json")
        dataset_version = metadata.get("dataset_version")
        body_frame_mode = metadata.get("target_definition", {}).get("body_frame_mode")
        if dataset_version != "dynamic_body_frame_v2" or body_frame_mode != "per_frame_dynamic":
            raise ValueError(
                "当前正式训练只接受动态身体坐标v2："
                f"dataset_version={dataset_version!r}, body_frame_mode={body_frame_mode!r}"
            )
        summary["dataset_version"] = dataset_version
        summary["body_frame_mode"] = body_frame_mode

    return summary


def _real_config(config_path: Path) -> dict[str, Any]:
    config = load_config(config_path)
    if str(config["data"].get("kind", "")).lower() != "prepared_npz":
        raise ValueError("正式基准配置的 data.kind 必须是 prepared_npz")
    if str(config["model"].get("type", "")).lower() != "dual_branch":
        raise ValueError("正式基准模型必须是 dual_branch，不能在基准中加入 FFT/拉普拉斯")
    _validate_output_root(config)
    return config


def _print_summary(summary: dict[str, Any]) -> None:
    print("\n数据预检查通过")
    print(f"数据文件：{summary['path']}")
    for split in ("train", "val", "test"):
        row = summary["splits"][split]
        print(
            f"{split:>5}: N={row['samples']}, sEMG={row['semg_shape']}, "
            f"IMU={row['imu_shape']}, XYZ={row['target_shape']}"
        )
    print(f"受试者划分：{summary['subject_splits']}")
    print(
        f"标签版本：{summary['dataset_version']} / "
        f"{summary['body_frame_mode']}"
    )


def main() -> None:
    _configure_console()
    parser = argparse.ArgumentParser(
        description="调用 NNtrain 的双分支模型运行 ULTRA-MoCap 基准测试"
    )
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument(
        "--check-only",
        action="store_true",
        help="只检查正式 NPZ，不开始训练",
    )
    parser.add_argument(
        "--smoke",
        action="store_true",
        help="用小型合成数据验证代码调用链；结果不能作为正式实验",
    )
    args = parser.parse_args()

    if args.smoke:
        if args.check_only:
            parser.error("--smoke 和 --check-only 不能同时使用")
        config = load_config(DEFAULT_SMOKE_CONFIG)
        config["run"]["name"] = "baseline_invocation_smoke_not_an_experiment"
        config["run"]["output_root"] = "BaselineTest_Mocap/outputs/smoke"
        config["model"]["type"] = "dual_branch"
        _validate_output_root(config)
        _add_run_timestamp(config)
        print("警告：当前运行的是合成数据冒烟测试，不是 ULTRA-MoCap 正式基准。")
        run_training(config)
        return

    config = _real_config(args.config.resolve())
    data_config = config["data"]
    dataset_path = resolve_project_path(data_config["path"])
    summary = validate_prepared_dataset(
        dataset_path,
        window_steps=int(data_config["window_steps"]),
        semg_channels=int(data_config["semg_channels"]),
        imu_channels=int(data_config["imu_channels"]),
        output_dim=int(data_config["output_dim"]),
    )
    _print_summary(summary)
    if args.check_only:
        print("仅检查模式结束，没有训练模型。")
        return

    run_name = _add_run_timestamp(config)
    print(f"\n开始正式基准：{run_name}，dual_branch，seed=42，Huber Loss。")
    result = run_training(config)
    print("\n基准测试完成，主要输出：")
    for name, path in result["paths"].items():
        print(f"  {name}: {path}")


if __name__ == "__main__":
    try:
        main()
    except (OSError, KeyError, TypeError, ValueError) as exc:
        _configure_console()
        print(f"\n基准测试未启动：{exc}", file=sys.stderr)
        raise SystemExit(2) from None
