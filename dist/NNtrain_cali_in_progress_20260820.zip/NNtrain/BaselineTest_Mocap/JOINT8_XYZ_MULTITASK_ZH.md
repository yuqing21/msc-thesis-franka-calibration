# ULTRA-MoCap 8角度＋XYZ联合监督实验

## 实验定义

输入保持ULTRA-MoCap全部3路sEMG和6个六轴IMU，监督输出改为窗口末帧8个
OpenSim IK角度：`SC_y`、`SC_x`、`SC_z`、`arm_flex_r`、`arm_add_r`、
`arm_rot_r`、`elbow_flex_r`和`pro_sup_r`。同一帧的Vicon腕部身体坐标
`(RRAD + RULN) / 2`作为第二监督目标。

训练集、验证集、测试集继续按P01–P09、P10–P11、P12–P13划分。500 ms窗口，
250 ms步长，共26,739/6,447/5,220个窗口。所有标准化器仅在训练受试者上拟合。

## 模型和损失

双分支CNN-GRU分别编码sEMG `[B,50,3]` 和IMU `[B,50,36]`。每个分支使用
两层Conv1d（64通道）、一层96隐藏单元GRU和128维投影；融合后通过256→256→128→8
回归头输出标准化角度。参数量256,204。

预测角度反标准化为度，再通过受试者缩放OpenSim模型参数构成的可微FK层生成腕部
XYZ。联合损失为：

```text
0.4 × Huber(标准化预测角度, 标准化IK角度)
+ 0.6 × Huber(标准化FK腕部XYZ, 标准化Vicon腕部XYZ)
```

角度与XYZ分别用训练集均值/标准差标准化后再加权，避免“度”和“米”的数值尺度
直接决定损失权重。FK允许右侧胸锁3角、肩3角、肘屈伸和旋前旋后变化；躯干、
左侧胸锁和腕关节固定在模型零位，测试帧未注入这些额外真实角度。

## 正式训练结果（seed 42）

配置：Adam，batch 32，初始学习率0.0005，weight decay 0.0001，最多100轮，
patience 15。最佳epoch 12，epoch 27早停，RTX 4070 Laptop GPU训练347.97秒。

| 角度 | MAE (deg) | RMSE (deg) | Pearson r |
|---|---:|---:|---:|
| SC_y | 7.502 | 9.405 | 0.842 |
| SC_x | 6.943 | 8.984 | 0.877 |
| SC_z | 8.312 | 10.623 | 0.607 |
| arm_flex_r | 14.754 | 20.261 | 0.910 |
| arm_add_r | 12.980 | 16.443 | 0.617 |
| arm_rot_r | 23.000 | 27.185 | 0.761 |
| elbow_flex_r | 14.012 | 19.161 | 0.888 |
| pro_sup_r | 17.868 | 22.586 | 0.854 |
| 8维平均 | 13.171 | 17.955 | 0.794 |

| 轨迹结果 | 平均欧氏误差 (cm) | 欧氏RMSE (cm) | 中位数 (cm) | P95 (cm) |
|---|---:|---:|---:|---:|
| 真实8角度→FK（Oracle） | 6.135 | 6.715 | 5.929 | 11.233 |
| 网络8角度→FK | 13.972 | 17.389 | 11.373 | 33.340 |
| 原直接XYZ基线 | 17.271 | — | 15.134 | — |
| 原真实4角度→FK（Oracle） | 16.113 | 17.666 | 15.281 | 28.943 |
| 原网络4角度→FK | 18.652 | 21.126 | 17.475 | 36.599 |

8角度Oracle相对4角度Oracle降低9.98 cm（61.9%）；网络FK相对原直接XYZ基线
降低3.30 cm（19.1%），相对4角度网络FK降低4.68 cm（25.1%）。因此增加胸锁运动
和旋前旋后并用XYZ联合监督是有效的，但网络预测与6.13 cm的表示下限之间仍有明显
差距，主要角度短板是肩内旋/外旋和前臂旋前旋后。

## 文件

- 配置：`BaselineTest_Mocap/joint8_xyz_multitask_ultra_mocap.yaml`
- 数据：`BaselineTest_Mocap/data/ultra_full_joint8_xyz_v1.npz`
- 审计：`BaselineTest_Mocap/data/ultra_full_joint8_xyz_v1_audit.json`
- 指标：`BaselineTest_Mocap/outputs/formal/joint8_xyz_multitask_v1/metrics/ultra_mocap_joint8_xyz_multitask_v1_dual_branch_test.json`
- 权重：`BaselineTest_Mocap/outputs/formal/joint8_xyz_multitask_v1/checkpoints/ultra_mocap_joint8_xyz_multitask_v1_dual_branch_best.pt`
