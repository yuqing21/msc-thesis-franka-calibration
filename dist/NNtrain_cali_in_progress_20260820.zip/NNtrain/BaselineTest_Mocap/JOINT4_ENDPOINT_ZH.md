# ULTRA-MoCap 四关节角 Endpoint 模式

该模式固定原有 P01–P09 / P10–P11 / P12–P13 受试者划分、500 ms 窗口、
250 ms 步长和双分支 CNN-GRU，只把监督目标从腕部 XYZ 改为 OpenSim `Raw IK`
中的窗口末帧四关节角：

1. `arm_flex_r`；
2. `arm_add_r`；
3. `arm_rot_r`；
4. `elbow_flex_r`。

## 重构数据集

```powershell
Set-Location F:\bishe_ai_project\NNtrain
.\.venv\Scripts\python.exe scripts\prepare_ultra_mocap.py --target-kind joint4_endpoint
```

输出：

- `BaselineTest_Mocap/data/ultra_full_joint4_endpoint_v1.npz`；
- `BaselineTest_Mocap/data/ultra_full_joint4_endpoint_v1_audit.json`。

MOT按时间与传感器覆盖范围内的Vicon帧精确匹配。原始数据中8条trial的MOT
覆盖短于TRC，共有范围外923帧被排除；3条MOT的声明行数与实际行数不同，构建器
记录两者并以实际连续数据为准。四个角度在全部有效trial中均无大于180度的跳变。

## 训练

```powershell
.\.venv\Scripts\python.exe scripts\train.py `
  --config BaselineTest_Mocap\joint4_endpoint_ultra_mocap.yaml
```

本次 seed 42 结果：最佳epoch 11，epoch 21早停，训练95.53秒。

| 关节角 | MAE (deg) | RMSE (deg) | Pearson r |
|---|---:|---:|---:|
| arm_flex_r | 13.551 | 18.409 | 0.925 |
| arm_add_r | 10.186 | 13.601 | 0.682 |
| arm_rot_r | 21.645 | 27.794 | 0.660 |
| elbow_flex_r | 15.243 | 20.354 | 0.884 |
| 四维平均 | 15.156 | 20.680 | 0.788 |

训练均值常数基线的四维平均MAE为30.701度。当前模式验证了关节角标签和完整
训练链路，但仍是窗口末帧回归，不是最终的序列轨迹teacher。前向运动学腕部
XYZ重建结果如下。

## 前向运动学与 Vicon 对比

评估使用 P12–P13 的5220个测试窗口、每位受试者缩放后的 OpenSim 模型以及
与原XYZ任务相同的 Vicon 腕部定义 `(RRAD + RULN) / 2`。只允许上述4个肩肘
角度变化；躯干、胸锁关节、前臂旋前旋后和腕关节均固定在模型零位，未向4自由度
结果注入测试帧的其他真实角度。

| 结果 | 平均欧氏误差 (cm) | 欧氏RMSE (cm) | 中位数 (cm) | P95 (cm) |
|---|---:|---:|---:|---:|
| 真实4角度 → FK（Oracle） | 16.113 | 17.666 | 15.281 | 28.943 |
| 网络4角度 → FK | 18.652 | 21.126 | 17.475 | 36.599 |

因此当前关节角路线没有超过直接XYZ基线的17.27 cm：网络FK比它高1.38 cm。
更重要的是，Oracle已经达到16.11 cm，表明只保留4个盂肱/肘角且固定肩胛带的
表示误差很大。作为实现校验，额外把测试帧真实胸锁角和旋前旋后角送入FK时，
误差降至4.64 cm；该数值使用了测试真值，只是sanity check，不能当作模型成绩。

可复现脚本：`BaselineTest_Mocap/diagnostics/evaluate_joint4_fk.py`；完整分受试者、
分动作指标和逐窗口坐标保存在正式输出目录的 `fk_evaluation` 子目录。
