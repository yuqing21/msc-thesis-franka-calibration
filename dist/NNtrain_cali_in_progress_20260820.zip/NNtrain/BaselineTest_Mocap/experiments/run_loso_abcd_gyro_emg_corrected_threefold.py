from __future__ import annotations

import csv
import json
import sys
import time
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
import torch
import yaml
from torch import nn
from torch.utils.data import DataLoader


ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))

from bishe_ai.data.datasets import MultimodalWindowDataset
from bishe_ai.data.loso import JOINT3_NAMES, load_joint3_loso_fold
from bishe_ai.evaluation.metrics import regression_metrics
from bishe_ai.models import build_model
from bishe_ai.models.regressors import IMUCoarseEMGResidualRegressor, TemporalEncoder
from bishe_ai.training import evaluate, fit
from bishe_ai.utils import choose_device, seed_everything


# Requires BaselineTest_Mocap/data/ultra_full_joint8_xyz_v2_gyrobias_emgnorm.npz to exist first:
#   python BaselineTest_Mocap/prepare_ultra_mocap.py --target-kind joint8_xyz \
#     --gyro-bias-correction --semg-trial-normalization \
#     --output BaselineTest_Mocap/data/ultra_full_joint8_xyz_v2_gyrobias_emgnorm.npz \
#     --audit-output BaselineTest_Mocap/data/ultra_full_joint8_xyz_v2_gyrobias_emgnorm_audit.json
SOURCE = ROOT / "BaselineTest_Mocap" / "data" / "ultra_full_joint8_xyz_v2_gyrobias_emgnorm.npz"
OUTPUT = ROOT / "BaselineTest_Mocap" / "outputs" / "loso_abcd_gyro_emg_corrected"
FOLDS = ("P11", "P12", "P13")
IMU_CHANNELS = 36
SEMG_CHANNELS = 3
MODEL_CONFIG = {"conv_channels": 64, "gru_hidden": 96, "feature_dim": 128, "dropout": 0.2}
TRAINING_CONFIG = {
    "batch_size": 32,
    "epochs": 100,
    "learning_rate": 0.0005,
    "weight_decay": 0.0001,
    "loss": "huber",
    "early_stopping_patience": 15,
}
# final_loss and residual_loss are algebraically identical for y_final = y_coarse + delta.
# Keep the latter only as a diagnostic; optimizing both would only rescale the same gradient.
LAMBDA_RESIDUAL = 0.0
STANDARD_MODELS = {
    "A_imu_only": "imu_only",
    "B_emg_only": "semg_only",
    "C_concat_fusion": "dual_branch",
}


def _json_ready(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): _json_ready(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_ready(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, Path):
        return str(value)
    return value


def _write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(_json_ready(value), indent=2, ensure_ascii=False), encoding="utf-8")


def _write_yaml(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(_json_ready(value), allow_unicode=True, sort_keys=False), encoding="utf-8")


def _loaders(arrays: dict[str, np.ndarray]) -> tuple[dict[str, MultimodalWindowDataset], dict[str, DataLoader]]:
    datasets = {
        split: MultimodalWindowDataset(
            arrays[f"semg_{split}"], arrays[f"imu_{split}"], arrays[f"target_{split}"]
        )
        for split in ("train", "val", "test")
    }
    return datasets, {
        "train": DataLoader(datasets["train"], batch_size=32, shuffle=True),
        "val": DataLoader(datasets["val"], batch_size=32, shuffle=False),
        "test": DataLoader(datasets["test"], batch_size=32, shuffle=False),
    }


def _checkpoint_config(experiment: str, fold: str, split: dict[str, Any], model: dict[str, Any]) -> dict[str, Any]:
    return {
        "run": {"name": experiment, "seed": 42, "fold": fold},
        "data": {
            "source": SOURCE,
            "train_subjects": split["train"],
            "validation_subjects": split["val"],
            "test_subject": split["test"],
            "normalization": "fitted on training subjects only",
            "joint_names": JOINT3_NAMES,
            "gyro_bias_correction": True,
            "semg_trial_normalization": True,
        },
        "model": model,
        "training": {
            **TRAINING_CONFIG,
            "lambda_residual": LAMBDA_RESIDUAL,
            "residual_loss_role": "diagnostic_only; final Huber is the sole optimization objective",
        },
    }


def _train_standard(
    name: str,
    model_type: str,
    fold: str,
    split: dict[str, Any],
    loaders: dict[str, DataLoader],
    preprocessing: dict[str, np.ndarray],
    device: torch.device,
) -> dict[str, Any]:
    fold_dir = OUTPUT / name / fold
    checkpoint = fold_dir / "best.pt"
    existing_metrics = fold_dir / "metrics.json"
    if checkpoint.is_file() and existing_metrics.is_file():
        print(f"{fold}: reusing completed {name}", flush=True)
        return json.loads(existing_metrics.read_text(encoding="utf-8"))
    model_config = {"type": model_type, **MODEL_CONFIG}
    model = build_model(model_config, 3, IMU_CHANNELS, SEMG_CHANNELS).to(device)
    parameters = sum(p.numel() for p in model.parameters() if p.requires_grad)
    config = _checkpoint_config(name, fold, split, model_config)
    history, seconds = fit(
        model, loaders["train"], loaders["val"], TRAINING_CONFIG, device, checkpoint, config, preprocessing
    )
    metrics, y_true, y_pred = evaluate(
        model, loaders["test"], device, preprocessing["target_mean"], preprocessing["target_scale"]
    )
    metrics.update({
        "experiment": name,
        "fold": fold,
        "best_epoch": int(np.argmin([row["val_loss"] for row in history]) + 1),
        "training_seconds": seconds,
        "trainable_parameters": parameters,
        "joint_names": JOINT3_NAMES,
        "imu_channels": IMU_CHANNELS,
    })
    _write_json(fold_dir / "metrics.json", metrics)
    _write_yaml(fold_dir / "config.yaml", config)
    np.savez_compressed(fold_dir / "predictions.npz", y_true=y_true, y_pred=y_pred, subject=np.full(len(y_true), fold), joint_names=JOINT3_NAMES)
    with (fold_dir / "training_history.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=("epoch", "train_loss", "val_loss"))
        writer.writeheader(); writer.writerows(history)
    return metrics


def _load_teacher(checkpoint: Path, device: torch.device) -> torch.nn.Module:
    payload = torch.load(checkpoint, map_location=device, weights_only=False)
    model_config = payload["config"]["model"]
    imu_channels = payload.get("preprocessing", {}).get("imu_mean")
    imu_channels = len(imu_channels) if imu_channels is not None else IMU_CHANNELS
    semg_channels = payload.get("preprocessing", {}).get("semg_mean")
    semg_channels = len(semg_channels) if semg_channels is not None else SEMG_CHANNELS
    model = build_model(model_config, 3, imu_channels, semg_channels).to(device)
    model.load_state_dict(payload["model_state"])
    model.eval()
    for parameter in model.parameters():
        parameter.requires_grad = False
    return model


def _residual_epoch(
    model: IMUCoarseEMGResidualRegressor,
    loader: DataLoader,
    device: torch.device,
    optimizer: torch.optim.Optimizer | None,
) -> dict[str, float]:
    training = optimizer is not None
    model.train(training)
    huber = nn.HuberLoss()
    totals = {"total_loss": 0.0, "final_loss": 0.0, "residual_loss": 0.0}
    count = 0
    context = torch.enable_grad() if training else torch.inference_mode()
    with context:
        for batch in loader:
            moved = {key: value.to(device, non_blocking=True) for key, value in batch.items()}
            if optimizer:
                optimizer.zero_grad(set_to_none=True)
            final, coarse, delta = model.forward_with_components(moved)
            final_loss = huber(final, moved["target"])
            residual_loss = huber(delta, moved["target"] - coarse)
            total_loss = final_loss
            if optimizer:
                total_loss.backward()
                if any(parameter.grad is not None for parameter in model.imu_coarse_model.parameters()):
                    raise RuntimeError("Frozen IMU coarse model unexpectedly received gradients")
                optimizer.step()
            size = len(moved["target"])
            count += size
            for key, loss in (("total_loss", total_loss), ("final_loss", final_loss), ("residual_loss", residual_loss)):
                totals[key] += float(loss.detach()) * size
    return {key: value / count for key, value in totals.items()}


def _train_residual(
    fold: str,
    split: dict[str, Any],
    loaders: dict[str, DataLoader],
    preprocessing: dict[str, np.ndarray],
    teacher_checkpoint: Path,
    device: torch.device,
    smoke: bool = False,
) -> dict[str, Any]:
    name = "D_imu_coarse_emg_residual"
    fold_dir = OUTPUT / name / fold
    teacher = _load_teacher(teacher_checkpoint, device)
    model = IMUCoarseEMGResidualRegressor(
        teacher, TemporalEncoder(SEMG_CHANNELS, 64, 96, 128, 0.2), 128, 3, 0.2
    ).to(device)
    model.freeze_coarse_model()
    if any(parameter.requires_grad for parameter in model.imu_coarse_model.parameters()):
        raise RuntimeError("IMU coarse branch is not frozen")
    optimizer = torch.optim.Adam(
        [p for p in model.parameters() if p.requires_grad],
        lr=TRAINING_CONFIG["learning_rate"], weight_decay=TRAINING_CONFIG["weight_decay"]
    )
    epochs = 2 if smoke else TRAINING_CONFIG["epochs"]
    patience = 2 if smoke else TRAINING_CONFIG["early_stopping_patience"]
    config = _checkpoint_config(name, fold, split, {
        "type": "imu_coarse_emg_residual", **MODEL_CONFIG,
        "coarse_checkpoint": teacher_checkpoint,
        "coarse_frozen": True,
        "residual_input": "concat(h_emg, y_coarse)",
    })
    _write_yaml(fold_dir / "config.yaml", config)
    best_final = float("inf"); stale = 0; history: list[dict[str, float]] = []
    started = time.perf_counter()
    for epoch in range(1, epochs + 1):
        train = _residual_epoch(model, loaders["train"], device, optimizer)
        val = _residual_epoch(model, loaders["val"], device, None)
        row = {"epoch": float(epoch), **{f"train_{k}": v for k, v in train.items()}, **{f"val_{k}": v for k, v in val.items()}}
        history.append(row)
        print(f"{fold} D epoch={epoch:03d} train_total={train['total_loss']:.6f} val_final={val['final_loss']:.6f}", flush=True)
        payload = {"model_state": model.state_dict(), "optimizer_state": optimizer.state_dict(), "epoch": epoch, "best_val_final_loss": best_final, "config": config, "preprocessing": preprocessing}
        torch.save(payload, fold_dir / "last.pt")
        if val["final_loss"] < best_final:
            best_final = val["final_loss"]; stale = 0
            payload["best_val_final_loss"] = best_final
            torch.save(payload, fold_dir / "best.pt")
        else:
            stale += 1
            if stale >= patience:
                break
    seconds = time.perf_counter() - started
    best = torch.load(fold_dir / "best.pt", map_location=device, weights_only=False)
    model.load_state_dict(best["model_state"])
    model.eval()
    true_parts: list[np.ndarray] = []; coarse_parts: list[np.ndarray] = []; delta_parts: list[np.ndarray] = []; pred_delta_parts: list[np.ndarray] = []; final_parts: list[np.ndarray] = []
    with torch.inference_mode():
        for batch in loaders["test"]:
            moved = {key: value.to(device, non_blocking=True) for key, value in batch.items()}
            final, coarse, delta = model.forward_with_components(moved)
            true_parts.append(moved["target"].cpu().numpy()); coarse_parts.append(coarse.cpu().numpy()); pred_delta_parts.append(delta.cpu().numpy()); final_parts.append(final.cpu().numpy())
    y_true_norm = np.concatenate(true_parts); y_coarse_norm = np.concatenate(coarse_parts); delta_pred_norm = np.concatenate(pred_delta_parts); y_final_norm = np.concatenate(final_parts)
    delta_target_norm = y_true_norm - y_coarse_norm
    mean, scale = preprocessing["target_mean"], preprocessing["target_scale"]
    y_true = y_true_norm * scale + mean; y_coarse = y_coarse_norm * scale + mean; y_final = y_final_norm * scale + mean
    delta_target = delta_target_norm * scale; delta_pred = delta_pred_norm * scale
    final_metrics = regression_metrics(y_true, y_final)
    metrics = dict(final_metrics)
    coarse_metrics = regression_metrics(y_true, y_coarse)
    improvement = np.mean(np.abs(y_coarse - y_true), axis=0) - np.mean(np.abs(y_final - y_true), axis=0)
    correlations: list[float | None] = []
    for index in range(3):
        correlations.append(None if np.std(delta_target[:, index]) < 1e-12 or np.std(delta_pred[:, index]) < 1e-12 else float(np.corrcoef(delta_target[:, index], delta_pred[:, index])[0, 1]))
    residual_analysis = {
        "coarse_metrics": coarse_metrics,
        "final_metrics": final_metrics,
        "correction_success_rate": float(np.mean(np.abs(y_true - y_final) < np.abs(y_true - y_coarse))),
        "correction_success_rate_per_joint": np.mean(np.abs(y_true - y_final) < np.abs(y_true - y_coarse), axis=0),
        "mae_improvement_degree_per_joint": improvement,
        "delta_rmse_degree_per_joint": np.sqrt(np.mean((delta_pred - delta_target) ** 2, axis=0)),
        "delta_pearson_per_joint": correlations,
    }
    metrics.update({"experiment": name, "fold": fold, "best_epoch": int(best["epoch"]), "training_seconds": seconds, "joint_names": JOINT3_NAMES, "coarse_checkpoint": teacher_checkpoint, "coarse_frozen": True, "lambda_residual": LAMBDA_RESIDUAL, "residual_analysis": residual_analysis})
    _write_json(fold_dir / "metrics.json", metrics)
    _write_json(fold_dir / "residual_analysis.json", residual_analysis)
    np.savez_compressed(fold_dir / "predictions_residual.npz", y_true=y_true, y_coarse=y_coarse, delta_target=delta_target, delta_pred=delta_pred, y_final=y_final, subject=np.full(len(y_true), fold), joint_names=JOINT3_NAMES)
    with (fold_dir / "training_history.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(history[0]))
        writer.writeheader(); writer.writerows(history)
    return metrics


def _summary(results: dict[str, dict[str, dict[str, Any]]]) -> None:
    summary = OUTPUT / "summary"; summary.mkdir(parents=True, exist_ok=True)
    models = ("A_imu_only", "B_emg_only", "C_concat_fusion", "D_imu_coarse_emg_residual")
    rows = []
    for model in models:
        values = [results[fold][model] for fold in FOLDS]
        rows.append({
            "model": model,
            "mae_mean": float(np.mean([v["mae"] for v in values])), "mae_std": float(np.std([v["mae"] for v in values], ddof=1)),
            "rmse_mean": float(np.mean([v["rmse"] for v in values])), "rmse_std": float(np.std([v["rmse"] for v in values], ddof=1)),
            "r2_mean": float(np.mean([v["r2_mean"] for v in values])), "r2_std": float(np.std([v["r2_mean"] for v in values], ddof=1)),
            "pearson_mean": float(np.mean([v["pearson_mean"] for v in values])), "pearson_std": float(np.std([v["pearson_mean"] for v in values], ddof=1)),
        })
    with (summary / "threefold_abcd_summary.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
    _write_json(summary / "threefold_abcd_summary.json", {"per_fold": results, "summary": rows})
    plt.figure(figsize=(8, 5)); plt.bar([r["model"] for r in rows], [r["mae_mean"] for r in rows], yerr=[r["mae_std"] for r in rows], capsize=5)
    plt.ylabel("Mean MAE across 3 folds (degree)"); plt.xticks(rotation=15, ha="right"); plt.tight_layout(); plt.savefig(summary / "threefold_mean_mae.png", dpi=180); plt.close()
    lines = ["# 三折 A/B/C/D 陀螺仪偏置校正 + sEMG 归一化实验", "", "> P11、P12、P13 三个未知受试者折；数据来自陀螺仪静息偏置校正 + trial 内 sEMG log1p/MAD 归一化后重新生成的原始数据集，全部三折均从头训练（不复用旧数据集上的权重）。", "", "| 模型 | MAE mean ± SD | RMSE mean ± SD | R² mean ± SD | Pearson r mean ± SD |", "|---|---:|---:|---:|---:|"]
    for row in rows:
        lines.append(f"| {row['model']} | {row['mae_mean']:.3f} ± {row['mae_std']:.3f}° | {row['rmse_mean']:.3f} ± {row['rmse_std']:.3f}° | {row['r2_mean']:.3f} ± {row['r2_std']:.3f} | {row['pearson_mean']:.3f} ± {row['pearson_std']:.3f} |")
    (summary / "threefold_abcd_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    if not SOURCE.is_file():
        raise FileNotFoundError(
            f"Missing corrected dataset: {SOURCE}\n"
            "Regenerate it first with:\n"
            "  python BaselineTest_Mocap/prepare_ultra_mocap.py --target-kind joint8_xyz "
            "--gyro-bias-correction --semg-trial-normalization "
            f"--output {SOURCE} --audit-output {SOURCE.with_name(SOURCE.stem + '_audit.json')}"
        )
    OUTPUT.mkdir(parents=True, exist_ok=True)
    device = choose_device("auto")
    results: dict[str, dict[str, dict[str, Any]]] = {}
    for fold in FOLDS:
        seed_everything(42)
        arrays, preprocessing, split = load_joint3_loso_fold(SOURCE, fold)
        _write_json(OUTPUT / "splits" / f"{fold}_split.json", {"fold": fold, **split, "window_counts": {s: len(arrays[f"target_{s}"]) for s in ("train", "val", "test")}})
        _, loaders = _loaders(arrays)
        results[fold] = {}
        for name, model_type in STANDARD_MODELS.items():
            print(f"{fold}: training {name}", flush=True)
            seed_everything(42)
            results[fold][name] = _train_standard(name, model_type, fold, split, loaders, preprocessing, device)
        teacher_checkpoint = OUTPUT / "A_imu_only" / fold / "best.pt"
        print(f"{fold}: smoke-testing frozen residual D", flush=True)
        seed_everything(42)
        _train_residual(fold, split, loaders, preprocessing, teacher_checkpoint, device, smoke=True)
        print(f"{fold}: training D_imu_coarse_emg_residual", flush=True)
        seed_everything(42)
        results[fold]["D_imu_coarse_emg_residual"] = _train_residual(fold, split, loaders, preprocessing, teacher_checkpoint, device)
    _summary(results)


if __name__ == "__main__":
    main()
