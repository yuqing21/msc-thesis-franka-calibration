"""Select a Joint3 checkpoint ensemble on validation data, then report test metrics."""

from __future__ import annotations

import itertools
import json
import sys
from pathlib import Path

import numpy as np
import torch

NNTRAIN_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(NNTRAIN_ROOT / "src"))

from bishe_ai.evaluation.metrics import regression_metrics
from bishe_ai.models import build_model


ROOT = NNTRAIN_ROOT / "BaselineTest_Mocap"
DATASET = ROOT / "data" / "ultra_joint3_shoulder_elbow_v1.npz"
CHECKPOINTS = {
    "seed42": ROOT
    / "outputs"
    / "experiments"
    / "joint3_shoulder_elbow_dual_branch_v1"
    / "checkpoints"
    / "ultra_mocap_joint3_shoulder_elbow_dual_branch_v1_dual_branch_best.pt",
    "seed7": ROOT
    / "outputs"
    / "experiments"
    / "joint3_shoulder_elbow_ensemble_v1"
    / "seed7"
    / "checkpoints"
    / "ultra_mocap_joint3_shoulder_elbow_dual_branch_seed7_dual_branch_best.pt",
    "seed2026": ROOT
    / "outputs"
    / "experiments"
    / "joint3_shoulder_elbow_ensemble_v1"
    / "seed2026"
    / "checkpoints"
    / "ultra_mocap_joint3_shoulder_elbow_dual_branch_seed2026_dual_branch_best.pt",
}
OUTPUT = ROOT / "outputs" / "experiments" / "joint3_shoulder_elbow_ensemble_v1" / "ensemble_selection.json"


def predict(checkpoint: Path, semg: np.ndarray, imu: np.ndarray, device: torch.device) -> np.ndarray:
    payload = torch.load(checkpoint, map_location=device, weights_only=False)
    config = payload["config"]
    model = build_model(
        config["model"],
        semg_channels=semg.shape[-1],
        imu_channels=imu.shape[-1],
        output_dim=3,
    ).to(device)
    model.load_state_dict(payload["model_state"])
    model.eval()
    outputs: list[np.ndarray] = []
    with torch.inference_mode():
        for start in range(0, len(semg), 256):
            stop = min(start + 256, len(semg))
            batch = {
                "semg": torch.from_numpy(semg[start:stop]).to(device),
                "imu": torch.from_numpy(imu[start:stop]).to(device),
            }
            outputs.append(model(batch).cpu().numpy())
    return np.concatenate(outputs, axis=0)


def metrics(target: np.ndarray, prediction: np.ndarray) -> dict[str, object]:
    value = regression_metrics(target, prediction)
    return {key: float(item) if isinstance(item, np.floating) else item for key, item in value.items()}


def main() -> None:
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    with np.load(DATASET, allow_pickle=False) as data:
        mean = data["target_mean"]
        scale = data["target_scale"]
        values = {
            split: {
                "semg": data[f"semg_{split}"],
                "imu": data[f"imu_{split}"],
                "target": data[f"target_{split}"] * scale + mean,
            }
            for split in ("val", "test")
        }

    prediction = {
        name: {
            split: predict(path, values[split]["semg"], values[split]["imu"], device) * scale + mean
            for split in ("val", "test")
        }
        for name, path in CHECKPOINTS.items()
    }

    names = tuple(CHECKPOINTS)
    candidates: dict[str, dict[str, object]] = {}
    for size in range(1, len(names) + 1):
        for subset in itertools.combinations(names, size):
            name = "+".join(subset)
            candidates[name] = {
                split: metrics(
                    values[split]["target"],
                    np.mean([prediction[member][split] for member in subset], axis=0),
                )
                for split in ("val", "test")
            }

    selected = min(candidates, key=lambda name: float(candidates[name]["val"]["mae"]))
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    result = {
        "selection_split": "val",
        "selection_metric": "mean joint-angle MAE in degrees",
        "selection_rule": "equal-weight average over every non-empty checkpoint subset",
        "selected_candidate": selected,
        "candidates": candidates,
        "checkpoints": {name: str(path) for name, path in CHECKPOINTS.items()},
    }
    OUTPUT.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
