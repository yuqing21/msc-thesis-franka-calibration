from __future__ import annotations

import csv
import json
import sys
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
import torch
from torch.utils.data import DataLoader


ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))

from bishe_ai.data.datasets import MultimodalWindowDataset
from bishe_ai.data.loso import JOINT3_NAMES, load_joint3_loso_fold
from bishe_ai.models import build_model
from bishe_ai.training import evaluate, fit
from bishe_ai.utils import choose_device, seed_everything


SOURCE = ROOT / "BaselineTest_Mocap" / "data" / "ultra_full_joint8_xyz_v1.npz"
OUTPUT = ROOT / "BaselineTest_Mocap" / "outputs" / "loso_abcd_fast_p13"
MODEL_TYPES = {
    "A_imu_only": "imu_only",
    "B_emg_only": "semg_only",
    "C_concat_fusion": "dual_branch",
    "D_imu_guided_emg_gate": "imu_guided_emg_gate",
}
MODEL_CONFIG = {
    "conv_channels": 64,
    "gru_hidden": 96,
    "feature_dim": 128,
    "dropout": 0.2,
}
TRAINING_CONFIG = {
    "batch_size": 32,
    "epochs": 100,
    "learning_rate": 0.0005,
    "weight_decay": 0.0001,
    "loss": "huber",
    "early_stopping_patience": 15,
}


def _json_ready(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): _json_ready(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_ready(item) for item in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, Path):
        return str(value)
    return value


def _write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(_json_ready(value), indent=2, ensure_ascii=False), encoding="utf-8")


def _gate_statistics(model: torch.nn.Module, loader: DataLoader, device: torch.device) -> dict[str, Any]:
    gates: list[np.ndarray] = []
    model.eval()
    with torch.inference_mode():
        for batch in loader:
            moved = {key: value.to(device) for key, value in batch.items()}
            _, gate = model.forward_with_gate(moved)
            gates.append(gate.cpu().numpy())
    values = np.concatenate(gates)
    sample_means = values.mean(axis=1)
    return {
        "gate_mean": float(values.mean()),
        "gate_std": float(values.std()),
        "gate_min": float(values.min()),
        "gate_max": float(values.max()),
        "fraction_below_0p1": float(np.mean(values < 0.1)),
        "fraction_above_0p9": float(np.mean(values > 0.9)),
        "sample_mean_std": float(sample_means.std()),
        "mean_per_latent_dimension": values.mean(axis=0),
        "std_per_latent_dimension": values.std(axis=0),
    }


def main() -> None:
    arrays, preprocessing, split = load_joint3_loso_fold(SOURCE, test_subject="P13")
    OUTPUT.mkdir(parents=True, exist_ok=True)
    split_payload = {
        "experiment_scope": "fast_single_fold_preliminary_ablation",
        "seed": 42,
        "test_subject": split["test"],
        "validation_subjects": split["val"],
        "train_subjects": split["train"],
        "window_counts": {name: int(len(arrays[f"target_{name}"])) for name in ("train", "val", "test")},
        "joint_names": JOINT3_NAMES,
        "source": SOURCE,
        "normalization": "fit on the 10 training subjects only",
    }
    _write_json(OUTPUT / "splits" / "P13_split.json", split_payload)
    print(json.dumps(_json_ready(split_payload), indent=2, ensure_ascii=False))

    datasets = {
        name: MultimodalWindowDataset(
            arrays[f"semg_{name}"], arrays[f"imu_{name}"], arrays[f"target_{name}"]
        )
        for name in ("train", "val", "test")
    }
    device = choose_device("auto")
    results: dict[str, dict[str, Any]] = {}

    for experiment, model_type in MODEL_TYPES.items():
        seed_everything(42)
        loaders = {
            "train": DataLoader(datasets["train"], batch_size=32, shuffle=True),
            "val": DataLoader(datasets["val"], batch_size=32, shuffle=False),
            "test": DataLoader(datasets["test"], batch_size=32, shuffle=False),
        }
        model_config = {"type": model_type, **MODEL_CONFIG}
        model = build_model(model_config, semg_channels=3, imu_channels=36, output_dim=3).to(device)
        parameter_count = sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad)
        fold_dir = OUTPUT / experiment / "P13"
        fold_dir.mkdir(parents=True, exist_ok=True)
        full_config = {
            "run": {"name": experiment, "seed": 42, "scope": "P13 preliminary single fold"},
            "data": split_payload,
            "model": model_config,
            "training": {**TRAINING_CONFIG, "device": str(device)},
        }
        print(f"\n=== {experiment} ({model_type}), parameters={parameter_count:,} ===")
        history, training_seconds = fit(
            model,
            loaders["train"],
            loaders["val"],
            TRAINING_CONFIG,
            device,
            fold_dir / "best.pt",
            full_config,
            preprocessing,
        )
        metrics, y_true, y_pred = evaluate(
            model,
            loaders["test"],
            device,
            target_mean=preprocessing["target_mean"],
            target_scale=preprocessing["target_scale"],
        )
        metrics.update(
            {
                "experiment": experiment,
                "test_subject": "P13",
                "training_seconds": training_seconds,
                "best_epoch": int(np.argmin([row["val_loss"] for row in history]) + 1),
                "trainable_parameters": parameter_count,
                "joint_names": JOINT3_NAMES,
            }
        )
        _write_json(fold_dir / "metrics.json", metrics)
        _write_json(fold_dir / "config.json", full_config)
        with (fold_dir / "training_history.csv").open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=("epoch", "train_loss", "val_loss"))
            writer.writeheader()
            writer.writerows(history)
        np.savez_compressed(
            fold_dir / "predictions.npz",
            y_true=y_true.astype(np.float32),
            y_pred=y_pred.astype(np.float32),
            subject=np.full(len(y_true), "P13"),
            joint_names=np.asarray(JOINT3_NAMES),
        )
        if model_type == "imu_guided_emg_gate":
            gate_stats = _gate_statistics(model, loaders["test"], device)
            _write_json(fold_dir / "gate_statistics.json", gate_stats)
            metrics["gate_statistics"] = gate_stats
        results[experiment] = metrics

    summary_dir = OUTPUT / "summary"
    summary_dir.mkdir(parents=True, exist_ok=True)
    _write_json(summary_dir / "p13_abcd_summary.json", results)
    fields = [
        "model", "arm_flex_mae", "arm_add_mae", "elbow_flex_mae", "mean_mae",
        "mean_rmse", "mean_r2", "mean_pearson", "best_epoch", "training_seconds", "parameters",
    ]
    rows = []
    for name, metrics in results.items():
        rows.append(
            {
                "model": name,
                "arm_flex_mae": metrics["mae_per_dim"][0],
                "arm_add_mae": metrics["mae_per_dim"][1],
                "elbow_flex_mae": metrics["mae_per_dim"][2],
                "mean_mae": metrics["mae"],
                "mean_rmse": metrics["rmse"],
                "mean_r2": metrics["r2_mean"],
                "mean_pearson": metrics["pearson_mean"],
                "best_epoch": metrics["best_epoch"],
                "training_seconds": metrics["training_seconds"],
                "parameters": metrics["trainable_parameters"],
            }
        )
    with (summary_dir / "p13_abcd_summary.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

    labels = list(results)
    values = [results[name]["mae"] for name in labels]
    plt.figure(figsize=(9, 5))
    bars = plt.bar(labels, values, color=("#4472C4", "#ED7D31", "#70AD47", "#A64D79"))
    plt.ylabel("P13 mean MAE (degree)")
    plt.title("Preliminary single-fold A/B/C/D comparison")
    plt.xticks(rotation=15, ha="right")
    for bar, value in zip(bars, values, strict=True):
        plt.text(bar.get_x() + bar.get_width() / 2, value, f"{value:.2f}°", ha="center", va="bottom")
    plt.tight_layout()
    plt.savefig(summary_dir / "p13_mean_mae_comparison.png", dpi=180)
    plt.close()

    report_lines = [
        "# P13 单折 A/B/C/D 初步消融结果",
        "",
        "> 这是以 P13 为唯一未知测试受试者的快速初步实验，不是完整 13 折 LOSO 结果。",
        "",
        f"训练受试者：{', '.join(split['train'])}",
        f"验证受试者：{', '.join(split['val'])}",
        "测试受试者：P13",
        "",
        "| 模型 | Mean MAE | Mean RMSE | Mean R² | Mean Pearson r |",
        "|---|---:|---:|---:|---:|",
    ]
    for name, metrics in results.items():
        report_lines.append(
            f"| {name} | {metrics['mae']:.3f}° | {metrics['rmse']:.3f}° | "
            f"{metrics['r2_mean']:.4f} | {metrics['pearson_mean']:.4f} |"
        )
    (summary_dir / "p13_abcd_report.md").write_text("\n".join(report_lines) + "\n", encoding="utf-8")
    print(json.dumps(_json_ready(results), indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
