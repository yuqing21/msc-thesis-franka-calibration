from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Any


EXPERIMENT_ROOT = Path(__file__).resolve().parent
BASELINE_ROOT = EXPERIMENT_ROOT.parents[1]
NNTRAIN_ROOT = BASELINE_ROOT.parent
NNTRAIN_SRC = NNTRAIN_ROOT / "src"
OUTPUT_ROOT = BASELINE_ROOT / "outputs" / "experiments" / "attention_gated_axis_heads"
CONFIGS = (
    (0.1, EXPERIMENT_ROOT / "dropout_0p1.yaml"),
    (0.2, EXPERIMENT_ROOT / "dropout_0p2.yaml"),
    (0.3, EXPERIMENT_ROOT / "dropout_0p3.yaml"),
)

sys.path.insert(0, str(NNTRAIN_SRC))
sys.path.insert(0, str(BASELINE_ROOT))

from bishe_ai.config import load_config, resolve_project_path  # noqa: E402
from bishe_ai.pipeline import run_training  # noqa: E402
from run_baseline import validate_prepared_dataset  # noqa: E402


def _configure_console() -> None:
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if callable(reconfigure):
            reconfigure(encoding="utf-8", errors="replace")


def _json_ready(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {str(key): _json_ready(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_ready(item) for item in value]
    return value


def _validate_config(config: dict[str, Any], expected_dropout: float) -> None:
    if str(config["model"].get("type", "")) != "attention_gated_axis_heads":
        raise ValueError("模型必须是 attention_gated_axis_heads")
    actual_dropout = float(config["model"].get("dropout", -1.0))
    if abs(actual_dropout - expected_dropout) > 1e-12:
        raise ValueError(
            f"Dropout配置错误：期望 {expected_dropout}，实际 {actual_dropout}"
        )
    if int(config["run"].get("seed", -1)) != 42:
        raise ValueError("Dropout对照实验必须统一使用seed=42")
    output = resolve_project_path(config["run"]["output_root"]).resolve()
    allowed = OUTPUT_ROOT.resolve()
    if output != allowed and allowed not in output.parents:
        raise ValueError(f"实验输出必须保存在 {allowed} 内，实际为 {output}")


def main() -> None:
    _configure_console()
    parser = argparse.ArgumentParser(
        description="Run the attention-gated-axis-heads Dropout sweep"
    )
    parser.add_argument(
        "--check-only",
        action="store_true",
        help="Validate all configs and the dynamic_v2 dataset without training",
    )
    args = parser.parse_args()
    sweep_stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    prepared_configs: list[tuple[float, Path, dict[str, Any]]] = []
    for dropout, path in CONFIGS:
        config = load_config(path)
        _validate_config(config, dropout)
        config["run"]["name"] = f"{config['run']['name']}_{sweep_stamp}"
        prepared_configs.append((dropout, path, config))

    data_config = prepared_configs[0][2]["data"]
    dataset_path = resolve_project_path(data_config["path"])
    dataset_summary = validate_prepared_dataset(
        dataset_path,
        window_steps=int(data_config["window_steps"]),
        semg_channels=int(data_config["semg_channels"]),
        imu_channels=int(data_config["imu_channels"]),
        output_dim=int(data_config["output_dim"]),
    )
    if args.check_only:
        print("三套配置和动态坐标v2数据检查通过；仅检查模式，没有训练模型。")
        return
    print("动态坐标v2数据检查通过，开始三组Dropout对照实验。")

    runs: list[dict[str, Any]] = []
    for index, (dropout, config_path, config) in enumerate(prepared_configs, start=1):
        print(f"\n===== 实验 {index}/3：Dropout={dropout:.1f} =====")
        result = run_training(config)
        best_row = min(result["history"], key=lambda row: row["val_loss"])
        runs.append(
            {
                "dropout": dropout,
                "config_source": str(config_path),
                "run_name": config["run"]["name"],
                "best_epoch": int(best_row["epoch"]),
                "best_val_loss": float(best_row["val_loss"]),
                "epochs_ran": len(result["history"]),
                "test_metrics": result["metrics"],
                "artifacts": result["paths"],
            }
        )

    best_run = min(runs, key=lambda row: row["best_val_loss"])
    summary = {
        "experiment": "attention_gated_axis_heads_dropout_sweep",
        "selection_rule": "lowest validation loss only",
        "dataset": dataset_summary,
        "runs": runs,
        "selected_dropout": best_run["dropout"],
        "selected_run_name": best_run["run_name"],
        "selected_checkpoint": best_run["artifacts"]["checkpoint"],
    }
    summary_path = OUTPUT_ROOT / "sweep_summaries" / f"dropout_sweep_{sweep_stamp}.json"
    summary_path.parent.mkdir(parents=True, exist_ok=True)
    summary_path.write_text(
        json.dumps(_json_ready(summary), ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print("\n===== Dropout对照完成 =====")
    for run in runs:
        metrics = run["test_metrics"]
        print(
            f"dropout={run['dropout']:.1f} best_epoch={run['best_epoch']} "
            f"best_val={run['best_val_loss']:.6f} "
            f"test_euclidean={metrics['euclidean_mean']:.6f}m"
        )
    print(
        f"按validation选择：Dropout={best_run['dropout']:.1f}，"
        f"checkpoint={best_run['artifacts']['checkpoint']}"
    )
    print(f"汇总：{summary_path}")


if __name__ == "__main__":
    main()
