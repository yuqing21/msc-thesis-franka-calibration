# Attention + Gated Fusion + Axis Heads Dropout Sweep

本实验保留 dynamic_v2 双分支基准，并新增独立模型
`attention_gated_axis_heads`：

1. 两个分支的 GRU 使用全部时间步进行注意力池化；
2. sEMG 与 IMU 特征经过可学习门控融合；
3. 共享融合层后，X、Y、Z 使用独立回归头；
4. 固定其他条件，只比较 Dropout 0.1、0.2、0.3。

运行入口：

```powershell
Set-Location F:\bishe_ai_project
.\NNtrain\BaselineTest_Mocap\experiments\attention_gated_axis_heads\run_dropout_sweep.ps1
```

模型选择只根据最低 validation loss，不根据 test 指标。三组权重、指标、曲线和
配置分别保存在：

```text
BaselineTest_Mocap/outputs/experiments/attention_gated_axis_heads/dropout_0p1/
BaselineTest_Mocap/outputs/experiments/attention_gated_axis_heads/dropout_0p2/
BaselineTest_Mocap/outputs/experiments/attention_gated_axis_heads/dropout_0p3/
```

原 `dual_branch` 模型与 `outputs/formal/dynamic_v2` 基准结果不会被覆盖。
