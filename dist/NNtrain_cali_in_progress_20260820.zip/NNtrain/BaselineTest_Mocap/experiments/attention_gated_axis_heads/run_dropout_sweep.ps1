param(
    [switch]$CheckOnly
)

$ErrorActionPreference = "Stop"
$experimentRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$baselineRoot = Split-Path -Parent (Split-Path -Parent $experimentRoot)
$nntrainRoot = Split-Path -Parent $baselineRoot
$workspaceRoot = Split-Path -Parent $nntrainRoot
$pythonPath = Join-Path $nntrainRoot ".venv\Scripts\python.exe"
$runnerPath = Join-Path $experimentRoot "run_dropout_sweep.py"

if (-not (Test-Path -LiteralPath $pythonPath -PathType Leaf)) {
    throw "NNtrain Python environment not found: $pythonPath"
}

Push-Location $workspaceRoot
try {
    $runnerArguments = @($runnerPath)
    if ($CheckOnly) {
        $runnerArguments += "--check-only"
    }
    & $pythonPath @runnerArguments
    $runnerExitCode = $LASTEXITCODE
}
finally {
    Pop-Location
}
if ($runnerExitCode -ne 0) {
    exit $runnerExitCode
}
