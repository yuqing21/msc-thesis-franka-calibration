# Baseline诊断工具和结果

- `analyze_baseline.py`：逐窗口、受试者、动作、trial、偏移、分布和滞后分析；
- `check_dynamic_body_frame.py`：Static坐标与逐帧身体坐标对照；
- `modality_ablation.yaml`：sEMG-only、IMU-only和Early Fusion消融配置；
- `evaluate_late_fusion.py`：只用validation选择sEMG/IMU晚期融合权重；
- `Baseline_v1_20260817_144111/`：本次生成的CSV、JSON、图片和诊断报告。

诊断不会修改 `fixed_results/Baseline_v1_20260817_144111` 中的冻结权重。

