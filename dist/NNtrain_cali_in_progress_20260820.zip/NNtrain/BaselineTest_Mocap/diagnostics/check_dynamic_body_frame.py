from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


DIAGNOSTICS_ROOT = Path(__file__).resolve().parent
BASELINE_ROOT = DIAGNOSTICS_ROOT.parent
NNTRAIN_ROOT = BASELINE_ROOT.parent
SRC_ROOT = NNTRAIN_ROOT / "src"
sys.path.insert(0, str(SRC_ROOT))

from bishe_ai.data.body_frame import dynamic_body_coordinates  # noqa: E402
from bishe_ai.data.ultra_mocap import interpolate_marker_gaps, read_trc  # noqa: E402


AUDIT_PATH = BASELINE_ROOT / "data" / "ultra_full_xyz_v1_audit.json"
OUTPUT_ROOT = DIAGNOSTICS_ROOT / "Baseline_v1_20260817_144111"
MARKERS = ("RRAD", "RULN", "LSHO", "RSHO", "STUR")


def main() -> None:
    metadata = json.loads(AUDIT_PATH.read_text(encoding="utf-8"))
    rows: list[dict[str, Any]] = []
    skipped: list[dict[str, str]] = []
    for report in metadata["trials"]:
        trc = read_trc(Path(report["marker_path"]), MARKERS)
        mask = (trc.frame_numbers >= int(report["common_frame_start"])) & (
            trc.frame_numbers <= int(report["common_frame_end"])
        )
        times_all = trc.time_s[mask]
        raw_markers = {name: trc.markers_m[name][mask] for name in MARKERS}
        jointly_valid = np.logical_and.reduce(
            [np.isfinite(raw_markers[name]).all(axis=1) for name in MARKERS]
        )
        valid_indices = np.flatnonzero(jointly_valid)
        if len(valid_indices) < 2:
            skipped.append(
                {"trial": report["trial_id"], "reason": "fewer than two shared valid frames"}
            )
            continue
        selected = slice(int(valid_indices[0]), int(valid_indices[-1]) + 1)
        times = times_all[selected]
        markers: dict[str, np.ndarray] = {}
        try:
            for name in MARKERS:
                markers[name], _, _ = interpolate_marker_gaps(
                    raw_markers[name][selected],
                    times,
                    marker_name=name,
                    path=trc.path,
                    maximum_gap_s=float(
                        metadata["target_definition"]["maximum_interpolated_gap_s"]
                    ),
                )
        except ValueError as exc:
            skipped.append({"trial": report["trial_id"], "reason": str(exc)})
            continue
        wrist = 0.5 * (markers["RRAD"] + markers["RULN"])
        static_matrix = np.asarray(
            metadata["static_calibration"][report["subject"]]["camera_from_body"],
            dtype=np.float64,
        )
        static_target = (wrist - markers["RSHO"]) @ static_matrix
        dynamic_target = dynamic_body_coordinates(
            wrist, markers["LSHO"], markers["RSHO"], markers["STUR"]
        )
        static_norm = np.linalg.norm(static_target, axis=1)
        dynamic_norm = np.linalg.norm(dynamic_target, axis=1)
        if not np.allclose(static_norm, dynamic_norm, atol=1e-5):
            raise ValueError(f"Rotation changed wrist distance: {report['trial_id']}")
        rows.append(
            {
                "split": report["split"],
                "subject": report["subject"],
                "exercise": report["exercise"],
                "trial": report["trial_id"],
                "frames": len(dynamic_target),
                "static_mean_x_m": float(static_target[:, 0].mean()),
                "dynamic_mean_x_m": float(dynamic_target[:, 0].mean()),
                "static_mean_y_m": float(static_target[:, 1].mean()),
                "dynamic_mean_y_m": float(dynamic_target[:, 1].mean()),
                "static_mean_z_m": float(static_target[:, 2].mean()),
                "dynamic_mean_z_m": float(dynamic_target[:, 2].mean()),
                "static_negative_mean_x": bool(static_target[:, 0].mean() < 0),
                "dynamic_negative_mean_x": bool(dynamic_target[:, 0].mean() < 0),
                "mean_coordinate_difference_m": float(
                    np.linalg.norm(static_target - dynamic_target, axis=1).mean()
                ),
                "mean_wrist_distance_m": float(dynamic_norm.mean()),
            }
        )

    table = pd.DataFrame(rows)
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    table.to_csv(OUTPUT_ROOT / "static_vs_dynamic_body_frame_by_trial.csv", index=False)
    by_subject = (
        table.groupby(["split", "subject"], as_index=False)
        .agg(
            trials=("trial", "count"),
            static_mean_x_m=("static_mean_x_m", "mean"),
            dynamic_mean_x_m=("dynamic_mean_x_m", "mean"),
            static_negative_x_trials=("static_negative_mean_x", "sum"),
            dynamic_negative_x_trials=("dynamic_negative_mean_x", "sum"),
            mean_coordinate_difference_m=("mean_coordinate_difference_m", "mean"),
            mean_wrist_distance_m=("mean_wrist_distance_m", "mean"),
        )
        .sort_values("subject")
    )
    by_subject.to_csv(OUTPUT_ROOT / "static_vs_dynamic_body_frame_by_subject.csv", index=False)
    summary = {
        "trials_used": int(len(table)),
        "trials_skipped": int(len(skipped)),
        "skipped": skipped,
        "static_negative_mean_x_trials": int(table["static_negative_mean_x"].sum()),
        "dynamic_negative_mean_x_trials": int(table["dynamic_negative_mean_x"].sum()),
        "mean_coordinate_difference_m": float(table["mean_coordinate_difference_m"].mean()),
        "maximum_coordinate_difference_m": float(table["mean_coordinate_difference_m"].max()),
        "subjects": by_subject.to_dict(orient="records"),
    }
    (OUTPUT_ROOT / "body_frame_diagnostic_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
