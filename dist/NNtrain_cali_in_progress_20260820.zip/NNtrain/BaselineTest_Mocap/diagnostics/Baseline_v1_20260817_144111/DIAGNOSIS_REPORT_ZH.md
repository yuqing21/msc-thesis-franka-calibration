# ULTRA-MoCap Baseline v1 诊断报告

## 结论先行

当前0.4037 m误差的第一原因不是GRU太小，而是 Ground Truth 身体坐标轴在不同
受试者/trial中不一致；第二原因是sEMG幅值和IMU安装方向存在严重跨受试者分布
漂移；第三原因是直接拼接没有能力拒绝质量较差的模态。

在修正坐标标签以前，不建议先加入FFT、LSTM或扩大网络。否则模型只会更强地拟合
不一致标签。

## 1. 已排除的问题

- P01～P09 / P10～P11 / P12～P13 按受试者划分正确；
- train/validation/test重叠窗口没有跨trial；
- 32条测试trial的label index均按25步递增，没有窗口次序错误；
- sEMG、IMU按Frame/Sub Frame与Vicon共同帧号读取；
- 标准化器只在P01～P09拟合；
- XYZ从mm正确转换为m，肩腕距离保持在合理范围；
- Y轴24/32条trial、Z轴19/32条trial的最佳滞后为0，不支持“整体时间错位”假设；
- P12与P13真实肩腕距离均值分别约0.458 m和0.449 m，差异约9 mm，手臂长度不是
  当前40 cm误差的主要原因。

## 2. 根因一：Static身体坐标轴与正式trial朝向不一致

当前标签计算为：

```text
动态 wrist - 动态 RSHO
→ 乘以 Static_Pxx.trc 估计出的固定旋转轴
```

如果受试者在正式trial中的身体朝向与Static文件不同，原点虽然跟着右肩移动，XYZ轴
却没有跟着身体旋转。

使用每帧 `LSHO、RSHO、STUR` 重建身体坐标轴，对全部208条有标签trial进行只读
对照，结果为：

| 检查项 | Static轴 | 逐帧动态轴 |
|---|---:|---:|
| 平均X为负的trial | 71 | 9 |
| 占全部trial | 34.1% | 4.3% |

- 两种坐标的平均位置差：0.2719 m；
- 最大trial平均位置差：0.8440 m；
- P05：13/16条Static trial的X为负，动态轴后为0/16；
- P08：16/16 → 0/16；
- P09：16/16 → 0/16；
- validation中的P10：16/16 → 0/16。

这意味着训练集本身混入三批近似翻转的目标，validation又有一名全部翻转、一名基本
正常的受试者。模型无法学到唯一的“传感器→身体XYZ”映射，因此validation loss从
第一轮就远高于train loss。

### 第一优先级对策

建立新的 `ultra_full_xyz_dynamic_v2.npz`，保留v1不动：

1. 每条trial读取 `RRAD、RULN、LSHO、RSHO、STUR`；
2. 取五个标记与传感器共同有效区间；
3. 每帧用 `LSHO→RSHO` 定义身体X轴；
4. 用 `STUR→双肩中点` 定义正交Y轴；
5. 用叉积定义右手系Z轴；
6. 将腕中心相对动态RSHO投影到每帧身体轴；
7. 重新标准化、切窗并用完全相同Baseline配置训练；
8. v1和v2必须分别保存，禁止覆盖。

## 3. 根因二：传感器跨受试者分布漂移

### sEMG

全局train标准化无法解决电极接触、贴放位置和个体幅值差异。例如：

- P12第三路sEMG标准差只有训练尺度的0.023，近似失活；
- 不同训练受试者同一sEMG通道标准差从0.018到2.615不等；
- test sEMG的中位标准差只有0.4265，而train约为1.0。

### IMU

- P13第6个IMU的ACCY均值偏移为2.354个训练标准差；
- 同一通道在P13的标准差达到3.736；
- test IMU某通道超过±3标准差的比例达到21.3%。

原始加速度和角速度处于各传感器自己的局部轴。如果粘贴方向变化，网络看到的XYZ
含义也会变化。

### 第二优先级对策

- sEMG先做 `log1p`压缩，再采用每次佩戴/session的无标签稳健归一化；
- 保存通道质量指标，对近似失活通道做mask；
- 训练时随机channel dropout，让网络不能依赖某一块电极；
- 将网络中的BatchNorm与GroupNorm/LayerNorm做对比，减少测试时使用train统计量；
- IMU必须规定箭头朝向和安装模板；
- 添加每个IMU的加速度模长、角速度模长作为方向不变特征；
- 若设备提供四元数，先把IMU向量旋转到统一身体坐标系；
- 对ULTRA可测试gyro-only、向量模长和去DC加速度，判断重力方向漂移的影响。

## 4. 根因三：直接特征拼接让sEMG拖累IMU

相同split、seed和训练参数下：

| 模型 | 三维平均误差 | Pearson平均值 |
|---|---:|---:|
| 当前双分支直接拼接 | 0.4037 m | 0.5008 |
| sEMG-only | 0.3802 m | 0.2577 |
| IMU-only | 0.3593 m | 0.5787 |
| Early Fusion | 0.3912 m | 0.5251 |
| validation选择的Late Fusion | **0.3286 m** | **0.5808** |

Late Fusion只在P10～P11选择一次固定权重：IMU 0.6、sEMG 0.4；测试集没有参与
权重选择。它相对当前双分支降低18.6%三维平均误差，证明两种模态存在互补信息，
问题主要是融合方法，而不是必须删掉sEMG。

### 第三优先级对策

先保留Late Fusion作为强对照，再实现IMU锚定的门控残差融合：

```text
f_imu + sigmoid(gate(f_imu, f_semg, quality)) × residual_semg
```

- gate初始偏向IMU，sEMG只有在有帮助时才修正IMU结果；
- 把sEMG通道质量和IMU异常程度输入gate；
- 训练时使用modality dropout；
- 为sEMG和IMU分支各加辅助XYZ loss，避免某个分支完全失效；
- 与Late Fusion、直接拼接保持相同数据和seed比较。

## 5. 固定位置偏差

Baseline全局平均偏差为：

```text
X = -0.196 m
Y = +0.135 m
Z = +0.178 m
```

仅用于诊断地移除测试集真实平均偏差后，三维平均误差由0.4037 m降至0.3160 m。
这不能作为正式算法，因为使用了测试标签，但说明“初始位置/坐标偏移”占误差较大。

实际系统可以采用不需要尺子的2～3秒中立姿态自动校准，或预测相对初始位置的位移。
如果完全不允许任何初始姿态，必须加入四元数/方向和更长时序状态，否则仅凭500 ms
加速度、角速度和肌电直接确定绝对XYZ在物理上存在歧义。

## 6. ULTRA改进迁移到自采设备

### 可以直接迁移的方法

- 动态身体坐标Ground Truth定义；
- Conv1D + GRU双分支思路；
- sEMG质量mask、session归一化和channel dropout；
- IMU方向统一、向量模长和四元数特征；
- 门控/晚期融合；
- 按录制session划分train/val/test；
- 分轴、三维距离、分trial评价方法。

### 不能直接照搬的内容

- ULTRA训练权重；
- ULTRA的mean/std标准化参数；
- IMU输入层：ULTRA是36维，你的3个IMU用加速度+角速度时是18维；
- sEMG输入层：ULTRA是3通道，你自采可以保存6通道再决定训练6通道或固定3通道；
- `T=50`：它来自100 Hz×500 ms，不是永远固定为50。

你的WT901目前约6.6～14.2 Hz，500 ms只有约3～7个IMU样本，GRU得到的时间信息
远少于ULTRA。迁移前应优先提高并稳定IMU采样率；否则把窗口延长到约1.5～2秒，
并用毫秒定义窗口而不是硬写 `T=50`。

推荐流程是：在ULTRA的v2标签上证明改进结构有效，然后保持结构思路，用你自己的
sEMG+3 IMU+同步深度相机XYZ重新训练。可以尝试加载GRU/回归头作初始化，但正式
结果必须在自采数据上重新训练或微调，不能直接宣称ULTRA权重适用于你的设备。

## 7. 下一步实验顺序

1. 生成动态身体坐标v2数据并原样重跑Baseline；
2. 在v2上重跑IMU-only、sEMG-only、直接拼接和Late Fusion；
3. 加入sEMG session归一化与通道质量mask；
4. 加入IMU方向不变特征/四元数；
5. 实现IMU锚定门控融合；
6. 最后再测试时间注意力和傅里叶分支；
7. 每个最终候选至少运行3个seed，报告平均值和标准差。

## 8. 诊断证据文件

- `diagnostic_summary.json`：全局、受试者、动作和最差trial；
- `metrics_by_subject.csv`、`metrics_by_exercise.csv`、`metrics_by_trial.csv`；
- `feature_distribution_shift.csv`；
- `lag_by_trial.csv`；
- `static_vs_dynamic_body_frame_by_subject.csv`；
- `static_vs_dynamic_body_frame_by_trial.csv`；
- `body_frame_diagnostic_summary.json`；
- `modality_ablation_results.csv`；
- `late_fusion_summary.json`；
- `bias_and_exercise_error.png`、`worst_trial_examples.png`。

