from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

from bishe_ai.data.datasets import MultimodalWindowDataset
from bishe_ai.data.body_frame import dynamic_body_coordinates
from bishe_ai.data.ultra_mocap import (
    TARGET_MARKERS,
    align_mot_coordinates,
    interpolate_marker_gaps,
    read_mot,
    read_trc,
)
from bishe_ai.evaluation.joint_fk import SubjectArmKinematics, endpoint_metrics
from bishe_ai.models import build_model


PROJECT = Path(__file__).resolve().parents[2]
DATASET = PROJECT / "BaselineTest_Mocap/data/ultra_full_joint4_endpoint_v1.npz"
CHECKPOINT = PROJECT / (
    "BaselineTest_Mocap/outputs/formal/joint4_endpoint_v1/checkpoints/"
    "ultra_mocap_joint4_endpoint_v1_dual_branch_best.pt"
)
OUTPUT = PROJECT / "BaselineTest_Mocap/outputs/formal/joint4_endpoint_v1/fk_evaluation"
RAW_ROOT = PROJECT / "data/raw/ultra_mocap/ULTRA-MoCap"


def _model_predictions(npz: np.lib.npyio.NpzFile) -> np.ndarray:
    payload = torch.load(CHECKPOINT, map_location="cpu", weights_only=False)
    config = payload["config"]
    dimensions = {
        "semg_channels": int(npz["semg_test"].shape[-1]),
        "imu_channels": int(npz["imu_test"].shape[-1]),
        "output_dim": 4,
    }
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = build_model(config["model"], **dimensions).to(device)
    model.load_state_dict(payload["model_state"])
    model.eval()
    dataset = MultimodalWindowDataset(npz["semg_test"], npz["imu_test"], npz["target_test"])
    predictions: list[np.ndarray] = []
    with torch.no_grad():
        for batch in DataLoader(dataset, batch_size=256, shuffle=False):
            standardized = model({key: value.to(device) for key, value in batch.items()})
            predictions.append(standardized.cpu().numpy())
    scaled = np.concatenate(predictions)
    return scaled * npz["target_scale"] + npz["target_mean"]


def _vicon_targets(
    npz: np.lib.npyio.NpzFile, metadata: dict[str, object]
) -> np.ndarray:
    reports = {
        (row["subject"], f'{row["exercise"]}/{row["trial_id"]}'): row
        for row in metadata["trials"]
        if row["split"] == "test"
    }
    subjects = npz["subject_test"]
    trials = npz["trial_test"]
    label_indices = npz["label_index_test"]
    result = np.empty((len(subjects), 3), dtype=np.float32)
    for key in sorted(set(zip(subjects.tolist(), trials.tolist(), strict=True))):
        report = reports[key]
        trc = read_trc(Path(report["marker_path"]), TARGET_MARKERS)
        start = int(report["common_frame_start"])
        end = int(report["common_frame_end"])
        selected = np.flatnonzero((trc.frame_numbers >= start) & (trc.frame_numbers <= end))
        time = trc.time_s[selected]
        markers = {
            name: interpolate_marker_gaps(
                trc.markers_m[name][selected],
                time,
                marker_name=name,
                path=trc.path,
                maximum_gap_s=0.2,
            )[0]
            for name in TARGET_MARKERS
        }
        wrist = 0.5 * (markers["RRAD"] + markers["RULN"])
        xyz = dynamic_body_coordinates(
            wrist, markers["LSHO"], markers["RSHO"], markers["STUR"]
        )
        mask = (subjects == key[0]) & (trials == key[1])
        result[mask] = xyz[label_indices[mask]]
    return result


def _other_ik_coordinates(
    npz: np.lib.npyio.NpzFile, metadata: dict[str, object]
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    channels = ("SC_y", "SC_x", "SC_z", "SC_y_l", "SC_x_l", "SC_z_l", "pro_sup_r")
    reports = {
        (row["subject"], f'{row["exercise"]}/{row["trial_id"]}'): row
        for row in metadata["trials"]
        if row["split"] == "test"
    }
    subjects, trials = npz["subject_test"], npz["trial_test"]
    label_indices = npz["label_index_test"]
    result = np.empty((len(subjects), len(channels)), dtype=np.float32)
    for key in sorted(set(zip(subjects.tolist(), trials.tolist(), strict=True))):
        report = reports[key]
        trc = read_trc(Path(report["marker_path"]), TARGET_MARKERS)
        start, end = int(report["common_frame_start"]), int(report["common_frame_end"])
        selected = (trc.frame_numbers >= start) & (trc.frame_numbers <= end)
        mot = read_mot(Path(report["ik_path"]), channels)
        aligned = align_mot_coordinates(mot, trc.time_s[selected], channels)
        mask = (subjects == key[0]) & (trials == key[1])
        result[mask] = aligned[label_indices[mask]]
    return result[:, :3], result[:, 3:6], result[:, 6]


def _group_metrics(
    target: np.ndarray, prediction: np.ndarray, groups: np.ndarray
) -> dict[str, dict[str, object]]:
    return {
        str(group): endpoint_metrics(target[groups == group], prediction[groups == group])
        for group in np.unique(groups)
    }


def main() -> None:
    with np.load(DATASET, allow_pickle=False) as npz:
        metadata = json.loads(str(npz["metadata_json"]))
        true_angles = (
            npz["target_test"] * npz["target_scale"] + npz["target_mean"]
        ).astype(np.float32)
        predicted_angles = _model_predictions(npz).astype(np.float32)
        vicon_xyz = _vicon_targets(npz, metadata)
        right_sc, left_sc, pronation = _other_ik_coordinates(npz, metadata)
        subjects = npz["subject_test"].copy()
        trials = npz["trial_test"].copy()

    oracle_xyz = np.empty_like(vicon_xyz)
    predicted_xyz = np.empty_like(vicon_xyz)
    full_ik_xyz = np.empty_like(vicon_xyz)
    for subject in np.unique(subjects):
        subject_number = int(str(subject)[1:])
        model_path = RAW_ROOT / str(subject) / f"subject_{subject_number}.osim"
        kinematics = SubjectArmKinematics.from_osim(model_path)
        mask = subjects == subject
        oracle_xyz[mask] = kinematics.wrist_xyz(true_angles[mask])
        predicted_xyz[mask] = kinematics.wrist_xyz(predicted_angles[mask])
        full_ik_xyz[mask] = kinematics.wrist_xyz_full_ik(
            true_angles[mask], right_sc[mask], left_sc[mask], pronation[mask]
        )

    exercises = np.asarray([str(value).split("/", 1)[0] for value in trials])
    report = {
        "definition": (
            "Subject-scaled OpenSim geometry; torso, sternoclavicular, pronation and wrist "
            "fixed at model zero; four right shoulder/elbow coordinates vary. Vicon target "
            "is (RRAD+RULN)/2 in the per-frame RSHO body frame."
        ),
        "oracle_fk_vs_vicon": endpoint_metrics(vicon_xyz, oracle_xyz),
        "predicted_fk_vs_vicon": endpoint_metrics(vicon_xyz, predicted_xyz),
        "full_ik_fk_sanity_check_vs_vicon": endpoint_metrics(vicon_xyz, full_ik_xyz),
        "oracle_by_subject": _group_metrics(vicon_xyz, oracle_xyz, subjects),
        "predicted_by_subject": _group_metrics(vicon_xyz, predicted_xyz, subjects),
        "oracle_by_exercise": _group_metrics(vicon_xyz, oracle_xyz, exercises),
        "predicted_by_exercise": _group_metrics(vicon_xyz, predicted_xyz, exercises),
    }
    OUTPUT.mkdir(parents=True, exist_ok=True)
    with (OUTPUT / "joint4_fk_metrics.json").open("w", encoding="utf-8") as handle:
        json.dump(report, handle, indent=2, ensure_ascii=False)
    np.savez_compressed(
        OUTPUT / "joint4_fk_predictions.npz",
        subject=subjects,
        trial=trials,
        true_angles_deg=true_angles,
        predicted_angles_deg=predicted_angles,
        vicon_xyz_m=vicon_xyz,
        oracle_fk_xyz_m=oracle_xyz,
        predicted_fk_xyz_m=predicted_xyz,
        full_ik_fk_xyz_m=full_ik_xyz,
    )
    print(json.dumps(report, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
