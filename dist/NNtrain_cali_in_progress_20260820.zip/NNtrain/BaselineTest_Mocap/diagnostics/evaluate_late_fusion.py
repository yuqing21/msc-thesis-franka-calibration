from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


DIAGNOSTICS_ROOT = Path(__file__).resolve().parent
BASELINE_ROOT = DIAGNOSTICS_ROOT.parent
NNTRAIN_ROOT = BASELINE_ROOT.parent
SRC_ROOT = NNTRAIN_ROOT / "src"
sys.path.insert(0, str(SRC_ROOT))
sys.path.insert(0, str(DIAGNOSTICS_ROOT))

from analyze_baseline import _configure_console, _predict  # noqa: E402
from bishe_ai.evaluation.metrics import regression_metrics  # noqa: E402


DATASET = BASELINE_ROOT / "data" / "ultra_full_xyz_v1.npz"
CHECKPOINT_ROOT = (
    BASELINE_ROOT / "outputs" / "diagnostics" / "modality_ablation" / "checkpoints"
)
SEMG_CHECKPOINT = (
    CHECKPOINT_ROOT / "baseline_v1_modality_ablation_seed42_semg_only_best.pt"
)
IMU_CHECKPOINT = CHECKPOINT_ROOT / "baseline_v1_modality_ablation_seed42_imu_only_best.pt"
OUTPUT_ROOT = DIAGNOSTICS_ROOT / "Baseline_v1_20260817_144111"


def select_imu_weight(
    target: np.ndarray,
    semg_prediction: np.ndarray,
    imu_prediction: np.ndarray,
    weights: np.ndarray | None = None,
) -> tuple[float, pd.DataFrame]:
    """Choose one validation-set weight; 1.0 means IMU-only."""
    if weights is None:
        weights = np.linspace(0.0, 1.0, 101)
    rows: list[dict[str, Any]] = []
    for weight in weights:
        prediction = weight * imu_prediction + (1.0 - weight) * semg_prediction
        metrics = regression_metrics(target, prediction)
        rows.append(
            {
                "imu_weight": float(weight),
                "semg_weight": float(1.0 - weight),
                "mae_m": metrics["mae"],
                "rmse_m": metrics["rmse"],
                "euclidean_mean_m": metrics["euclidean_mean"],
            }
        )
    table = pd.DataFrame(rows)
    best_index = table["euclidean_mean_m"].idxmin()
    return float(table.loc[best_index, "imu_weight"]), table


def main() -> None:
    _configure_console()
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    for path in (DATASET, SEMG_CHECKPOINT, IMU_CHECKPOINT):
        if not path.is_file():
            raise FileNotFoundError(path)

    semg_val = _predict(SEMG_CHECKPOINT, DATASET, batch_size=256, split="val")
    imu_val = _predict(IMU_CHECKPOINT, DATASET, batch_size=256, split="val")
    if not np.array_equal(semg_val["target"], imu_val["target"]):
        raise ValueError("Validation labels differ between modality models")
    weight, curve = select_imu_weight(
        semg_val["target"], semg_val["prediction"], imu_val["prediction"]
    )
    curve.to_csv(OUTPUT_ROOT / "late_fusion_validation_curve.csv", index=False)

    semg_test = _predict(SEMG_CHECKPOINT, DATASET, batch_size=256, split="test")
    imu_test = _predict(IMU_CHECKPOINT, DATASET, batch_size=256, split="test")
    if not np.array_equal(semg_test["target"], imu_test["target"]):
        raise ValueError("Test labels differ between modality models")
    fused = weight * imu_test["prediction"] + (1.0 - weight) * semg_test["prediction"]
    summary = {
        "selection_split": "validation",
        "selection_metric": "mean Euclidean XYZ error in metres",
        "imu_weight": weight,
        "semg_weight": 1.0 - weight,
        "validation_metrics": regression_metrics(semg_val["target"], weight * imu_val["prediction"] + (1.0 - weight) * semg_val["prediction"]),
        "test_metrics": regression_metrics(semg_test["target"], fused),
        "semg_only_test_metrics": regression_metrics(
            semg_test["target"], semg_test["prediction"]
        ),
        "imu_only_test_metrics": regression_metrics(
            imu_test["target"], imu_test["prediction"]
        ),
    }
    (OUTPUT_ROOT / "late_fusion_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    try:
        main()
    except (OSError, KeyError, TypeError, ValueError) as exc:
        _configure_console()
        print(f"\nLate fusion诊断失败：{exc}", file=sys.stderr)
        raise SystemExit(2) from None

