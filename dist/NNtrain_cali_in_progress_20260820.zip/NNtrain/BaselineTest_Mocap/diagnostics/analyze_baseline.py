from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

import matplotlib
import numpy as np
import pandas as pd
import torch


matplotlib.use("Agg")
import matplotlib.pyplot as plt


DIAGNOSTICS_ROOT = Path(__file__).resolve().parent
BASELINE_ROOT = DIAGNOSTICS_ROOT.parent
NNTRAIN_ROOT = BASELINE_ROOT.parent
SRC_ROOT = NNTRAIN_ROOT / "src"
sys.path.insert(0, str(SRC_ROOT))

from bishe_ai.evaluation.metrics import regression_metrics  # noqa: E402
from bishe_ai.models import build_model  # noqa: E402


DEFAULT_ARCHIVE = BASELINE_ROOT / "fixed_results" / "Baseline_v1_20260817_144111"
DEFAULT_CHECKPOINT = DEFAULT_ARCHIVE / "model_best.pt"
DEFAULT_DATASET = BASELINE_ROOT / "data" / "ultra_full_xyz_v1.npz"
DEFAULT_OUTPUT = DIAGNOSTICS_ROOT / "Baseline_v1_20260817_144111"
AXES = ("x", "y", "z")


def _configure_console() -> None:
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if callable(reconfigure):
            reconfigure(encoding="utf-8", errors="replace")


def _json_ready(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): _json_ready(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_ready(item) for item in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, Path):
        return str(value)
    return value


def _pearson(target: np.ndarray, prediction: np.ndarray) -> float | None:
    if len(target) < 3 or np.std(target) < 1e-12 or np.std(prediction) < 1e-12:
        return None
    return float(np.corrcoef(target, prediction)[0, 1])


def best_lag_windows(
    target: np.ndarray, prediction: np.ndarray, max_lag: int = 4
) -> tuple[list[int], list[float | None]]:
    """Find lag maximizing Pearson; positive means prediction trails target."""
    target = np.asarray(target, dtype=np.float64)
    prediction = np.asarray(prediction, dtype=np.float64)
    if target.shape != prediction.shape or target.ndim != 2:
        raise ValueError("target and prediction must share [samples, dimensions]")
    if max_lag < 0:
        raise ValueError("max_lag must be nonnegative")
    best_lags: list[int] = []
    best_correlations: list[float | None] = []
    for axis in range(target.shape[1]):
        candidates: list[tuple[float, int]] = []
        for lag in range(-max_lag, max_lag + 1):
            if lag > 0:
                aligned_target = target[:-lag, axis]
                aligned_prediction = prediction[lag:, axis]
            elif lag < 0:
                aligned_target = target[-lag:, axis]
                aligned_prediction = prediction[:lag, axis]
            else:
                aligned_target = target[:, axis]
                aligned_prediction = prediction[:, axis]
            correlation = _pearson(aligned_target, aligned_prediction)
            if correlation is not None:
                candidates.append((correlation, lag))
        if not candidates:
            best_lags.append(0)
            best_correlations.append(None)
            continue
        correlation, lag = max(candidates, key=lambda pair: (pair[0], -abs(pair[1])))
        best_lags.append(lag)
        best_correlations.append(correlation)
    return best_lags, best_correlations


def _summary_row(name: str, target: np.ndarray, prediction: np.ndarray) -> dict[str, Any]:
    metrics = regression_metrics(target, prediction)
    error = prediction - target
    centered_target = target - target.mean(axis=0, keepdims=True)
    centered_prediction = prediction - prediction.mean(axis=0, keepdims=True)
    centered = regression_metrics(centered_target, centered_prediction)
    row: dict[str, Any] = {
        "group": name,
        "samples": len(target),
        "mae_m": metrics["mae"],
        "rmse_m": metrics["rmse"],
        "euclidean_mean_m": metrics.get("euclidean_mean"),
        "euclidean_median_m": metrics.get("euclidean_median"),
        "centered_rmse_m": centered["rmse"],
        "centered_euclidean_mean_m": centered.get("euclidean_mean"),
    }
    for axis, label in enumerate(AXES):
        row[f"mae_{label}_m"] = metrics["mae_per_dim"][axis]
        row[f"rmse_{label}_m"] = metrics["rmse_per_dim"][axis]
        row[f"pearson_{label}"] = metrics["pearson_per_dim"][axis]
        row[f"bias_{label}_m"] = float(error[:, axis].mean())
        row[f"target_mean_{label}_m"] = float(target[:, axis].mean())
        row[f"prediction_mean_{label}_m"] = float(prediction[:, axis].mean())
        row[f"target_std_{label}_m"] = float(target[:, axis].std())
        row[f"prediction_std_{label}_m"] = float(prediction[:, axis].std())
        row[f"centered_pearson_{label}"] = centered["pearson_per_dim"][axis]
    return row


def _group_table(
    labels: np.ndarray,
    target: np.ndarray,
    prediction: np.ndarray,
) -> pd.DataFrame:
    rows = []
    for label in sorted(np.unique(labels).tolist()):
        mask = labels == label
        rows.append(_summary_row(str(label), target[mask], prediction[mask]))
    return pd.DataFrame(rows)


def _predict(
    checkpoint_path: Path,
    dataset_path: Path,
    batch_size: int,
    split: str = "test",
) -> dict[str, np.ndarray]:
    if split not in {"train", "val", "test"}:
        raise ValueError(f"Unknown split: {split}")
    payload = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    config = payload["config"]
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    with np.load(dataset_path, allow_pickle=False) as archive:
        semg = archive[f"semg_{split}"].astype(np.float32)
        imu = archive[f"imu_{split}"].astype(np.float32)
        target_standardized = archive[f"target_{split}"].astype(np.float32)
        target_mean = archive["target_mean"].astype(np.float32)
        target_scale = archive["target_scale"].astype(np.float32)
        subject = archive[f"subject_{split}"].astype(np.str_)
        trial = archive[f"trial_{split}"].astype(np.str_)
        label_index = archive[f"label_index_{split}"].astype(np.int64)

    dimensions = {
        "semg_channels": int(semg.shape[-1]),
        "imu_channels": int(imu.shape[-1]),
        "output_dim": int(target_standardized.shape[-1]),
    }
    model = build_model(config["model"], **dimensions).to(device)
    model.load_state_dict(payload["model_state"])
    model.eval()
    chunks: list[np.ndarray] = []
    with torch.inference_mode():
        for start in range(0, len(target_standardized), batch_size):
            stop = min(start + batch_size, len(target_standardized))
            batch = {
                "semg": torch.from_numpy(semg[start:stop]).to(device),
                "imu": torch.from_numpy(imu[start:stop]).to(device),
            }
            chunks.append(model(batch).cpu().numpy())
    prediction_standardized = np.concatenate(chunks, axis=0)
    return {
        "target": target_standardized * target_scale + target_mean,
        "prediction": prediction_standardized * target_scale + target_mean,
        "subject": subject,
        "trial": trial,
        "exercise": np.asarray([value.split("/", 1)[0] for value in trial], dtype=np.str_),
        "label_index": label_index,
    }


def _feature_shift_table(dataset_path: Path) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    with np.load(dataset_path, allow_pickle=False) as archive:
        for split in ("train", "val", "test"):
            for modality in ("semg", "imu", "target"):
                array = archive[f"{modality}_{split}"]
                flattened = array.reshape(-1, array.shape[-1]).astype(np.float64)
                means = flattened.mean(axis=0)
                stds = flattened.std(axis=0)
                outliers = np.mean(np.abs(flattened) > 3.0, axis=0)
                for channel in range(flattened.shape[1]):
                    rows.append(
                        {
                            "split": split,
                            "modality": modality,
                            "channel": channel,
                            "mean_standardized": means[channel],
                            "std_standardized": stds[channel],
                            "fraction_abs_gt_3": outliers[channel],
                        }
                    )
    return pd.DataFrame(rows)


def _window_integrity(
    subject: np.ndarray,
    trial: np.ndarray,
    label_index: np.ndarray,
    expected_stride: int = 25,
) -> dict[str, Any]:
    problems = []
    for label in np.unique(trial):
        indices = np.flatnonzero(trial == label)
        trial_subjects = np.unique(subject[indices]).tolist()
        differences = np.diff(label_index[indices])
        if trial_subjects.__len__() != 1 or (
            len(differences) and not np.all(differences == expected_stride)
        ):
            problems.append(
                {
                    "trial": str(label),
                    "subjects": trial_subjects,
                    "label_step_values": np.unique(differences).tolist(),
                }
            )
    return {
        "trials_checked": int(len(np.unique(trial))),
        "expected_stride_steps": expected_stride,
        "problems": problems,
    }


def _lag_table(
    trial: np.ndarray,
    target: np.ndarray,
    prediction: np.ndarray,
    stride_seconds: float = 0.25,
) -> pd.DataFrame:
    rows = []
    for label in sorted(np.unique(trial).tolist()):
        mask = trial == label
        lags, correlations = best_lag_windows(target[mask], prediction[mask], max_lag=4)
        row: dict[str, Any] = {"trial": label, "samples": int(mask.sum())}
        for axis, axis_name in enumerate(AXES):
            row[f"best_lag_{axis_name}_windows"] = lags[axis]
            row[f"best_lag_{axis_name}_seconds"] = lags[axis] * stride_seconds
            row[f"best_lag_{axis_name}_pearson"] = correlations[axis]
        rows.append(row)
    return pd.DataFrame(rows)


def _save_plots(
    output: Path,
    subject_table: pd.DataFrame,
    exercise_table: pd.DataFrame,
    trial_table: pd.DataFrame,
    arrays: dict[str, np.ndarray],
) -> None:
    figure, axes = plt.subplots(1, 2, figsize=(12, 4.5))
    positions = np.arange(len(subject_table))
    width = 0.24
    for index, axis_name in enumerate(AXES):
        axes[0].bar(
            positions + (index - 1) * width,
            subject_table[f"bias_{axis_name}_m"],
            width,
            label=axis_name.upper(),
        )
    axes[0].axhline(0.0, color="black", linewidth=0.8)
    axes[0].set_xticks(positions, subject_table["group"])
    axes[0].set_ylabel("Mean prediction bias (m)")
    axes[0].set_title("Bias by test subject")
    axes[0].legend()

    ordered = exercise_table.sort_values("euclidean_mean_m", ascending=False)
    axes[1].barh(ordered["group"], ordered["euclidean_mean_m"], label="original")
    axes[1].barh(
        ordered["group"],
        ordered["centered_euclidean_mean_m"],
        alpha=0.75,
        label="after diagnostic mean removal",
    )
    axes[1].set_xlabel("Mean Euclidean error (m)")
    axes[1].set_title("Error by exercise")
    axes[1].legend()
    figure.tight_layout()
    figure.savefig(output / "bias_and_exercise_error.png", dpi=180)
    plt.close(figure)

    worst_trials = trial_table.nlargest(3, "euclidean_mean_m")["group"].tolist()
    figure, axes = plt.subplots(len(worst_trials), 3, figsize=(14, 3.2 * len(worst_trials)))
    axes = np.atleast_2d(axes)
    for row_index, trial_name in enumerate(worst_trials):
        indices = np.flatnonzero(arrays["trial"] == trial_name)[:160]
        for axis_index, axis_name in enumerate(AXES):
            axis = axes[row_index, axis_index]
            axis.plot(arrays["target"][indices, axis_index], label="target", linewidth=1.4)
            axis.plot(
                arrays["prediction"][indices, axis_index],
                label="prediction",
                linewidth=1.0,
            )
            axis.set_title(f"{trial_name} / {axis_name.upper()}")
            if row_index == 0 and axis_index == 0:
                axis.legend()
    figure.tight_layout()
    figure.savefig(output / "worst_trial_examples.png", dpi=180)
    plt.close(figure)


def run_diagnostics(
    checkpoint_path: Path,
    dataset_path: Path,
    output: Path,
    batch_size: int = 256,
) -> dict[str, Any]:
    checkpoint_path = checkpoint_path.resolve()
    dataset_path = dataset_path.resolve()
    output = output.resolve()
    if not checkpoint_path.is_file() or not dataset_path.is_file():
        raise FileNotFoundError(
            f"checkpoint={checkpoint_path.is_file()}, dataset={dataset_path.is_file()}"
        )
    output.mkdir(parents=True, exist_ok=True)

    arrays = _predict(checkpoint_path, dataset_path, batch_size)
    target = arrays["target"]
    prediction = arrays["prediction"]
    global_metrics = regression_metrics(target, prediction)

    subject_table = _group_table(arrays["subject"], target, prediction)
    exercise_table = _group_table(arrays["exercise"], target, prediction)
    trial_table = _group_table(arrays["trial"], target, prediction)
    lag_table = _lag_table(arrays["trial"], target, prediction)
    shift_table = _feature_shift_table(dataset_path)
    integrity = _window_integrity(
        arrays["subject"], arrays["trial"], arrays["label_index"]
    )

    with np.load(dataset_path, allow_pickle=False) as archive:
        train_target_mean = archive["target_mean"].astype(np.float32)
    mean_prediction = np.broadcast_to(train_target_mean, target.shape)
    mean_baseline = regression_metrics(target, mean_prediction)

    global_bias = (prediction - target).mean(axis=0)
    diagnostic_bias_corrected = prediction - global_bias
    bias_corrected_metrics = regression_metrics(target, diagnostic_bias_corrected)

    for table, filename in (
        (subject_table, "metrics_by_subject.csv"),
        (exercise_table, "metrics_by_exercise.csv"),
        (trial_table, "metrics_by_trial.csv"),
        (lag_table, "lag_by_trial.csv"),
        (shift_table, "feature_distribution_shift.csv"),
    ):
        table.to_csv(output / filename, index=False, encoding="utf-8-sig")

    np.savez_compressed(
        output / "test_predictions.npz",
        target=target.astype(np.float32),
        prediction=prediction.astype(np.float32),
        subject=arrays["subject"],
        trial=arrays["trial"],
        exercise=arrays["exercise"],
        label_index=arrays["label_index"],
    )
    _save_plots(output, subject_table, exercise_table, trial_table, arrays)

    summary = {
        "checkpoint": checkpoint_path,
        "dataset": dataset_path,
        "global_metrics": global_metrics,
        "train_mean_constant_baseline": mean_baseline,
        "diagnostic_global_bias_m": global_bias,
        "diagnostic_global_bias_corrected_metrics": bias_corrected_metrics,
        "window_integrity": integrity,
        "subject_metrics": subject_table.to_dict(orient="records"),
        "worst_exercises": exercise_table.nlargest(5, "euclidean_mean_m").to_dict(
            orient="records"
        ),
        "worst_trials": trial_table.nlargest(8, "euclidean_mean_m").to_dict(
            orient="records"
        ),
        "lag_median_windows": {
            axis: float(lag_table[f"best_lag_{axis}_windows"].median()) for axis in AXES
        },
        "lag_mode_windows": {
            axis: int(lag_table[f"best_lag_{axis}_windows"].mode().iloc[0]) for axis in AXES
        },
    }
    (output / "diagnostic_summary.json").write_text(
        json.dumps(_json_ready(summary), indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(_json_ready(summary), indent=2, ensure_ascii=False))
    return summary


def main() -> None:
    _configure_console()
    parser = argparse.ArgumentParser(description="Diagnose the frozen ULTRA-MoCap baseline")
    parser.add_argument("--checkpoint", type=Path, default=DEFAULT_CHECKPOINT)
    parser.add_argument("--dataset", type=Path, default=DEFAULT_DATASET)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--batch-size", type=int, default=256)
    args = parser.parse_args()
    run_diagnostics(args.checkpoint, args.dataset, args.output, args.batch_size)


if __name__ == "__main__":
    try:
        main()
    except (OSError, KeyError, TypeError, ValueError) as exc:
        _configure_console()
        print(f"\n诊断失败：{exc}", file=sys.stderr)
        raise SystemExit(2) from None
