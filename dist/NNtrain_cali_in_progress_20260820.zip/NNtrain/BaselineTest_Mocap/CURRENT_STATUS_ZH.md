# ULTRA-MoCap 验证场：当前状态

## 角色边界

`BaselineTest_Mocap/` 只用于公开 ULTRA-MoCap 数据上的模型验证。最终系统将在
`src/bishe_ai/` 上使用自采六路 sEMG、IMU与深度相机关节角标签训练。这里的指标
不能直接写成自采系统的最终精度。

## 可作为历史对照的结果

- `fixed_results/`：冻结的XYZ基准和注意力门控历史实验；不修改、不覆盖。
- `JOINT3_SHOULDER_ELBOW_RESULTS_ZH.md`：固定受试者划分的三角度历史结果；仅用于
  对照，不能代替LOSO受试者平均结果。
- `outputs/loso_abcd_fast_p13/`：P13单折快速探索，其中旧
  `D_imu_guided_emg_gate` 已废弃，不纳入新的A/B/C/D定义。

## 当前A/B/C/D定义

```text
A_imu_only                    IMU绝对关节角预测
B_emg_only                    sEMG绝对关节角预测
C_concat_fusion               IMU与sEMG普通late fusion
D_imu_coarse_emg_residual     冻结A的粗预测 + sEMG残差修正
```

三折P11/P12/P13输出在 `outputs/loso_abcd/`。A、B、C、D的比较仅代表公开数据上的
初步三折验证，不是完整13折LOSO，也不是自采实验结论。

## D残差模型的修复状态

旧D训练曾使用：

```text
Huber(y_coarse + delta, y_gt) + 0.5 × Huber(delta, y_gt - y_coarse)
```

这两项在数学上完全相同，第二项只会放大同一梯度。现已修正为：

```text
优化目标：Huber(y_final, y_gt)
残差Huber：仅记录为诊断指标，不参与反向传播
```

因此已有 `outputs/loso_abcd/D_imu_coarse_emg_residual/` 的D结果必须标记为
**修复前探索性结果**；若要引用D与A/C的正式比较，必须用修复后的脚本重新运行。
此前A/B/C权重和结果仍保留，不能覆盖。

## 运行规则

- 每折只用训练受试者拟合 sEMG、IMU和目标角标准化器。
- A教师必须来自同一fold的A `best.pt`，保持eval且所有参数冻结。
- 每个模型训练前重置同一随机种子；模型选择和early stopping只使用验证受试者。
- 测试受试者只在最佳checkpoint确定后评估一次。

## 进入自采数据阶段前

1. 录制单人多trial的六路sEMG、IMU和深度相机数据；
2. 使用 `scripts/validate_recording.py` 检查时间同步与缺失；
3. 使用 `scripts/prepare_self_recorded.py` 生成训练窗口；
4. 在 `src/bishe_ai/` 上训练，并把自采指标和ULTRA验证指标分开报告。
