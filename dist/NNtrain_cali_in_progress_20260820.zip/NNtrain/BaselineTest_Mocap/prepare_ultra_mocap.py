from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any

import numpy as np
from tqdm import tqdm


BASELINE_ROOT = Path(__file__).resolve().parent
NNTRAIN_ROOT = BASELINE_ROOT.parent
SRC_ROOT = NNTRAIN_ROOT / "src"
sys.path.insert(0, str(SRC_ROOT))

from bishe_ai.data.ultra_mocap import (  # noqa: E402
    IMU_CHANNELS,
    JOINT4_CHANNELS,
    JOINT8_CHANNELS,
    SEMG_CHANNELS,
    SUBJECT_SPLITS,
    TARGET_MARKERS,
    discover_trials,
    load_trial,
)
from bishe_ai.data.windows import Standardizer, TrialData, make_windows  # noqa: E402
from bishe_ai.evaluation.joint_fk import SubjectArmKinematics  # noqa: E402


DEFAULT_RAW_ROOT = NNTRAIN_ROOT / "data" / "raw" / "ultra_mocap" / "ULTRA-MoCap"
DEFAULT_OUTPUT = BASELINE_ROOT / "data" / "ultra_full_xyz_dynamic_v2.npz"
DEFAULT_AUDIT = BASELINE_ROOT / "data" / "ultra_full_xyz_dynamic_v2_audit.json"
DEFAULT_JOINT4_OUTPUT = BASELINE_ROOT / "data" / "ultra_full_joint4_endpoint_v1.npz"
DEFAULT_JOINT4_AUDIT = BASELINE_ROOT / "data" / "ultra_full_joint4_endpoint_v1_audit.json"
DEFAULT_JOINT8_OUTPUT = BASELINE_ROOT / "data" / "ultra_full_joint8_xyz_v1.npz"
DEFAULT_JOINT8_AUDIT = BASELINE_ROOT / "data" / "ultra_full_joint8_xyz_v1_audit.json"


FK_VECTOR_FIELDS = (
    "right_clavicle_origin",
    "left_clavicle_origin",
    "scapula_offset",
    "shoulder_offset",
    "rsho_marker",
    "lsho_marker",
    "stur_marker",
    "elbow_offset",
    "radioulnar_offset",
    "rradius_marker",
    "rulna_marker",
    "elbow_axis",
    "pronation_axis",
)


def _fk_arrays(raw_root: Path, subjects: list[str]) -> dict[str, np.ndarray]:
    models = []
    for subject in subjects:
        number = int(subject[1:])
        models.append(SubjectArmKinematics.from_osim(raw_root / subject / f"subject_{number}.osim"))
    arrays = {
        f"fk_{field}": np.stack([getattr(model, field) for model in models]).astype(np.float32)
        for field in FK_VECTOR_FIELDS
    }
    arrays["fk_shoulder_axes"] = np.stack([model.shoulder_axes for model in models]).astype(np.float32)
    arrays["fk_right_sc_axes"] = np.stack([model.right_sc_axes for model in models]).astype(np.float32)
    arrays["fk_subjects"] = np.asarray(subjects, dtype=np.str_)
    return arrays


def _configure_console() -> None:
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if callable(reconfigure):
            reconfigure(encoding="utf-8", errors="replace")


def _integer_steps(milliseconds: float, rate_hz: float, name: str) -> int:
    exact = milliseconds * rate_hz / 1000.0
    rounded = round(exact)
    if rounded <= 0 or not np.isclose(exact, rounded):
        raise ValueError(f"{name}={milliseconds} ms is not an integer step count at {rate_hz} Hz")
    return int(rounded)


def _split_for_subject(subject: str) -> str:
    matches = [split for split, subjects in SUBJECT_SPLITS.items() if subject in subjects]
    if len(matches) != 1:
        raise ValueError(f"Subject {subject} belongs to {len(matches)} splits: {matches}")
    return matches[0]


def _require_fitted(scaler: Standardizer, name: str) -> tuple[np.ndarray, np.ndarray]:
    if scaler.mean is None or scaler.scale is None:
        raise RuntimeError(f"{name} scaler was not fitted")
    return scaler.mean.astype(np.float32), scaler.scale.astype(np.float32)


def _window_metadata(rows: list[tuple[str, str, int]]) -> dict[str, np.ndarray]:
    return {
        "subject": np.asarray([row[0] for row in rows], dtype=np.str_),
        "trial": np.asarray([row[1] for row in rows], dtype=np.str_),
        "label_index": np.asarray([row[2] for row in rows], dtype=np.int32),
    }


def prepare_dataset(
    raw_root: Path,
    output: Path,
    audit_output: Path,
    *,
    feature_rate_hz: float = 100.0,
    window_ms: float = 500.0,
    stride_ms: float = 250.0,
    maximum_marker_gap_s: float = 0.2,
    target_kind: str = "wrist_xyz",
    gyro_bias_correction: bool = False,
    gyro_quiet_window_ms: float = 200.0,
    semg_trial_normalization: bool = False,
    semg_mad_epsilon: float = 1e-6,
) -> dict[str, Any]:
    raw_root = raw_root.resolve()
    output = output.resolve()
    audit_output = audit_output.resolve()
    trial_files, discovery_report = discover_trials(raw_root)
    if target_kind in {"joint4_endpoint", "joint8_xyz"} and discovery_report["missing_ik_trials"]:
        raise ValueError(
            "Joint-angle preparation requires a Raw IK MOT for every labelled trial: "
            + ", ".join(discovery_report["missing_ik_trials"])
        )
    actual_subjects = sorted({trial.subject for trial in trial_files})
    expected_subjects = sorted(subject for values in SUBJECT_SPLITS.values() for subject in values)
    if actual_subjects != expected_subjects:
        raise ValueError(
            f"Expected subjects {expected_subjects}, discovered {actual_subjects} under {raw_root}"
        )

    trials_by_split: dict[str, list[TrialData]] = {
        split: [] for split in ("train", "val", "test")
    }
    trial_reports: list[dict[str, object]] = []
    print(f"Matched labelled trials: {len(trial_files)}")
    print(f"Sensor-only trials without Raw Marker labels: {len(discovery_report['sensor_only_trials'])}")
    for files in tqdm(trial_files, desc="Preparing ULTRA-MoCap trials", unit="trial"):
        trial, report = load_trial(
            files,
            feature_rate_hz=feature_rate_hz,
            maximum_marker_gap_s=maximum_marker_gap_s,
            target_kind=target_kind,
            gyro_bias_correction=gyro_bias_correction,
            gyro_quiet_window_ms=gyro_quiet_window_ms,
            semg_trial_normalization=semg_trial_normalization,
            semg_mad_epsilon=semg_mad_epsilon,
        )
        split = _split_for_subject(files.subject)
        trials_by_split[split].append(trial)
        report["split"] = split
        trial_reports.append(report)

    empty = [split for split, trials in trials_by_split.items() if not trials]
    if empty:
        raise ValueError(f"All splits must contain trials; empty={empty}")
    semg_scaler = Standardizer().fit(trial.semg for trial in trials_by_split["train"])
    imu_scaler = Standardizer().fit(trial.imu for trial in trials_by_split["train"])
    if target_kind == "joint8_xyz":
        target_scaler = Standardizer().fit(
            trial.target[:, : len(JOINT8_CHANNELS)] for trial in trials_by_split["train"]
        )
        xyz_scaler = Standardizer().fit(
            trial.target[:, len(JOINT8_CHANNELS) :] for trial in trials_by_split["train"]
        )
    else:
        target_scaler = Standardizer().fit(trial.target for trial in trials_by_split["train"])
        xyz_scaler = None
    semg_mean, semg_scale = _require_fitted(semg_scaler, "sEMG")
    imu_mean, imu_scale = _require_fitted(imu_scaler, "IMU")
    target_mean, target_scale = _require_fitted(target_scaler, "target")
    if xyz_scaler is not None:
        xyz_mean, xyz_scale = _require_fitted(xyz_scaler, "XYZ")

    window_steps = _integer_steps(window_ms, feature_rate_hz, "window-ms")
    stride_steps = _integer_steps(stride_ms, feature_rate_hz, "stride-ms")
    arrays: dict[str, np.ndarray] = {}
    window_counts: dict[str, int] = {}
    trial_counts: dict[str, int] = {}
    for split in ("train", "val", "test"):
        standardized = []
        for trial in trials_by_split[split]:
            if xyz_scaler is None:
                standardized_target = target_scaler.transform(trial.target)
            else:
                standardized_target = np.column_stack(
                    (
                        target_scaler.transform(trial.target[:, : len(JOINT8_CHANNELS)]),
                        xyz_scaler.transform(trial.target[:, len(JOINT8_CHANNELS) :]),
                    )
                )
            standardized.append(
                TrialData(
                    subject=trial.subject,
                    trial=trial.trial,
                    semg=semg_scaler.transform(trial.semg),
                    imu=imu_scaler.transform(trial.imu),
                    target=standardized_target,
                )
            )
        semg, imu, target, rows = make_windows(
            standardized,
            window_steps=window_steps,
            stride_steps=stride_steps,
        )
        arrays[f"semg_{split}"] = semg
        arrays[f"imu_{split}"] = imu
        window_meta = _window_metadata(rows)
        if target_kind == "joint8_xyz":
            arrays[f"target_{split}"] = target[:, : len(JOINT8_CHANNELS)]
            arrays[f"xyz_{split}"] = target[:, len(JOINT8_CHANNELS) :]
            subject_lookup = {subject: index for index, subject in enumerate(expected_subjects)}
            arrays[f"subject_index_{split}"] = np.asarray(
                [subject_lookup[str(subject)] for subject in window_meta["subject"]], dtype=np.int64
            )
        else:
            arrays[f"target_{split}"] = target
        arrays[f"subject_{split}"] = window_meta["subject"]
        arrays[f"trial_{split}"] = window_meta["trial"]
        arrays[f"label_index_{split}"] = window_meta["label_index"]
        window_counts[split] = len(target)
        trial_counts[split] = len(standardized)
        print(f"{split:>5}: trials={len(standardized)}, windows={len(target)}, "
              f"sEMG={semg.shape}, IMU={imu.shape}, target={target.shape}")

    if target_kind == "wrist_xyz":
        dataset_version = "dynamic_body_frame_v2"
        predecessor = "ultra_full_xyz_v1.npz (static-axis baseline; preserved)"
        task = "right_wrist_xyz_from_semg_and_imu"
        target_channels = ["wrist_x_body_m", "wrist_y_body_m", "wrist_z_body_m"]
        target_definition: dict[str, Any] = {
            "wrist_center": "mean(RRAD, RULN)",
            "source_rate_hz": feature_rate_hz,
            "source_unit": "mm",
            "output_unit": "m",
            "body_frame_mode": "per_frame_dynamic",
            "required_markers": list(TARGET_MARKERS),
            "body_frame_origin": "dynamic RSHO at each Vicon frame",
            "body_x": "per-frame LSHO to RSHO",
            "body_y": "per-frame STUR to shoulder midpoint, orthogonalized against x",
            "body_z": "per-frame x cross y",
            "static_calibration_used_for_target": False,
            "maximum_interpolated_gap_s": maximum_marker_gap_s,
            "window_label": "last Vicon frame in each window",
            "physical_distance_check_m": [0.1, 1.0],
        }
    elif target_kind == "joint4_endpoint":
        dataset_version = "opensim_joint4_endpoint_v1"
        predecessor = "ultra_full_xyz_dynamic_v2.npz (preserved)"
        task = "right_shoulder_elbow_joint_angles_from_semg_and_imu"
        target_channels = list(JOINT4_CHANNELS)
        target_definition = {
            "source": "subject-specific OpenSim Raw IK MOT",
            "source_rate_hz": feature_rate_hz,
            "source_unit": "degree",
            "output_unit": "degree",
            "coordinates": list(JOINT4_CHANNELS),
            "torso_assumption": "fixed; torso coordinates are not prediction targets",
            "window_label": "last OpenSim IK frame in each window",
            "alignment": "exact MOT time matched to the sensor-covered Vicon frame range",
            "maximum_interpolated_marker_gap_s_used_for_common_range": maximum_marker_gap_s,
        }
    elif target_kind == "joint8_xyz":
        dataset_version = "opensim_joint8_xyz_multitask_v1"
        predecessor = "ultra_full_joint4_endpoint_v1.npz (preserved)"
        task = "right_joint8_and_wrist_xyz_from_semg_and_imu"
        target_channels = list(JOINT8_CHANNELS)
        target_definition = {
            "angle_source": "subject-specific OpenSim Raw IK MOT",
            "angle_unit": "degree",
            "coordinates": list(JOINT8_CHANNELS),
            "xyz_source": "Vicon mean(RRAD, RULN)",
            "xyz_unit": "metre",
            "xyz_body_frame_mode": "per_frame_dynamic",
            "fk_non_target_coordinates": "torso, left SC and wrist fixed at model zero",
            "window_label": "last aligned OpenSim/Vicon frame in each window",
            "alignment": "exact MOT time matched to sensor-covered Vicon frames",
        }
    else:
        raise ValueError(f"Unsupported target_kind={target_kind!r}")

    correction_tags = []
    if gyro_bias_correction:
        correction_tags.append("gyrobias")
    if semg_trial_normalization:
        correction_tags.append("emgnorm")
    if correction_tags:
        dataset_version = f"{dataset_version}+{'_'.join(correction_tags)}"

    metadata: dict[str, Any] = {
        "dataset": "ULTRA-MoCap",
        "dataset_version": dataset_version,
        "predecessor": predecessor,
        "dataset_doi": "10.6084/m9.figshare.28751156.v1",
        "task": task,
        "raw_root": str(raw_root),
        "feature_rate_hz": feature_rate_hz,
        "window_ms": window_ms,
        "stride_ms": stride_ms,
        "window_steps": window_steps,
        "stride_steps": stride_steps,
        "subject_splits": SUBJECT_SPLITS,
        "trial_counts": trial_counts,
        "window_counts": window_counts,
        "semg_channels": list(SEMG_CHANNELS),
        "semg_sensor_mapping": {
            "IM EMG4": "right biceps brachii / S4",
            "IM EMG5": "right triceps brachii / S5",
            "IM EMG6": "right middle deltoid / S6",
        },
        "semg_source_rate_hz": 2000.0,
        "semg_source_unit": "V",
        "semg_preprocessing": {
            "demean": True,
            "bandpass_hz": [20.0, 450.0],
            "line_notch_hz": 60.0,
            "rms_window_ms": 50.0,
            "antialiased_output_rate_hz": feature_rate_hz,
            "per_trial_normalization_applied": semg_trial_normalization,
            "per_trial_normalization_method": (
                "log1p + per-trial per-channel median/MAD" if semg_trial_normalization else None
            ),
            "per_trial_normalization_mad_epsilon": semg_mad_epsilon if semg_trial_normalization else None,
        },
        "imu_channels": list(IMU_CHANNELS),
        "imu_sensor_mapping": {
            "1": "hand / S1",
            "2": "wrist / S2",
            "3": "forearm / S3",
            "4": "biceps / S4",
            "5": "triceps / S5",
            "6": "deltoid / S6",
        },
        "imu_export_rate_hz": 2000.0,
        "imu_source_units": {"ACC": "mm/s^2", "GYRO": "degree/s"},
        "imu_preprocessing": {
            "lowpass_hz": 20.0,
            "antialiased_output_rate_hz": feature_rate_hz,
            "gyro_bias_correction_applied": gyro_bias_correction,
            "gyro_bias_correction_quiet_window_ms": gyro_quiet_window_ms if gyro_bias_correction else None,
        },
        "target_channels": target_channels,
        "target_definition": target_definition,
        "normalization": "mean/std fitted on P01-P09 train frames only",
        "discovery": discovery_report,
        "trials": trial_reports,
    }
    arrays.update(
        {
            "semg_mean": semg_mean,
            "semg_scale": semg_scale,
            "imu_mean": imu_mean,
            "imu_scale": imu_scale,
            "target_mean": target_mean,
            "target_scale": target_scale,
            "metadata_json": np.asarray(json.dumps(metadata, ensure_ascii=False), dtype=np.str_),
        }
    )
    if target_kind == "joint8_xyz":
        arrays["xyz_mean"] = xyz_mean
        arrays["xyz_scale"] = xyz_scale
        arrays.update(_fk_arrays(raw_root, expected_subjects))

    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_name(f"{output.stem}.building.npz")
    if temporary.exists():
        temporary.unlink()
    try:
        np.savez_compressed(temporary, **arrays)
        os.replace(temporary, output)
    finally:
        if temporary.exists():
            temporary.unlink()
    audit_output.parent.mkdir(parents=True, exist_ok=True)
    audit_output.write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Prepared NPZ: {output}")
    print(f"Audit report: {audit_output}")
    return metadata


def main() -> None:
    _configure_console()
    parser = argparse.ArgumentParser(
        description="Prepare ULTRA-MoCap sEMG/IMU windows with XYZ or OpenSim joint labels"
    )
    parser.add_argument("--raw-root", type=Path, default=DEFAULT_RAW_ROOT)
    parser.add_argument(
        "--target-kind",
        choices=("wrist_xyz", "joint4_endpoint", "joint8_xyz"),
        default="wrist_xyz",
    )
    parser.add_argument("--output", type=Path)
    parser.add_argument("--audit-output", type=Path)
    parser.add_argument("--feature-rate", type=float, default=100.0)
    parser.add_argument("--window-ms", type=float, default=500.0)
    parser.add_argument("--stride-ms", type=float, default=250.0)
    parser.add_argument("--maximum-marker-gap-s", type=float, default=0.2)
    parser.add_argument(
        "--gyro-bias-correction",
        action="store_true",
        help="Remove a per-trial gyroscope bias estimated from the trial's quietest window "
        "(gyro channels only; accelerometer is left untouched since it reads gravity at rest).",
    )
    parser.add_argument(
        "--gyro-quiet-window-ms",
        type=float,
        default=200.0,
        help="Length of the rest window used to estimate gyroscope bias, in milliseconds.",
    )
    parser.add_argument(
        "--semg-trial-normalization",
        action="store_true",
        help="Apply log1p compression + per-trial per-channel median/MAD normalization to the "
        "sEMG RMS envelope before the global standardizer.",
    )
    parser.add_argument(
        "--semg-mad-epsilon",
        type=float,
        default=1e-6,
        help="Floor on the per-trial sEMG MAD-derived scale, to avoid divide-by-zero on near-silent channels.",
    )
    args = parser.parse_args()
    default_outputs = {
        "wrist_xyz": (DEFAULT_OUTPUT, DEFAULT_AUDIT),
        "joint4_endpoint": (DEFAULT_JOINT4_OUTPUT, DEFAULT_JOINT4_AUDIT),
        "joint8_xyz": (DEFAULT_JOINT8_OUTPUT, DEFAULT_JOINT8_AUDIT),
    }
    default_output, default_audit = default_outputs[args.target_kind]
    output = args.output or default_output
    audit_output = args.audit_output or default_audit
    prepare_dataset(
        args.raw_root,
        output,
        audit_output,
        feature_rate_hz=args.feature_rate,
        window_ms=args.window_ms,
        stride_ms=args.stride_ms,
        maximum_marker_gap_s=args.maximum_marker_gap_s,
        target_kind=args.target_kind,
        gyro_bias_correction=args.gyro_bias_correction,
        gyro_quiet_window_ms=args.gyro_quiet_window_ms,
        semg_trial_normalization=args.semg_trial_normalization,
        semg_mad_epsilon=args.semg_mad_epsilon,
    )


if __name__ == "__main__":
    try:
        main()
    except (OSError, KeyError, TypeError, ValueError) as exc:
        _configure_console()
        print(f"\nULTRA-MoCap preparation failed: {exc}", file=sys.stderr)
        raise SystemExit(2) from None
