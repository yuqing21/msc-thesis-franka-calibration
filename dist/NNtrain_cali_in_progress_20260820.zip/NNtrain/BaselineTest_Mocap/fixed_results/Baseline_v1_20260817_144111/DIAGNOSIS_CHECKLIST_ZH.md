# Baseline v1 问题排查顺序

> 本清单的第一轮排查已经完成。证据、根因和对策见
> [`diagnostics/Baseline_v1_20260817_144111/DIAGNOSIS_REPORT_ZH.md`](../../diagnostics/Baseline_v1_20260817_144111/DIAGNOSIS_REPORT_ZH.md)。

## 当前观察

1. 第5轮时 train loss 为0.0311，validation loss为0.4861，差距很大；
2. X轴 Pearson 只有0.090，几乎没有正确跟随跨受试者变化；
3. Y、Z轴运动形状有一定跟随能力，但预测曲线存在明显位置偏移；
4. 测试集标准化后均值为 `[0.5725, -0.2381, -0.3516]`，与训练集近似零均值
   不同，说明P12～P13相对训练受试者存在明显目标分布偏移；
5. 三维欧氏距离平均误差为0.4037 m，当前只能作为“流程跑通”的基线。

## P0：先排除数据和评价错误

- [ ] 按 P12、P13 分别计算 XYZ 的 MAE、RMSE、Pearson 和欧氏距离；
- [ ] 再按动作、trial分别计算，确认错误集中在哪些动作；
- [ ] 画每条trial自己的预测图，不跨trial连接曲线；
- [ ] 检查 sEMG、IMU、Vicon 的共同起止时间和时间戳偏移；
- [ ] 随机抽取至少5条trial，把窗口末端标签与原始TRC对应帧人工核对；
- [ ] 检查 `target_mean/target_scale` 是否只计算于P01～P09且只逆变换一次；
- [ ] 检查所有受试者的 RSHO、LSHO、STUR、RRAD、RULN 标记映射；
- [ ] 检查身体坐标系三个轴的方向、正交性和左右手规则在13人中一致；
- [ ] 检查单位始终是 `mm → m`，没有某些trial重复除以1000；
- [ ] 检查重叠窗口没有跨trial，受试者没有跨split。

只有以上项目通过以后，才能把问题归因于网络结构。

## P1：区分“固定偏移”和“运动形状错误”

每个受试者和每条trial额外统计：

```text
bias_xyz = mean(prediction - target)
centered_error = (prediction - prediction_mean) - (target - target_mean)
```

- 若去掉均值后Pearson和RMSE明显改善，主要问题是跨受试者位置偏移或身体尺度；
- 若去掉均值后仍然很差，优先检查时间对齐和动态建模；
- 不能直接在测试集上减去真实标签均值作为最终算法，这只能用于诊断。

## P2：数据正确后再做网络对比

每次只改一个因素，依次建议：

1. Baseline v1：当前 Conv1D + GRU + 直接拼接；
2. 增强正则化：dropout、weight decay或更早停止；
3. GRU全部时间步 + 时间注意力/平均池化，不只取最后hidden；
4. sEMG/IMU门控融合，让网络学习两种模态的权重；
5. 最后再加入sEMG频域或傅里叶融合模块。

暂时不要同时更换LSTM、加入FFT和修改窗口长度，否则无法判断是哪项修改产生影响。

## 公平比较的固定条件

- 数据SHA-256必须与 `dataset_snapshot.json` 一致；
- split固定为P01～P09 / P10～P11 / P12～P13；
- seed固定为42；
- 保持500 ms窗口、250 ms步长和相同标准化器；
- 使用相同测试指标；
- 报告实际epoch、最佳epoch、参数量和训练时间；
- 新实验不能覆盖本目录。
