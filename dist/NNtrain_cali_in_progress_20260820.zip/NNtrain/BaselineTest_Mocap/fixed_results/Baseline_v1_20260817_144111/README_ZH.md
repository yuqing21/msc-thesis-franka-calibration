# Baseline v1：固定结果说明

## 1. 归档状态

这是第一次正式 ULTRA-MoCap 双分支基准实验的只读快照。原实验标识为：

```text
ultra_mocap_baseline_20260817_144111_dual_branch
```

后续排查或改进不能修改本目录中的权重、配置、历史和指标；应建立新的实验目录并
在 `comparison_table.csv` 中增加一行。

## 2. 模型和数据

```text
sEMG [B,50,3]  → Conv1D → GRU → Linear → 64维 ─┐
                                                   ├→ 拼接 → MLP → XYZ [B,3]
IMU  [B,50,36] → Conv1D → GRU → Linear → 64维 ─┘
```

- 模型：`dual_branch`，约 67,619 个可训练参数；
- 损失：Huber Loss；
- 优化器：Adam，学习率 `0.001`，weight decay `0.0001`；
- seed：42；batch size：32；设备：CUDA；
- train：P01～P09，26,777 个窗口；
- validation：P10～P11，6,447 个窗口；
- test：P12～P13，5,222 个窗口；
- 输入窗口：500 ms，100 Hz，50 个时间步；
- sEMG：3通道；IMU：6个传感器的加速度和角速度，共36维；
- 标签：身体局部坐标系中的右腕 XYZ，单位为米。

数据没有复制进结果目录。数据版本由 `dataset_snapshot.json` 中的路径、大小和
SHA-256 固定。

## 3. 训练结果

- 实际训练：15 epochs；
- 最佳epoch：5；
- 第5轮 train loss：0.0310896；
- 第5轮 validation loss：0.4861397；
- 第6～15轮没有改善，触发 patience=10 的早停；
- 训练时间：68.7936秒；
- 测试时使用的是第5轮最佳权重，不是第15轮权重。

## 4. 测试指标

| 指标 | 结果 |
|---|---:|
| MAE | 0.206290 m |
| RMSE | 0.269186 m |
| 三维欧氏距离平均值 | 0.403676 m |
| 三维欧氏距离中位数 | 0.360454 m |
| X轴 Pearson | 0.089964 |
| Y轴 Pearson | 0.787443 |
| Z轴 Pearson | 0.624846 |
| Pearson平均值 | 0.500751 |

结论：训练工程和跨受试者测试流程已经跑通，但当前误差不能作为最终性能。X轴相关
性很弱，训练/验证损失差距明显，Y、Z轴还存在系统性偏移，需要按
`DIAGNOSIS_CHECKLIST_ZH.md` 排查。

## 5. 归档文件

| 文件 | 作用 |
|---|---|
| `model_best.pt` | 第5轮最佳模型权重及配置 |
| `actual_config.yaml` | 本次实际运行配置 |
| `training_history.json` | 15轮 train/validation loss |
| `test_metrics.json` | 正式测试指标 |
| `training_curve.png` | 训练与验证损失曲线 |
| `prediction_curve.png` | 前300个有序测试窗口的XYZ预测图 |
| `comparison_table.csv` | 后续实验的统一比较表 |
| `dataset_snapshot.json` | 本次数据版本、划分和标准化快照 |
| `SHA256SUMS.txt` | 归档完整性校验值 |

注意：预测图只画了前300个测试窗口，并把多个trial按保存顺序连接起来。trial边界
处的跳变不一定是模型错误；正式排查需要按受试者、动作和trial分别绘图。

