# AttentionGatedAxisHeads Dropout 0.3 固定结果

本目录保存 2026-08-17 Dropout 对照实验中，仅依据最低 validation loss 选出的
模型。选中结构包含：

1. sEMG、IMU 双分支 GRU 全时间步注意力池化；
2. 可学习的特征级门控融合；
3. 共享融合层后的 X、Y、Z 独立回归头；
4. Dropout 0.3。

选择规则为 `lowest validation loss only`，没有使用 test 指标决定 Dropout。最佳
checkpoint 来自第 2 个 epoch，validation loss 为 `0.1038529575`。

## 固定内容

- `model_best.pt`：选中模型权重；
- `model_source_regressors.py`：本次模型实现快照；
- `actual_config.yaml`：训练时实际配置；
- `training_history.json`：训练和验证损失；
- `test_metrics.json`：P12、P13 测试指标；
- `training_curve.png`、`prediction_curve.png`：结果图；
- `dropout_sweep_summary.json`：三组 Dropout 完整对照；
- `ANALYSIS_ZH.md`：结果解释与后续建议；
- `SHA256SUMS.txt`：关键文件校验值。

原始完整输出仍保存在
`BaselineTest_Mocap/outputs/experiments/attention_gated_axis_heads/`。
