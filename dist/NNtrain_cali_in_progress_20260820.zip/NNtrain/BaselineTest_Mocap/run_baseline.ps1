param(
    [switch]$CheckOnly,
    [switch]$Smoke
)

$ErrorActionPreference = "Stop"
$baselineRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$nntrainRoot = Split-Path -Parent $baselineRoot
$workspaceRoot = Split-Path -Parent $nntrainRoot
$pythonPath = Join-Path $nntrainRoot ".venv\Scripts\python.exe"
$runnerPath = Join-Path $baselineRoot "run_baseline.py"

if (-not (Test-Path -LiteralPath $pythonPath -PathType Leaf)) {
    throw "NNtrain Python environment not found: $pythonPath"
}

$runnerArguments = @($runnerPath)
if ($CheckOnly) {
    $runnerArguments += "--check-only"
}
if ($Smoke) {
    $runnerArguments += "--smoke"
}

Push-Location $workspaceRoot
try {
    & $pythonPath @runnerArguments
    $runnerExitCode = $LASTEXITCODE
}
finally {
    Pop-Location
}
if ($runnerExitCode -ne 0) {
    exit $runnerExitCode
}
