# ULTRA-MoCap 三角度肩肘预测实验结果（历史固定划分）

> 本文记录的是旧的 P01–P09 / P10–P11 / P12–P13 固定划分结果，用于历史对照。
> ULTRA-MoCap 仅是模型验证场，最终目标是 `src/` 上的自采六路 sEMG+IMU 数据集。
> 当前三折 LOSO 状态与残差D的修复说明见 [`CURRENT_STATUS_ZH.md`](CURRENT_STATUS_ZH.md)。

## 1. 实验目的

将任务收敛为现有三路 sEMG 肌肉覆盖最匹配的三个可观测关节角：

1. `arm_flex_r`：肩屈伸；
2. `arm_add_r`：肩外展/内收；
3. `elbow_flex_r`：肘屈伸。

ULTRA-MoCap 的三路 sEMG 分别来自肱二头肌、肱三头肌和三角肌中束。该组合对肘屈伸与肩部主要平面运动具有直接或较直接的肌肉信息；不把肩内/外旋、前臂旋前/旋后纳入本轮主目标，避免将缺乏直接肌肉覆盖的轴向旋转混入核心指标。

## 2. 数据与划分

本轮从 `ultra_full_joint8_xyz_v1.npz` 派生三角度数据，不改变任一窗口、传感器特征或受试者划分，只选择原始 Joint8 标签中的第 4、5、7 维：

```text
P01–P09：训练集，26,739 窗口
P10–P11：验证集， 6,447 窗口
P12–P13：测试集， 5,220 窗口

输入：sEMG [B, 50, 3] + IMU [B, 50, 36]
输出：肩屈伸、肩外展/内收、肘屈伸 [B, 3]
```

窗口为 500 ms、50 个时间步、步长 250 ms。标准化器仍仅由训练受试者拟合。

## 3. 网络流程图

```mermaid
flowchart TD
    EMG["三路 sEMG RMS 包络<br/>B × 50 × 3"] --> EC1["Conv1d 3→64, kernel 5<br/>BatchNorm + ReLU"]
    EC1 --> EC2["Conv1d 64→64, kernel 3<br/>BatchNorm + ReLU"]
    EC2 --> EGRU["GRU, hidden=96"]
    EGRU --> EF["Linear 96→128<br/>ReLU + Dropout 0.2"]

    IMU["六颗 IMU 的加速度和角速度<br/>B × 50 × 36"] --> IC1["Conv1d 36→64, kernel 5<br/>BatchNorm + ReLU"]
    IC1 --> IC2["Conv1d 64→64, kernel 3<br/>BatchNorm + ReLU"]
    IC2 --> IGRU["GRU, hidden=96"]
    IGRU --> IF["Linear 96→128<br/>ReLU + Dropout 0.2"]

    EF --> F["拼接为 256 维融合特征"]
    IF --> F
    F --> H1["Linear 256→256 + ReLU + Dropout"]
    H1 --> H2["Linear 256→128 + ReLU"]
    H2 --> OUT["Linear 128→3<br/>预测标准化关节角"]
    OUT --> LOSS["Huber Loss<br/>与 OpenSim IK 三角度标签比较"]
    LOSS --> OPT["Adam: lr=0.0005<br/>weight decay=0.0001"]
```

本轮复用了当前 Joint8 最佳实验的双分支 CNN-GRU 融合网络规模：`Conv=64`、`GRU hidden=96`、`feature=128`、`dropout=0.2`。由于输出只包含 3 个角，不能在不引入未知其余角的情况下进行完整 8 角人体 FK，因此本轮采用角度 Huber Loss，评估重点为关节角精度。

## 4. 训练配置与过程

```yaml
seed: 42
epochs: 100
batch_size: 32
learning_rate: 0.0005
weight_decay: 0.0001
loss: huber
early_stopping_patience: 15
device: RTX 4070 Laptop GPU
```

- 最佳验证轮：epoch 12；
- 早停轮：epoch 27；
- 训练时间：190.08 s；
- 最佳验证 Huber loss：0.197153。

## 5. 测试集结果（P12–P13）

| 角度 | MAE (°) | RMSE (°) | Pearson r |
|---|---:|---:|---:|
| 肩屈伸 `arm_flex_r` | 14.30 | 19.85 | 0.915 |
| 肩外展/内收 `arm_add_r` | **10.28** | **14.00** | 0.689 |
| 肘屈伸 `elbow_flex_r` | 15.19 | 19.97 | 0.874 |
| 平均 | **13.26** | 17.94 | 0.826 |

## 6. 与原 Joint8 模型中相同三角度的对照

原 Joint8 联合监督模型的完整平均 MAE 是 13.17°，但其中包含较难的肩旋转和前臂旋转，不可直接与三角度平均值比较。为公平描述本轮变化，下表仅比较两者共同的三个角：

| 角度 | 原 Joint8 中该角 MAE (°) | 本轮三角度 MAE (°) | 变化 |
|---|---:|---:|---:|
| 肩屈伸 | 14.75 | 14.30 | 改善 0.45° |
| 肩外展/内收 | 12.98 | **10.28** | 改善 2.70° |
| 肘屈伸 | **14.01** | 15.19 | 退化 1.18° |
| 三角度平均 | 13.92 | **13.26** | 改善 0.66°（4.7%） |

## 7. 结果分析

1. 三角度任务在共同的三角度平均 MAE 上改善 4.7%，说明去除当前没有直接肌肉覆盖的轴向旋转目标后，网络可更集中地学习肩肘主要平面运动。
2. 最大改善来自肩外展/内收（12.98° → 10.28°）。这一角度与三角肌中束 sEMG 的生理功能最匹配，符合传感器覆盖预期。
3. 肘屈伸未改善（14.01° → 15.19°），说明肱二头/肱三头的肌电信息并不等价于绝对肘角；起始姿态、共同收缩、动作速度和跨受试者幅值差异仍会造成误差。
4. 本轮不报告腕部 FK 厘米误差。仅有 3 个角时，肩旋转、胸锁/肩胛带和前臂旋转均未知，若强行固定它们再做 FK，会把缺失自由度的结构误差误当成三角度网络误差。

## 8. 明天组会可用结论

> 我们将 ULTRA-MoCap 任务收敛为与三路 sEMG 肌肉覆盖一致的肩屈伸、肩外展/内收和肘屈伸预测。复用双分支 CNN-GRU 融合网络后，测试集三角度平均 MAE 为 13.26°，相较 Joint8 模型中相同三个角的平均误差降低 4.7%。其中三角肌中束覆盖的肩外展/内收改善最明显，达到 10.28°。该结果支持“按肌肉可观测性定义阶段性输出空间”的设计；肩旋转、前臂旋转和腕部角度将在具备六路前臂 sEMG 的自采数据阶段扩展。

## 9. 限制与下一步

该三角度模型适合验证肩肘姿态估计，但不是完整末端姿态模仿模型。后续应在自采的六路 sEMG、四颗 IMU 与深度相机标签数据上，补充前臂屈肌/伸肌信息，再扩展到前臂旋转、腕部角度和 Franka 重定向。

本轮正式产物：

- 配置：`experiments/joint3_shoulder_elbow_dual_branch_v1.yaml`；
- 数据：`data/ultra_joint3_shoulder_elbow_v1.npz`；
- 指标：`outputs/experiments/joint3_shoulder_elbow_dual_branch_v1/metrics/ultra_mocap_joint3_shoulder_elbow_dual_branch_v1_dual_branch_test.json`；
- 最佳权重：`outputs/experiments/joint3_shoulder_elbow_dual_branch_v1/checkpoints/ultra_mocap_joint3_shoulder_elbow_dual_branch_v1_dual_branch_best.pt`。

## 10. 随机初始化复现实验

为检验单次训练的稳定性，以完全相同的结构、数据和超参数追加训练了 seed 7 与 seed 2026。所有单模型及其等权组合仅用 P10–P11 的原始角度 MAE 选择。

| 候选 | 验证集 MAE (°) | 测试集 MAE (°) | 结论 |
|---|---:|---:|---|
| seed 42（原三角度模型） | 15.35 | 13.26 | 原始正式结果 |
| seed 7 | 16.01 | **12.23** | 测试观察值最好，但未被验证集选中 |
| seed 2026 | 14.71 | 15.06 | 验证较好，测试较差 |
| 验证集选中的 seed42 + seed2026 等权集成 | **14.53** | 13.53 | 未提升测试精度 |

该结果不能将 seed 7 的 12.23°表述为“验证集选出的最终泛化模型”，因为它在 P10–P11 上不是最优。它说明模型对随机初始化和受试者组合较敏感：P10–P11 与 P12–P13 的分布差异仍是主要问题。

明天组会建议如实报告两个层次：

1. 可复现的正式三角度单模型结果为 13.26°；
2. seed 7 达到 12.23°，表明现有输入与网络存在进一步优化空间，但需要以更稳健的受试者交叉验证、姿态校准或更多自采数据确认，不能视作已完成的泛化提升。

完整组合选择记录位于：`outputs/experiments/joint3_shoulder_elbow_ensemble_v1/ensemble_selection.json`。
