# 自采数据文件格式参考

只有当硬件录制程序或导出转换程序需要确定列名时才看本文件。日常操作从 `NNtrain` 根目录的 `START_HERE.md` 开始。

## semg.csv

```csv
timestamp_s,emg_1,emg_2,emg_3,emg_4,emg_5,emg_6
0.000000,...
0.000500,...
```

`timestamp_s` 必须是秒。2000 Hz时相邻时间戳约为0.0005秒。

## imu.csv

一个IMU的默认列：

```csv
timestamp_s,acc_x_1,acc_y_1,acc_z_1,gyro_x_1,gyro_y_1,gyro_z_1
```

多个IMU继续使用 `_2`、`_3`。列名和顺序必须与 `metadata.yaml` 的 `imu.channels` 完全一致。

## depth_skeleton.csv

必须包含 `timestamp_s`、左右肩、spine_chest、左右手腕的x/y/z米制坐标，以及左右手腕置信度。完整表头由 `scripts/create_recording_trial.py` 自动生成。

## metadata.yaml

由trial创建脚本自动生成，必须根据真实设备核对采样率、IMU数量和通道、50 Hz工频、设备间时间偏移、使用侧手臂和设备内部已有滤波。

## dataset_manifest.csv

```csv
subject_id,session_id,trial_id,split,use
subject_001,session_001,trial_001,train,1
```

`use=0` 可以排除坏trial而不删除原始数据。正式跨人实验中，同一个 `subject_id` 不得出现在多个split。
