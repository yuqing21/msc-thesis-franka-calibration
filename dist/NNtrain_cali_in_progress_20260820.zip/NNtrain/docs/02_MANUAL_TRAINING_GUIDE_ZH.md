# 完整 ULTRA-MoCap → NNtrain 第一次手动操作指南

## 1. 阅读方式

这份指南假设你是第一次独立完成深度学习工程。每一步都说明：

- 这一步在做什么；
- 为什么必须做；
- 应该看到什么结果；
- 哪些命令现在能运行；
- 哪些只是下一阶段要实现的接口。

完整目标：

```text
下载完整13人ULTRA-MoCap
→ 检查原始文件
→ 生成统一NPZ训练数据
→ 训练sEMG+IMU双分支网络
→ 在未见受试者上测试手腕XYZ
→ 生成组会可展示的模型、指标和曲线
```

本次不做关节角主任务，不混合现有设备数据，也不修改网络去适配某个硬件。

### 1.1 当前哪些部分已经存在

| 内容 | 状态 |
|---|---|
| Python虚拟环境 | 已存在 |
| 网络结构 | 已存在 |
| 训练器和评估器 | 已存在 |
| synthetic smoke | 可运行 |
| ULTRA完整数据 | 已下载、校验并解压 |
| ULTRA适配器 | 已实现并通过测试 |
| ULTRA正式配置 | 已创建 |
| ULTRA训练NPZ | 已生成并通过预检查 |
| ULTRA正式训练 | 尚未开始 |

---

## 2. 先理解整个程序怎样工作

### 2.1 原始数据不能直接进入网络

网络不直接读取官方 ZIP、CSV 或 `.trc`。中间必须有数据适配器：

```text
官方原始文件
→ 数据适配器
→ 统一NPZ
→ DataLoader分批读取
→ 神经网络
→ Loss
→ 参数更新
```

适配器解决“不同数据集格式不同”的问题；NNtrain 解决“如何训练网络”的问题。

### 2.2 一个样本是什么

本项目把500 ms连续信号作为一个样本。对齐到100 Hz后：

```text
一个样本 = 50个连续时间点
```

该样本包含：

```text
sEMG窗口  [50,Cs]
IMU窗口   [50,Ci]
正确答案  [x,y,z]
```

正确答案取窗口最后一个时间点的 Vicon 手腕位置。

### 2.3 `N`、`B`、`T`、`Cs`、`Ci`

```text
N  = 某个split中全部窗口数
B  = 每次训练取出的窗口数，即batch size
T  = 每个窗口的时间点数，本项目为50
Cs = sEMG通道数
Ci = IMU特征数
```

NPZ 保存的形状：

```text
sEMG  [N,50,Cs]
IMU   [N,50,Ci]
XYZ   [N,3]
```

DataLoader 从 `N` 个窗口中每次取 `B` 个，于是网络实际看到：

```text
sEMG  [B,50,Cs]
IMU   [B,50,Ci]
XYZ   [B,3]
```

`B` 不需要写进数据文件，它由训练配置和显存决定。

### 2.4 一次训练循环

```text
取一个batch
→ 网络输出预测XYZ
→ 用Vicon XYZ计算Loss
→ 反向传播
→ Adam更新参数
→ 取下一个batch
```

训练集全部 batch 学习一遍叫一个 epoch。每个 epoch 后在 validation 上检查，
validation 不更新参数。

---

## 3. 认识 NNtrain 目录

```text
NNtrain/
├─ configs/                       实验参数
├─ data/
│  ├─ downloads/                  下载的三个ZIP
│  ├─ raw/ultra_mocap/            解压并合并后的只读原始数据
│  └─ processed/ultra_mocap/      适配器生成的NPZ和审计文件
├─ docs/                          当前说明
├─ outputs/
│  ├─ checkpoints/                最佳模型权重
│  ├─ metrics/                    JSON指标和训练历史
│  ├─ figures/                    曲线图
│  └─ logs/                       实际运行配置
├─ scripts/
│  ├─ check_cuda.py               检查CPU/GPU
│  ├─ train.py                    训练入口
│  └─ evaluate.py                 重新评估checkpoint
├─ src/bishe_ai/
│  ├─ data/                       数据和窗口工具
│  ├─ models/regressors.py        网络结构
│  ├─ training/engine.py          训练循环
│  ├─ evaluation/                 指标和绘图
│  └─ pipeline.py                 串起完整训练过程
└─ tests/                         单元测试
```

推荐读代码的顺序：

```text
configs/synthetic_smoke.yaml
→ scripts/train.py
→ src/bishe_ai/config.py
→ src/bishe_ai/pipeline.py
→ src/bishe_ai/data/datasets.py
→ src/bishe_ai/models/regressors.py
→ src/bishe_ai/training/engine.py
→ src/bishe_ai/evaluation/metrics.py
```

第一次不用逐行看懂数学实现，先知道每个文件负责哪一步。

---

## 4. 阶段A：环境和代码自检（现在可以运行）

### 4.1 进入正确目录

```powershell
Set-Location F:\bishe_ai_project\NNtrain
```

后续命令默认都在这里运行。

### 4.2 检查固定解释器

```powershell
.\.venv\Scripts\python.exe --version
```

本项目只使用：

```text
F:\bishe_ai_project\NNtrain\.venv\Scripts\python.exe
```

不要混用系统 Python 或其他 Conda 环境，否则很容易出现“明明安装了库却找不到”的
问题。

### 4.3 检查依赖

```powershell
.\.venv\Scripts\python.exe -m pip check
```

如果显示 `No broken requirements found`，说明已安装包之间没有明显版本冲突。

需要重新安装时才运行：

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-lock.txt
.\.venv\Scripts\python.exe -m pip install -e .
```

### 4.4 检查 GPU

```powershell
.\.venv\Scripts\python.exe scripts\check_cuda.py
```

理解输出：

- `cuda available=True`：PyTorch 可以使用 NVIDIA GPU；
- `cuda available=False`：使用 CPU，也能跑测试，但正式训练更慢；
- GPU 型号只影响速度，不改变数据和网络定义。

### 4.5 运行单元测试

从项目上一级运行可以避免当前 Windows 终端的退出等待问题：

```powershell
Set-Location F:\bishe_ai_project
.\NNtrain\.venv\Scripts\python.exe -m pytest -q NNtrain\tests `
  --rootdir=NNtrain -c NNtrain\pyproject.toml
Set-Location F:\bishe_ai_project\NNtrain
```

测试通过意味着窗口、坐标变换、模型形状和指标等基础代码符合预期；它不代表
ULTRA 原始数据已经能读取。

### 4.6 运行 synthetic smoke

```powershell
.\.venv\Scripts\python.exe scripts\train.py `
  --config configs\synthetic_smoke.yaml
```

synthetic 表示程序生成假的随机数据。它用于检查：

- DataLoader 能否产生 batch；
- 网络能否前向计算；
- Loss 能否反向传播；
- checkpoint、JSON和图片能否写出。

应看到类似：

```text
device=cpu 或 cuda
batch_devices=semg:..., imu:..., target:...
forward_output_shape=(某个batch大小, 3)
```

最后一维必须是3，因为输出为 `x,y,z`。synthetic 指标没有论文意义。

---

## 5. 阶段B：下载完整 ULTRA-MoCap

官方页面：

- [Figshare 数据页](https://doi.org/10.6084/m9.figshare.28751156.v1)
- [Scientific Data 论文](https://www.nature.com/articles/s41597-026-06687-5)

本次下载三个部分，不再只下载 P01～P06。

### 5.1 建立下载目录

```powershell
New-Item -ItemType Directory -Force -Path .\data\downloads
```

从官方页面手动下载后，为避免后续命令受官方文件名影响，可以在本地统一命名：

```text
data/downloads/ULTra-MoCap-processed.zip
data/downloads/ULTra-MoCap-raw-0.zip
data/downloads/ULTra-MoCap-raw-1.zip
```

### 5.2 三个文件的校验信息

| 本地文件名 | 字节数 | MD5 |
|---|---:|---|
| `ULTra-MoCap-processed.zip` | 710,577,809 | `e987a7327249290624f0dfb04504aea5` |
| `ULTra-MoCap-raw-0.zip` | 2,347,794,170 | `603706e4db8707ecacdc88ef419ae589` |
| `ULTra-MoCap-raw-1.zip` | 2,119,742,453 | `c80080b2ba1fe385247b3786978d9d6e` |

总大小约4.82 GiB。解压后需要更多空间，应提前保证磁盘余量。

### 5.3 检查实际字节数

```powershell
Get-Item .\data\downloads\ULTra-MoCap-*.zip |
  Select-Object Name, Length
```

`Length` 必须逐个匹配上表。浏览器显示“下载完成”不等于文件一定完整。

### 5.4 检查 MD5

```powershell
Get-FileHash .\data\downloads\ULTra-MoCap-processed.zip -Algorithm MD5
Get-FileHash .\data\downloads\ULTra-MoCap-raw-0.zip -Algorithm MD5
Get-FileHash .\data\downloads\ULTra-MoCap-raw-1.zip -Algorithm MD5
```

MD5 是文件内容的指纹。任何一个字符不同都应重新下载该文件，不能继续解压训练。

---

## 6. 阶段C：解压并合并完整目录

三个压缩包内部各自带有一层目录：

```text
ULTra-MoCap-processed/All_subjects_data.h5
ULTra-MoCap-raw-0/P01 ... P07
ULTra-MoCap-raw-1/P08 ... P13
```

因此不能把普通的 `Expand-Archive` 直接指向最终根目录，否则会保留这三层不同的
外壳目录。下面使用 Windows 自带的 `tar`，通过 `--strip-components=1` 去掉压缩包
内部的第一层目录。

先创建原始受试者数据目录，以及官方 processed 文件的独立存放目录：

```powershell
New-Item -ItemType Directory -Force `
  -Path .\data\raw\ultra_mocap\ULTRA-MoCap

New-Item -ItemType Directory -Force `
  -Path .\data\raw\ultra_mocap\official_processed
```

然后执行解压：

```powershell
tar -xf .\data\downloads\ULTra-MoCap-raw-0.zip `
  -C .\data\raw\ultra_mocap\ULTRA-MoCap `
  --strip-components=1

tar -xf .\data\downloads\ULTra-MoCap-raw-1.zip `
  -C .\data\raw\ultra_mocap\ULTRA-MoCap `
  --strip-components=1

tar -xf .\data\downloads\ULTra-MoCap-processed.zip `
  -C .\data\raw\ultra_mocap\official_processed `
  --strip-components=1
```

最终应得到：

```text
data/raw/ultra_mocap/
├─ ULTRA-MoCap/
│  ├─ P01/
│  ├─ ...
│  └─ P13/
└─ official_processed/
   └─ All_subjects_data.h5
```

`P01`～`P13` 是后续从原始 sEMG、IMU 和 Vicon 数据构造 XYZ 标签时使用的主体。
官方的 `All_subjects_data.h5` 单独保存，避免与原始受试者目录混在一起。不要修改
解压后的原文件；适配结果单独写入 `data/processed`。

### 6.1 生成文件清单

```powershell
Get-ChildItem .\data\raw\ultra_mocap\ULTRA-MoCap -Recurse -File |
  Select-Object FullName, Length |
  Export-Csv .\data\raw\ultra_mocap\inventory.csv `
    -NoTypeInformation -Encoding UTF8
```

清单用于以后证明实际使用了哪些文件，也便于发现缺少的受试者。

### 6.2 检查13名受试者

```powershell
Get-ChildItem .\data\raw\ultra_mocap\ULTRA-MoCap -Directory |
  Where-Object Name -Match '^P(0[1-9]|1[0-3])$' |
  Sort-Object Name |
  Select-Object Name
```

输出必须从 `P01` 连续到 `P13`，总计13个目录。

---

## 7. 阶段D：第一次人工认识原始数据

在编写适配器前，先打开少量文本文件检查。不能凭论文描述猜代码中的列名。

### 7.1 每名受试者应确认

- `Static_Pxx.trc` 是否存在（用于认识原数据；dynamic_v2标签不依赖它）；
- 个体 `.osim` 和 Scaling XML 是否存在；
- 5类动作目录是否齐全；
- 每个动作有哪些速度或条件；
- EMG、IMU、Raw Marker 文件能否按 trial 一一对应。

### 7.2 sEMG 应确认

- 文件头有几行说明；
- 时间列叫什么；
- 3个通道实际叫什么；
- 单位是什么；
- 每条 trial 实际采样率；
- 是否有 NaN、空行或明显饱和。

### 7.3 IMU 应确认

- 6个传感器的名称和身体位置；
- 每个传感器有哪些加速度和角速度列；
- 单位是 `g`、`m/s²`、`deg/s` 还是 `rad/s`；
- 坐标轴顺序是否固定；
- 时间轴是否与 EMG 共用。

如果使用6个IMU的加速度和角速度，常见示例通道数是：

```text
6个IMU × (加速度3轴 + 角速度3轴) = Ci 36
```

但最终 `Ci` 必须由真实文件确认。

### 7.4 Vicon `.trc` 应确认

- 单位是毫米还是米；
- 帧率是否100 Hz；
- `RRAD`、`RULN`、`LSHO`、`RSHO`、`STUR` 五个标记的精确列名；
- 缺失标记如何表示；
- 动态 trial 中五个必需标记是否同时有效。

文件名和列名必须写进适配审计报告，不能只存在程序员记忆中。

---

## 8. 固定受试者划分

使用全部13名受试者：

```text
P01 P02 P03 P04 P05 P06 P07 P08 P09 → train
P10 P11                             → validation
P12 P13                             → test
```

### 为什么是9/2/2

- train 需要大部分数据学习参数；
- validation 至少需要多个独立受试者观察模型选择是否稳定；
- test 保留两个从未参加训练和调参的人，用来报告跨受试者结果。

### 什么是数据泄漏

如果 P12 的部分窗口进入 train，剩余窗口进入 test，网络已经见过 P12 的肌电
特征，这就不是未见受试者测试。正确顺序一定是：

```text
先按人分组
→ 再处理各人的trial
→ 最后生成窗口
```

---

## 9. 阶段E：ULTRA 适配器的职责

当前适配器主入口为 `BaselineTest_Mocap/prepare_ultra_mocap.py`，兼容入口为
`scripts/prepare_ultra_mocap.py`。它已经实现：

```text
1. 发现P01～P13和全部trial
2. 建立EMG/IMU/Raw Marker对应关系
3. 读取并验证时间戳
4. 统一传感器顺序和物理单位
5. 处理Vicon短缺口
6. 每帧用动态 `LSHO`、`RSHO`、`STUR` 建立当时的人体坐标轴
7. 用动态 `RSHO` 作逐帧原点，将 `(RRAD+RULN)/2` 转成右手腕XYZ（米）
8. 找到三种模态的共同时间段
9. 预处理并对齐到100 Hz
10. 按9/2/2受试者划分
11. 只用train计算标准化统计量
12. 在每条trial内部生成50步窗口
13. 保存NPZ和审计JSON/YAML
```

### 9.1 为什么适配器需要测试

网络训练即使能运行，也可能在错误标签上学习。适配器测试至少应覆盖：

- `.trc` 列名和单位解析；
- trial 配对；
- 标记缺失处理；
- 身体坐标轴正交；
- 窗口不跨 trial；
- P01～P13 不跨 split；
- 标准化只使用 P01～P09；
- 结果没有 NaN/Inf。

### 9.2 已实现的运行接口

```powershell
.\.venv\Scripts\python.exe .\BaselineTest_Mocap\prepare_ultra_mocap.py
```

默认输入为 `data/raw/ultra_mocap/ULTRA-MoCap`，输出为
`BaselineTest_Mocap/data/ultra_full_xyz_dynamic_v2.npz`，审计报告为
`BaselineTest_Mocap/data/ultra_full_xyz_dynamic_v2_audit.json`。旧的
`ultra_full_xyz_v1.npz` 是固定静态轴的历史基线，只保留用于问题对照，正式训练
不要再选它。

---

## 10. NPZ 数据合同

“数据合同”指训练器要求文件必须包含哪些数组、形状和含义。

```text
semg_train  [N_train,50,Cs]
semg_val    [N_val,50,Cs]
semg_test   [N_test,50,Cs]

imu_train   [N_train,50,Ci]
imu_val     [N_val,50,Ci]
imu_test    [N_test,50,Ci]

target_train [N_train,3]
target_val   [N_val,3]
target_test  [N_test,3]
```

同一个 split 中，三种数组的第一维必须相等。例如：

```text
semg_train.shape[0]
= imu_train.shape[0]
= target_train.shape[0]
```

因为第 `i` 个 sEMG窗口、第 `i` 个IMU窗口和第 `i` 个XYZ必须属于同一时刻。

标准化数组：

```text
semg_mean、semg_scale
imu_mean、imu_scale
target_mean、target_scale
```

还应额外保存审计文件，记录：

- 数据 DOI 和版本；
- 三个 ZIP 的 MD5；
- 9/2/2受试者划分；
- 真实传感器、通道和标记名称；
- 物理单位转换；
- 滤波、重采样和窗口参数；
- 删除或跳过的 trial 及原因；
- 每个 split 的 trial 数、时长和窗口数；
- Vicon 缺失率。

---

## 11. 如何人工验收准备好的数据

正式训练前必须检查：

1. `Cs` 和 `Ci` 与通道清单一致；
2. 所有数组为有限数，没有 NaN/Inf；
3. `target` 单位为米；
4. 人体手腕相对肩部距离处于合理尺度；
5. 随机绘制多条 XYZ 曲线，连续且方向合理；
6. train/val/test 均非空；
7. P01～P13 各出现且只出现于一个 split；
8. 重复运行适配器结果一致；
9. 处理结果没有覆盖原始数据。

特别注意：数组形状正确不代表语义正确。把左腕列误当右腕列，网络仍然可以训练，
所以必须画图和人工抽查。

---

## 12. 阶段F：正式训练配置

正式配置已创建为 `configs/ultra_mocap_xyz.yaml`：

```yaml
run:
  name: ultra_mocap_dynamic_v2_baseline
  seed: 42
  output_root: BaselineTest_Mocap/outputs/formal/dynamic_v2

data:
  kind: prepared_npz
  path: BaselineTest_Mocap/data/ultra_full_xyz_dynamic_v2.npz
  dataset_version: dynamic_body_frame_v2
  semg_channels: 3
  imu_channels: 36
  output_dim: 3
  window_steps: 50
  num_workers: 0

model:
  type: dual_branch
  conv_channels: 32
  gru_hidden: 48
  feature_dim: 64
  dropout: 0.1

training:
  device: auto
  batch_size: auto
  epochs: 50
  learning_rate: 0.001
  weight_decay: 0.0001
  loss: huber
  early_stopping_patience: 10
```

### 12.1 配置逐项解释

- `name`：本次实验名称，决定输出文件前缀；
- `seed`：固定随机数种子，帮助复现；
- `path`：准备好的 NPZ；
- `semg_channels: null`：从 NPZ 自动读取 `Cs`；
- `imu_channels: null`：从 NPZ 自动读取 `Ci`；
- `output_dim: 3`：输出 x、y、z；
- `window_steps: 50`：每个窗口50个时间点；
- `model.type`：主网络为双分支；
- `conv_channels`：卷积中间通道宽度；
- `gru_hidden`：GRU隐藏状态维度；
- `feature_dim`：每个分支最终特征维度；
- `dropout`：训练时随机屏蔽比例；
- `device: auto`：有CUDA就用GPU，否则用CPU；
- `batch_size: auto`：程序根据设备选择 batch 大小；
- `epochs`：最多训练50遍；
- `learning_rate`：每次参数更新幅度；
- `weight_decay`：抑制权重过大；
- `loss: huber`：使用Huber回归误差；
- `patience: 10`：验证集10轮不改善就停止。

第一次正式跑不要同时修改很多超参数。先用固定默认值证明 pipeline 正确，再做
有控制的比较。

---

## 13. 阶段G：启动正式训练

只有 NPZ、配置和适配测试都存在后运行。推荐先从工程根目录做只读预检查：

```powershell
Set-Location F:\bishe_ai_project
.\NNtrain\BaselineTest_Mocap\run_baseline.ps1 -CheckOnly
```

看到“仅检查模式结束，没有训练模型”后，再由你手动运行：

```powershell
.\NNtrain\BaselineTest_Mocap\run_baseline.ps1
```

### 13.1 启动时检查形状

应看到：

```text
batch_devices=semg:..., imu:..., target:...
forward_output_shape=(B, 3)
```

如果实际 batch size 是64，可能看到：

```text
forward_output_shape=(64, 3)
```

这表示一次输入64个窗口，每个窗口得到一个三维坐标。

### 13.2 每个 epoch 发生什么

```text
训练阶段：shuffle train → 前向 → loss → 反向 → 更新参数
验证阶段：固定val顺序 → 前向 → loss → 不更新参数
```

train loss 下降说明模型在学习训练数据；val loss 同时下降说明对未参与参数更新的
数据也在改善。如果 train 持续下降而 val 上升，通常是过拟合。

### 13.3 最佳模型怎样选择

不是自动保存最后一个 epoch，而是保存 validation loss 最好的 epoch。这样即使
后面开始过拟合，仍保留较好的 checkpoint。

---

## 14. 输出文件怎么读

默认文件：

```text
BaselineTest_Mocap/outputs/formal/dynamic_v2/checkpoints/*_best.pt
BaselineTest_Mocap/outputs/formal/dynamic_v2/metrics/*_history.json
BaselineTest_Mocap/outputs/formal/dynamic_v2/metrics/*_test.json
BaselineTest_Mocap/outputs/formal/dynamic_v2/figures/*_training.png
BaselineTest_Mocap/outputs/formal/dynamic_v2/figures/*_prediction.png
BaselineTest_Mocap/outputs/formal/dynamic_v2/logs/*_config.yaml
```

含义：

- `best.pt`：最佳权重、配置和标准化信息；
- `history.json`：每个 epoch 的 train/val 变化；
- `test.json`：P12、P13上的最终指标；
- `training.png`：训练曲线，用于看收敛和过拟合；
- `prediction.png`：真实与预测轨迹对比；
- `config.yaml`：本次实际使用的最终配置。

不要只保留 `.pt`。没有数据版本、split和配置，模型结果以后无法复现。

---

## 15. 重新评估 checkpoint

```powershell
Set-Location F:\bishe_ai_project\NNtrain
$checkpointPath = Get-ChildItem `
  .\BaselineTest_Mocap\outputs\formal\dynamic_v2\checkpoints\*_best.pt |
  Sort-Object LastWriteTime -Descending |
  Select-Object -First 1 -ExpandProperty FullName
.\.venv\Scripts\python.exe scripts\evaluate.py --checkpoint $checkpointPath
```

重新评估不会重新训练，只是加载保存的模型，在固定 test split 上重新计算指标。

---

## 16. 指标怎么理解

| 指标 | 意义 | 判断方向 |
|---|---|---|
| MAE x/y/z | 每个轴平均差多少 | 越小越好 |
| RMSE x/y/z | 对少量大误差更敏感 | 越小越好 |
| Pearson x/y/z | 轨迹变化趋势是否一致 | 越接近1越好 |
| Euclidean mean | 三维直线距离误差均值 | 越小越好 |
| Euclidean median | 三维距离误差中位数 | 越小越好 |

如果标签单位是米：

```text
0.01 m = 1 cm
0.05 m = 5 cm
0.10 m = 10 cm
```

不能只看 Pearson。预测轨迹整体偏移5 cm但形状相似时，Pearson 仍可能很高。

---

## 17. 对照实验

主网络跑通后，使用完全相同的 NPZ 和 split：

```powershell
.\.venv\Scripts\python.exe scripts\train.py `
  --config configs\ultra_mocap_xyz.yaml --model-type imu_only

.\.venv\Scripts\python.exe scripts\train.py `
  --config configs\ultra_mocap_xyz.yaml --model-type semg_only

.\.venv\Scripts\python.exe scripts\train.py `
  --config configs\ultra_mocap_xyz.yaml --model-type early_fusion

.\.venv\Scripts\python.exe scripts\train.py `
  --config configs\ultra_mocap_xyz.yaml --model-type dual_branch
```

对照实验回答：

- 单独 IMU 能做到什么程度；
- 单独 sEMG 能做到什么程度；
- 提前拼接和双分支融合谁更好；
- 双模态是否真的带来收益。

组会时间紧时，先完成 `dual_branch`；有余量再依次运行三个对照。

---

## 18. 怎样算“网络工程已经搭建好”

至少满足：

- 完整13人全部进入固定9/2/2划分；
- 真实 sEMG、IMU、Vicon 被正确解析和同步；
- 统一 NPZ 通过形状、单位、NaN和split检查；
- 模型前向输出 `[B,3]`；
- train/val loss 可以正常计算；
- 最佳 checkpoint 能保存并重新加载；
- P12、P13 test 指标能生成；
- 预测曲线能与真实曲线对比；
- 重复评估得到一致结果。

这证明的是训练工程和网络结构已能处理真实公开数据。

---

## 19. 以后自己的数据怎样接入

以后不修改 `regressors.py` 和训练循环，只需要让自采适配器输出：

```text
semg_train/val/test       [N,50,Cs_self]
imu_train/val/test        [N,50,Ci_self]
target_train/val/test     [N,3]
```

然后复制 ULTRA 配置并更换：

```yaml
run:
  name: self_recorded_xyz

data:
  path: data/processed/self_recorded/self_recorded_xyz_v1.npz
```

`Cs_self` 和 `Ci_self` 可以与 ULTRA 不同，网络会重新建立输入层。需要保持一致的
是：

- 输入都是500 ms同步窗口；
- 输出都是身体坐标系中的手腕 XYZ；
- train/val/test 先按受试者划分；
- 标准化只使用 train；
- 训练、评估和输出接口相同。

所以“录好自己的数据就能跑”准确含义是：

```text
录制原始数据
→ 运行自采适配器生成统一NPZ
→ 修改配置中的数据路径
→ 使用同一个train.py训练
```

---

## 20. 常见错误

### `Prepared dataset not found`

配置中的 NPZ 不存在。先检查：

```powershell
Test-Path .\BaselineTest_Mocap\data\ultra_full_xyz_dynamic_v2.npz
```

### sEMG 和 IMU 的 `N` 不一致

说明窗口没有一一对应，通常是同步裁剪或缺失处理错误。不能通过随意截断到最短
长度掩盖原因。

### XYZ 数值大到几百

很可能 `.trc` 使用毫米而程序没有转换成米。

### validation 很好，test 很差

先检查受试者是否泄漏、P12/P13标记映射、通道顺序和标准化，再考虑改网络。

### Loss 变成 NaN

检查原始缺失、插值边界、零标准差通道、异常值和学习率。先找到第一条异常
trial，不要直接把所有 NaN 替换成0。

### GPU利用率不高

这是小型时序网络，未必占满GPU。先确认张量确实在 CUDA，再考虑 batch size；
不能只凭任务管理器百分比判断失败。

### train loss 不下降

先检查标签与输入时间是否错位、标准化是否合理、XYZ是否几乎不变，然后再检查
学习率。输入与标签错位时，换更大的网络也学不会。

---

## 21. 实验记录模板

```text
实验名称：ultra_full_xyz_dual_branch
数据集：ULTRA-MoCap
数据版本：Figshare v1
processed MD5：e987a7327249290624f0dfb04504aea5
raw-0 MD5：603706e4db8707ecacdc88ef419ae589
raw-1 MD5：c80080b2ba1fe385247b3786978d9d6e
train：P01～P09
validation：P10～P11
test：P12～P13
sEMG字段：适配后填写
IMU字段和顺序：适配后填写
Vicon标记：适配后填写
XYZ单位：m
特征率：100 Hz
窗口/步长：500/250 ms
模型：dual_branch
seed：42
实际batch size：运行后填写
最佳epoch：运行后填写
checkpoint：完整路径
test指标：JSON完整路径
代码版本或修改日期：填写
异常或删除trial：填写
```

---

## 22. 最终检查表

- [ ] 固定解释器可用；
- [ ] 单元测试通过；
- [ ] synthetic smoke通过；
- [ ] processed、raw-0、raw-1全部下载；
- [ ] 三个文件字节数和MD5正确；
- [ ] 解压后P01～P13完整；
- [ ] sEMG、IMU、Vicon真实字段和单位已核对；
- [ ] ULTRA适配器已实现并有测试；
- [ ] split固定为P01～P09 / P10～P11 / P12～P13；
- [ ] NPZ形状和数据合同正确；
- [ ] NPZ无NaN/Inf；
- [ ] XYZ单位为米且随机曲线合理；
- [ ] `configs/ultra_mocap_xyz.yaml` 指向完整NPZ；
- [ ] 主网络成功保存checkpoint和test指标；
- [ ] checkpoint能重新评估；
- [ ] 组会图表和实验记录齐全。
