# NNtrain agent instructions

开始操作前先看 `README.md`。本工程有两个明确层次：

1. `src/bishe_ai/` 是可复用的 sEMG+IMU 训练、评估和数据处理实现；它最终服务于
   自采六路 sEMG、IMU 与深度相机 Ground Truth 数据集。
2. `BaselineTest_Mocap/` 仅使用 ULTRA-MoCap 公开数据验证模型和实验假设；它不是
   最终自采数据集，也不得替代自采实验结论。

所有训练代码、公开数据缓存、模型和结果只写入
`F:\bishe_ai_project\NNtrain`。唯一解释器是
`F:\bishe_ai_project\NNtrain\.venv\Scripts\python.exe`；不得新建第二套 Python
环境或混用系统 Python。

ULTRA processed、raw-0、raw-1 的下载与解压内容必须保持不可变。公开数据的任一
训练/验证/测试划分都必须是受试者独立；所有标准化器仅可在该实验 fold 的训练受试者
上拟合。不得将重叠窗口随机分散到不同受试者 split。

适配器必须从真实文件核对 sEMG、IMU、Vicon 的字段名、传感器位置、单位和时间戳，
不得猜测。原始高频 sEMG 需完成工频处理、带通、RMS/包络和抗混叠重采样。Vicon
标签由双肩和躯干构造身体坐标系，不能只减单个肩点而忽略旋转。

新增或修改数据准备、坐标变换、窗口、模型、损失、指标或 split 逻辑时必须加测试。
训练前至少运行：

```powershell
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe scripts\train.py --config configs\synthetic_smoke.yaml
```

不要提交真实数据、checkpoint、处理缓存、虚拟环境、日志和大图片。若第三方数据许可
不清楚，只保留下载说明和校验信息，不复制数据到仓库。
