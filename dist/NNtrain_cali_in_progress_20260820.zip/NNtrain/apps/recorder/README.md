# 硬件录制程序位置

这里将放置针对真实设备的录制程序。当前不会猜测未知硬件API。

拿到设备信息后，录制程序应同时获取sEMG、IMU和深度骨架数据，为每个样本写入统一实验时间 `timestamp_s`，并直接生成 `data/raw/self_recorded/subject/session/trial` 所需的三个CSV和metadata。

开始实现前需要：sEMG品牌/型号/SDK或导出格式、IMU品牌/型号/数量/SDK或导出格式、深度相机型号/骨架SDK，以及三者同步或触发能力。
