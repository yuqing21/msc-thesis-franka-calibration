from __future__ import annotations

import platform
import subprocess
import sys
import time

import torch


def main() -> int:
    print(f"Python version: {platform.python_version()}")
    print(f"Python executable: {sys.executable}")
    print(f"PyTorch version: {torch.__version__}")
    print(f"PyTorch CUDA runtime: {torch.version.cuda}")
    print(f"CUDA available: {torch.cuda.is_available()}")
    print(f"GPU count: {torch.cuda.device_count()}")
    if not torch.cuda.is_available():
        print("ERROR: CUDA is unavailable; verify the interpreter and CUDA wheel.", file=sys.stderr)
        return 1

    current = torch.cuda.current_device()
    properties = torch.cuda.get_device_properties(current)
    print(f"Current CUDA device: {current}")
    print(f"GPU name: {torch.cuda.get_device_name(current)}")
    print(f"Total VRAM: {properties.total_memory / 1024**3:.2f} GiB")
    print(f"Compute capability: {properties.major}.{properties.minor}")

    device = torch.device(f"cuda:{current}")
    before = torch.cuda.memory_allocated(device)
    left = torch.randn((4096, 4096), device=device)
    right = torch.randn((4096, 4096), device=device)
    started = time.perf_counter()
    result = left @ right
    torch.cuda.synchronize(device)
    elapsed = time.perf_counter() - started
    allocated = torch.cuda.memory_allocated(device)
    print(f"Matrix test shape: {tuple(result.shape)}")
    print(f"Matrix test elapsed: {elapsed:.4f} s")
    print(f"Result tensor device: {result.device}")
    print(f"Tensor is CUDA: {result.is_cuda}")
    print(f"Allocated VRAM during test: {(allocated - before) / 1024**2:.1f} MiB")
    try:
        snapshot = subprocess.run(
            [
                "nvidia-smi",
                "--query-gpu=name,memory.used,memory.total,utilization.gpu",
                "--format=csv,noheader",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        print(f"nvidia-smi during allocation: {snapshot.stdout.strip()}")
    except (OSError, subprocess.CalledProcessError) as error:
        print(f"WARNING: nvidia-smi snapshot failed: {error}")
    return 0 if result.is_cuda else 2


if __name__ == "__main__":
    raise SystemExit(main())

