from __future__ import annotations

import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASELINE_ROOT = ROOT / "BaselineTest_Mocap"
sys.path.insert(0, str(BASELINE_ROOT))

from prepare_ultra_mocap import main  # noqa: E402


if __name__ == "__main__":
    main()
