from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from bishe_ai.data.self_recorded import MANIFEST_COLUMNS, POINT_COLUMNS


def _identifier(prefix: str, value: str) -> str:
    text = value.strip()
    if text.startswith(prefix + "_"):
        return text
    return f"{prefix}_{int(text):03d}" if text.isdigit() else f"{prefix}_{text}"


def _write_header(path: Path, columns: list[str]) -> None:
    with path.open("x", newline="", encoding="utf-8") as handle:
        csv.writer(handle).writerow(columns)


def main() -> None:
    parser = argparse.ArgumentParser(description="Create one empty self-recorded trial folder")
    parser.add_argument("--subject", required=True, help="Example: 1 or subject_001")
    parser.add_argument("--session", required=True, help="Example: 1 or session_001")
    parser.add_argument("--trial", required=True, help="Example: 1 or trial_001")
    parser.add_argument("--split", required=True, choices=("train", "val", "test"))
    parser.add_argument("--movement", default="slow_circle")
    parser.add_argument("--arm", default="right", choices=("left", "right"))
    parser.add_argument("--semg-rate", type=float, default=2000.0)
    parser.add_argument("--imu-rate", type=float, default=200.0)
    parser.add_argument("--imu-count", type=int, default=1)
    parser.add_argument("--root", type=Path, default=ROOT / "data" / "raw" / "self_recorded")
    args = parser.parse_args()
    if args.imu_count <= 0:
        raise ValueError("--imu-count must be positive")

    subject = _identifier("subject", args.subject)
    session = _identifier("session", args.session)
    trial = _identifier("trial", args.trial)
    recording_root = args.root.resolve()
    directory = recording_root / subject / session / trial
    if directory.exists():
        raise FileExistsError(f"Trial directory already exists; it was not overwritten: {directory}")
    directory.mkdir(parents=True)

    semg_channels = [f"emg_{index}" for index in range(1, 7)]
    imu_channels = [
        f"{quantity}_{axis}_{sensor}"
        for sensor in range(1, args.imu_count + 1)
        for quantity in ("acc", "gyro")
        for axis in "xyz"
    ]
    depth_columns = ["timestamp_s"]
    for name in ("left_shoulder", "right_shoulder", "spine_chest", "left_wrist", "right_wrist"):
        depth_columns.extend(POINT_COLUMNS[name])
    depth_columns.extend(("left_wrist_confidence", "right_wrist_confidence"))
    _write_header(directory / "semg.csv", ["timestamp_s", *semg_channels])
    _write_header(directory / "imu.csv", ["timestamp_s", *imu_channels])
    _write_header(directory / "depth_skeleton.csv", depth_columns)

    metadata = {
        "subject_id": subject,
        "session_id": session,
        "trial_id": trial,
        "movement": args.movement,
        "arm": args.arm,
        "calibration_seconds": 3.0,
        "power_line_hz": 50.0,
        "timestamps": "seconds_on_one_common_recording_clock",
        "semg": {
            "sample_rate_hz": args.semg_rate,
            "time_offset_s": 0.0,
            "channels": semg_channels,
            "bandpass_hz": [20.0, 450.0],
            "rms_window_ms": 50.0,
        },
        "imu": {
            "sample_rate_hz": args.imu_rate,
            "time_offset_s": 0.0,
            "channels": imu_channels,
            "lowpass_hz": 20.0,
        },
        "depth": {
            "time_offset_s": 0.0,
            "wrist_confidence_threshold": 0.5,
            "maximum_gap_s": 0.2,
            "position_unit": "meter",
        },
    }
    (directory / "metadata.yaml").write_text(
        yaml.safe_dump(metadata, allow_unicode=True, sort_keys=False), encoding="utf-8"
    )

    manifest = recording_root / "dataset_manifest.csv"
    manifest.parent.mkdir(parents=True, exist_ok=True)
    exists = manifest.exists()
    with manifest.open("a", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(MANIFEST_COLUMNS))
        if not exists:
            writer.writeheader()
        writer.writerow(
            {
                "subject_id": subject,
                "session_id": session,
                "trial_id": trial,
                "split": args.split,
                "use": 1,
            }
        )
    print(f"Created: {directory}")
    print("Next: replace the three header-only CSV files with synchronized recorded samples.")


if __name__ == "__main__":
    main()
