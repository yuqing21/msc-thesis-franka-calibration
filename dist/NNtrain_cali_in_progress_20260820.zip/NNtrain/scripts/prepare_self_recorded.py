from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from bishe_ai.data.self_recorded import load_manifest, load_recorded_trial, trial_directory
from bishe_ai.data.windows import Standardizer, TrialData, make_windows


def _integer_steps(milliseconds: float, rate: float, name: str) -> int:
    exact = milliseconds * rate / 1000.0
    rounded = round(exact)
    if rounded <= 0 or not np.isclose(exact, rounded):
        raise ValueError(f"{name}={milliseconds} ms is not an integer number of steps at {rate} Hz")
    return int(rounded)


def main() -> None:
    parser = argparse.ArgumentParser(description="Prepare synchronized self-recorded sEMG/IMU/XYZ data")
    parser.add_argument("--root", type=Path, default=ROOT / "data" / "raw" / "self_recorded")
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / "data" / "processed" / "self_recorded" / "self_recorded_xyz_v1.npz",
    )
    parser.add_argument("--feature-rate", type=float, default=100.0)
    parser.add_argument("--window-ms", type=float, default=500.0)
    parser.add_argument("--stride-ms", type=float, default=250.0)
    parser.add_argument("--allow-subject-overlap", action="store_true")
    args = parser.parse_args()
    root = args.root.resolve()
    manifest = load_manifest(root, args.allow_subject_overlap)
    trials_by_split: dict[str, list[TrialData]] = {name: [] for name in ("train", "val", "test")}
    diagnostics = []
    for _, row in manifest.iterrows():
        trial, report = load_recorded_trial(trial_directory(root, row), args.feature_rate)
        trials_by_split[row["split"]].append(trial)
        diagnostics.append({"split": row["split"], **report})
    empty = [name for name, trials in trials_by_split.items() if not trials]
    if empty:
        raise ValueError(f"Every split needs at least one active trial; empty={empty}")

    semg_scaler = Standardizer().fit(trial.semg for trial in trials_by_split["train"])
    imu_scaler = Standardizer().fit(trial.imu for trial in trials_by_split["train"])
    target_scaler = Standardizer().fit(trial.target for trial in trials_by_split["train"])
    window_steps = _integer_steps(args.window_ms, args.feature_rate, "window-ms")
    stride_steps = _integer_steps(args.stride_ms, args.feature_rate, "stride-ms")
    arrays: dict[str, np.ndarray] = {}
    window_counts: dict[str, int] = {}
    for split, trials in trials_by_split.items():
        standardized = [
            TrialData(
                subject=trial.subject,
                trial=trial.trial,
                semg=semg_scaler.transform(trial.semg),
                imu=imu_scaler.transform(trial.imu),
                target=target_scaler.transform(trial.target),
            )
            for trial in trials
        ]
        semg, imu, target, _ = make_windows(standardized, window_steps, stride_steps)
        arrays[f"semg_{split}"] = semg
        arrays[f"imu_{split}"] = imu
        arrays[f"target_{split}"] = target
        window_counts[split] = len(target)
        print(f"{split}: semg={semg.shape} imu={imu.shape} target={target.shape}")

    metadata = {
        "task": "self_recorded_semg_imu_to_wrist_xyz_body_frame",
        "target_unit": "meter",
        "feature_rate_hz": args.feature_rate,
        "window_steps": window_steps,
        "stride_steps": stride_steps,
        "window_counts": window_counts,
        "allow_subject_overlap": args.allow_subject_overlap,
        "trials": diagnostics,
    }
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        output,
        **arrays,
        semg_mean=semg_scaler.mean.astype(np.float32),
        semg_scale=semg_scaler.scale.astype(np.float32),
        imu_mean=imu_scaler.mean.astype(np.float32),
        imu_scale=imu_scaler.scale.astype(np.float32),
        target_mean=target_scaler.mean.astype(np.float32),
        target_scale=target_scaler.scale.astype(np.float32),
        metadata_json=np.asarray(json.dumps(metadata, ensure_ascii=False)),
    )
    print(f"Prepared training data: {output}")


if __name__ == "__main__":
    main()
