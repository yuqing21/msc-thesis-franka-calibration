from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from bishe_ai.config import load_config
from bishe_ai.pipeline import run_training


def main() -> None:
    parser = argparse.ArgumentParser(description="Train a configured multimodal regression model")
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument(
        "--model-type",
        choices=(
            "imu_only",
            "semg_only",
            "early_fusion",
            "dual_branch",
            "imu_guided_emg_gate",
            "attention_gated_axis_heads",
        ),
        help="Override model.type for a controlled ablation run",
    )
    args = parser.parse_args()
    config = load_config(args.config)
    if args.model_type:
        config["model"]["type"] = args.model_type
    run_training(config)


if __name__ == "__main__":
    main()
