from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from bishe_ai.data.self_recorded import load_manifest, load_recorded_trial, trial_directory


def main() -> None:
    parser = argparse.ArgumentParser(description="Validate self-recorded files before training")
    parser.add_argument("--root", type=Path, default=ROOT / "data" / "raw" / "self_recorded")
    parser.add_argument("--feature-rate", type=float, default=100.0)
    parser.add_argument("--allow-subject-overlap", action="store_true")
    args = parser.parse_args()
    recording_root = args.root.resolve()
    manifest = load_manifest(recording_root, args.allow_subject_overlap)
    failures: list[str] = []
    for _, row in manifest.iterrows():
        directory = trial_directory(recording_root, row)
        try:
            _, diagnostics = load_recorded_trial(directory, args.feature_rate)
            print(json.dumps({"status": "OK", **diagnostics}, ensure_ascii=False))
        except Exception as error:  # report every bad trial in one run
            failures.append(f"{directory}: {type(error).__name__}: {error}")
            print(f"ERROR {failures[-1]}")
    if failures:
        raise SystemExit(f"Validation failed for {len(failures)} trial(s). Fix them before preparing data.")
    print(f"All {len(manifest)} active trial(s) are valid.")


if __name__ == "__main__":
    main()
