from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from bishe_ai.pipeline import evaluate_checkpoint


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate a saved checkpoint on its test split")
    parser.add_argument("--checkpoint", type=Path, required=True)
    args = parser.parse_args()
    metrics = evaluate_checkpoint(args.checkpoint)
    print(json.dumps(metrics, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()

