from __future__ import annotations

import numpy as np
import pytest

from bishe_ai.data.loso import add_imu_magnitude_features, rotating_loso_split


def test_rotating_loso_p13_is_disjoint_and_wraps_validation() -> None:
    subjects = [f"P{i:02d}" for i in range(1, 14)]
    split = rotating_loso_split("P13", subjects)
    assert split["test"] == "P13"
    assert split["val"] == ["P01", "P02"]
    assert len(split["train"]) == 10
    assert not (set(split["train"]) & set(split["val"]))
    assert split["test"] not in split["train"]
    assert split["test"] not in split["val"]


def test_add_imu_magnitude_features_appends_orientation_invariant_norms() -> None:
    rng = np.random.default_rng(0)
    imu = rng.normal(size=(2, 3, 12)).astype(np.float32)  # 2 mock sensors, 6 channels each
    expanded = add_imu_magnitude_features(imu, sensors=2)
    assert expanded.shape == (2, 3, 12 + 4)

    accel0 = imu[..., 0:3]
    gyro0 = imu[..., 3:6]
    accel1 = imu[..., 6:9]
    gyro1 = imu[..., 9:12]
    assert np.allclose(expanded[..., 12], np.linalg.norm(accel0, axis=-1), atol=1e-5)
    assert np.allclose(expanded[..., 13], np.linalg.norm(gyro0, axis=-1), atol=1e-5)
    assert np.allclose(expanded[..., 14], np.linalg.norm(accel1, axis=-1), atol=1e-5)
    assert np.allclose(expanded[..., 15], np.linalg.norm(gyro1, axis=-1), atol=1e-5)


def test_add_imu_magnitude_features_is_rotation_invariant() -> None:
    rng = np.random.default_rng(1)
    imu = rng.normal(size=(2, 3, 12)).astype(np.float32)
    theta = 0.7
    cos, sin = np.cos(theta), np.sin(theta)
    rotation = np.array([[cos, -sin, 0], [sin, cos, 0], [0, 0, 1]], dtype=np.float64)
    rotated = imu.copy()
    rotated[..., 0:3] = imu[..., 0:3] @ rotation.T

    original = add_imu_magnitude_features(imu, sensors=2)
    after_rotation = add_imu_magnitude_features(rotated, sensors=2)
    assert np.allclose(after_rotation[..., 12], original[..., 12], atol=1e-4)


def test_add_imu_magnitude_features_default_sensor_count_matches_ultra_layout() -> None:
    rng = np.random.default_rng(2)
    imu = rng.normal(size=(4, 50, 36)).astype(np.float32)
    expanded = add_imu_magnitude_features(imu)
    assert expanded.shape == (4, 50, 48)


def test_add_imu_magnitude_features_rejects_wrong_channel_count() -> None:
    with pytest.raises(ValueError, match="sensors\\*6"):
        add_imu_magnitude_features(np.zeros((2, 3, 10)), sensors=2)
