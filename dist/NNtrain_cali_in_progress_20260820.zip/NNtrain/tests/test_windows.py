from __future__ import annotations

import numpy as np

from bishe_ai.data.windows import Standardizer, TrialData, make_windows, split_trials


def _trial(subject: str, trial: str, offset: float = 0.0) -> TrialData:
    time = 30
    return TrialData(
        subject=subject,
        trial=trial,
        semg=np.full((time, 3), offset, dtype=np.float32),
        imu=np.full((time, 6), offset + 1, dtype=np.float32),
        target=np.arange(time * 3, dtype=np.float32).reshape(time, 3),
    )


def test_split_is_subject_disjoint_before_windowing() -> None:
    trials = [_trial(f"S{index}", "T1", float(index)) for index in range(8)]
    splits = split_trials(trials, val_fraction=0.25, test_fraction=0.25, seed=5)
    subject_sets = {name: {trial.subject for trial in values} for name, values in splits.items()}
    assert subject_sets["train"].isdisjoint(subject_sets["val"])
    assert subject_sets["train"].isdisjoint(subject_sets["test"])
    assert subject_sets["val"].isdisjoint(subject_sets["test"])


def test_window_label_is_endpoint_plus_horizon() -> None:
    trial = _trial("S1", "T1")
    semg, imu, target, metadata = make_windows([trial], 10, 5, horizon_steps=2)
    assert semg.shape == (4, 10, 3)
    assert imu.shape == (4, 10, 6)
    assert metadata[0] == ("S1", "T1", 11)
    np.testing.assert_array_equal(target[0], trial.target[11])


def test_standardizer_fits_training_values_only() -> None:
    standardizer = Standardizer().fit([np.array([[0.0], [2.0]], dtype=np.float32)])
    transformed_test = standardizer.transform(np.array([[100.0]], dtype=np.float32))
    assert transformed_test.item() == 99.0

