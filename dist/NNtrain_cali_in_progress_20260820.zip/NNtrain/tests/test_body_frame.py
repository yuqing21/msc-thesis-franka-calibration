from __future__ import annotations

import numpy as np

from bishe_ai.data.body_frame import dynamic_body_coordinates, estimate_static_body_frame


def test_static_body_frame_maps_right_wrist_to_expected_axes() -> None:
    left = np.tile(np.array([[-0.2, 1.5, 0.0]]), (10, 1))
    right = np.tile(np.array([[0.2, 1.5, 0.0]]), (10, 1))
    torso = np.tile(np.array([[0.0, 1.0, 0.0]]), (10, 1))
    frame = estimate_static_body_frame(left, right, torso, arm="right")
    wrist = np.array([[0.3, 1.7, 0.4]])
    transformed = frame.transform_points(wrist)
    np.testing.assert_allclose(transformed, [[0.1, 0.2, 0.4]], atol=1e-6)


def test_body_frame_uses_selected_shoulder_as_origin() -> None:
    left = np.tile(np.array([[-0.2, 1.5, 0.0]]), (5, 1))
    right = np.tile(np.array([[0.2, 1.5, 0.0]]), (5, 1))
    torso = np.tile(np.array([[0.0, 1.0, 0.0]]), (5, 1))
    frame = estimate_static_body_frame(left, right, torso, arm="left")
    np.testing.assert_allclose(frame.transform_points(np.array([[-0.2, 1.5, 0.0]])), 0.0)


def test_dynamic_body_coordinates_follow_body_rotation_per_frame() -> None:
    left = np.array([[-1.0, 0.0, 0.0], [0.0, 0.0, 1.0]])
    right = np.array([[1.0, 0.0, 0.0], [0.0, 0.0, -1.0]])
    torso = np.array([[0.0, -1.0, 0.0], [0.0, -1.0, 0.0]])
    anatomical_right = (right - left) / np.linalg.norm(
        right - left, axis=1, keepdims=True
    )
    wrist = right + 0.5 * anatomical_right
    transformed = dynamic_body_coordinates(wrist, left, right, torso)
    np.testing.assert_allclose(transformed[:, 0], 0.5, atol=1e-7)
    np.testing.assert_allclose(transformed[:, 1:], 0.0, atol=1e-7)
