from __future__ import annotations

from pathlib import Path

import numpy as np
import pytest

from bishe_ai.data.ultra_mocap import (
    JOINT4_CHANNELS,
    JOINT8_CHANNELS,
    TARGET_MARKERS,
    _longest_contiguous_run,
    align_mot_coordinates,
    discover_trials,
    interpolate_marker_gaps,
    read_mot,
    read_trc,
)


def test_target_markers_include_dynamic_body_frame_landmarks() -> None:
    assert set(TARGET_MARKERS) == {"RRAD", "RULN", "LSHO", "RSHO", "STUR"}


def test_joint8_channels_cover_scapula_shoulder_elbow_and_pronation() -> None:
    assert JOINT8_CHANNELS == (
        "SC_y",
        "SC_x",
        "SC_z",
        "arm_flex_r",
        "arm_add_r",
        "arm_rot_r",
        "elbow_flex_r",
        "pro_sup_r",
    )


def _write_trc(path: Path) -> None:
    rows = [
        "PathFileType\t4\t(X/Y/Z)\ttest.trc",
        "DataRate\tCameraRate\tNumFrames\tNumMarkers\tUnits\tOrigDataRate\tOrigDataStartFrame\tOrigNumFrames",
        "100.0\t100.0\t3\t2\tmm\t100.0\t1\t3",
        "Frame#\tTime\tRRAD\t\t\tRULN\t\t",
        "\t\tX1\tY1\tZ1\tX2\tY2\tZ2",
        "1\t0.00\t100\t200\t300\t300\t400\t500",
        "2\t0.01\t110\t210\t310\t310\t410\t510",
        "3\t0.02\t120\t220\t320\t320\t420\t520",
    ]
    path.write_text("\n".join(rows) + "\n", encoding="utf-8")


def test_read_trc_selects_markers_and_converts_mm_to_metres(tmp_path: Path) -> None:
    path = tmp_path / "trial.trc"
    _write_trc(path)
    trc = read_trc(path, ("RRAD", "RULN"))
    assert trc.rate_hz == 100.0
    assert trc.units == "mm"
    np.testing.assert_allclose(trc.time_s, [0.0, 0.01, 0.02])
    np.testing.assert_allclose(trc.markers_m["RRAD"][0], [0.1, 0.2, 0.3])
    np.testing.assert_allclose(trc.markers_m["RULN"][-1], [0.32, 0.42, 0.52])


def test_read_trc_accepts_one_frame_header_discrepancy(tmp_path: Path) -> None:
    path = tmp_path / "trial.trc"
    _write_trc(path)
    text = path.read_text(encoding="utf-8").replace(
        "100.0\t100.0\t3\t2\tmm", "100.0\t100.0\t4\t2\tmm"
    )
    path.write_text(text, encoding="utf-8")
    trc = read_trc(path, ("RRAD", "RULN"))
    assert trc.declared_num_frames == 4
    assert len(trc.time_s) == 3


def _write_mot(path: Path) -> None:
    rows = [
        "Coordinates",
        "version=1",
        "nRows=3",
        "nColumns=5",
        "inDegrees=yes",
        "",
        "endheader",
        "time\tarm_flex_r\tarm_add_r\tarm_rot_r\telbow_flex_r",
        "0.00\t1\t2\t3\t4",
        "0.01\t5\t6\t7\t8",
        "0.02\t9\t10\t11\t12",
    ]
    path.write_text("\n".join(rows) + "\n", encoding="utf-8")


def test_read_and_align_opensim_joint_angles(tmp_path: Path) -> None:
    path = tmp_path / "trial.mot"
    _write_mot(path)
    mot = read_mot(path, JOINT4_CHANNELS)
    assert mot.in_degrees
    assert mot.declared_num_rows == 3
    aligned = align_mot_coordinates(mot, np.array([0.01, 0.02]), JOINT4_CHANNELS)
    np.testing.assert_allclose(aligned, [[5, 6, 7, 8], [9, 10, 11, 12]])


def test_read_mot_records_declared_row_discrepancy(tmp_path: Path) -> None:
    path = tmp_path / "trial.mot"
    _write_mot(path)
    path.write_text(
        path.read_text(encoding="utf-8").replace("nRows=3", "nRows=4"),
        encoding="utf-8",
    )
    mot = read_mot(path, JOINT4_CHANNELS)
    assert mot.declared_num_rows == 4
    assert mot.actual_num_rows == 3


def test_align_mot_rejects_nonmatching_vicon_time(tmp_path: Path) -> None:
    path = tmp_path / "trial.mot"
    _write_mot(path)
    mot = read_mot(path, JOINT4_CHANNELS)
    with pytest.raises(ValueError, match="not exactly aligned"):
        align_mot_coordinates(mot, np.array([0.015]), JOINT4_CHANNELS)


def test_interpolate_marker_gaps_rejects_long_gaps(tmp_path: Path) -> None:
    time_s = np.arange(6, dtype=np.float64) / 100.0
    values = np.column_stack((time_s, time_s + 1, time_s + 2))
    values[2:5] = np.nan
    with pytest.raises(ValueError, match="exceeds"):
        interpolate_marker_gaps(
            values,
            time_s,
            marker_name="RRAD",
            path=tmp_path / "trial.trc",
            maximum_gap_s=0.02,
        )


def test_discover_trials_matches_modalities_case_insensitively(tmp_path: Path) -> None:
    exercise = tmp_path / "P01" / "Arm Swing"
    for folder in ("EMG", "IMU", "Raw Marker"):
        (exercise / folder).mkdir(parents=True, exist_ok=True)
    (exercise / "Raw IK").mkdir()
    (exercise / "EMG" / "P01_ArmSwing_Fast.csv").touch()
    (exercise / "IMU" / "p01_armswing_fast.csv").touch()
    (exercise / "Raw Marker" / "P01_ARMSWING_FAST.trc").touch()
    (exercise / "Raw IK" / "p01_armswing_fast.mot").touch()
    (exercise / "EMG" / "P01_ArmSwing_Extra.csv").touch()
    (exercise / "IMU" / "P01_ArmSwing_Extra.csv").touch()

    trials, report = discover_trials(tmp_path)
    assert len(trials) == 1
    assert trials[0].subject == "P01"
    assert trials[0].trial_id == "P01_ARMSWING_FAST"
    assert trials[0].ik_path is not None
    assert trials[0].ik_path.name == "p01_armswing_fast.mot"
    assert report["sensor_only_trials"] == ["P01/Arm Swing/P01_ArmSwing_Extra.csv"]


def test_longest_contiguous_run_uses_the_largest_shared_segment() -> None:
    result = _longest_contiguous_run(np.array([1, 2, 5, 6, 7, 10]))
    np.testing.assert_array_equal(result, [5, 6, 7])
