from __future__ import annotations

import numpy as np

from bishe_ai.evaluation.metrics import regression_metrics


def test_regression_metrics_for_three_dimensions() -> None:
    target = np.array([[0, 0, 0], [1, 1, 1]], dtype=np.float32)
    prediction = target + 1
    metrics = regression_metrics(target, prediction)
    assert metrics["mae"] == 1.0
    assert metrics["rmse"] == 1.0
    assert metrics["r2_per_dim"] == [-3.0, -3.0, -3.0]
    assert np.isclose(metrics["euclidean_mean"], np.sqrt(3))


def test_constant_dimension_correlation_is_reported_as_none() -> None:
    target = np.zeros((4, 1), dtype=np.float32)
    prediction = np.arange(4, dtype=np.float32)[:, None]
    metrics = regression_metrics(target, prediction)
    assert metrics["pearson_per_dim"] == [None]
    assert metrics["r2_per_dim"] == [None]
