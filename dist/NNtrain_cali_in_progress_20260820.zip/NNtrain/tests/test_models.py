from __future__ import annotations

import pytest
import numpy as np
import torch

from bishe_ai.models import build_model
from bishe_ai.models.regressors import IMUCoarseEMGResidualRegressor, TemporalEncoder
from bishe_ai.data.datasets import MultimodalWindowDataset


def test_multimodal_dataset_returns_joint_fk_auxiliaries() -> None:
    dataset = MultimodalWindowDataset(
        np.zeros((2, 5, 3), dtype=np.float32),
        np.zeros((2, 5, 6), dtype=np.float32),
        np.zeros((2, 8), dtype=np.float32),
        xyz=np.zeros((2, 3), dtype=np.float32),
        subject_index=np.array([0, 1]),
    )
    item = dataset[1]
    assert set(item) == {"semg", "imu", "target", "xyz", "subject_index"}
    assert item["subject_index"].item() == 1


@pytest.mark.parametrize(
    "model_type",
    (
        "imu_only",
        "semg_only",
        "early_fusion",
        "dual_branch",
        "imu_guided_emg_gate",
        "attention_gated_axis_heads",
    ),
)
def test_model_forward_and_backward(model_type: str) -> None:
    model = build_model(
        {
            "type": model_type,
            "conv_channels": 8,
            "gru_hidden": 12,
            "feature_dim": 16,
            "dropout": 0.0,
        },
        semg_channels=3,
        imu_channels=12,
        output_dim=3,
    )
    batch = {
        "semg": torch.randn(4, 50, 3),
        "imu": torch.randn(4, 50, 12),
    }
    output = model(batch)
    assert output.shape == (4, 3)
    output.square().mean().backward()
    assert any(parameter.grad is not None for parameter in model.parameters())


def test_imu_guided_emg_gate_has_expected_shape_and_range() -> None:
    model = build_model(
        {"type": "imu_guided_emg_gate", "feature_dim": 16, "dropout": 0.0}, 3, 12, 3
    )
    prediction, gate = model.forward_with_gate(
        {"semg": torch.randn(4, 50, 3), "imu": torch.randn(4, 50, 12)}
    )
    assert prediction.shape == (4, 3)
    assert gate.shape == (4, 16)
    assert torch.all((gate >= 0) & (gate <= 1))


def test_imu_coarse_emg_residual_freezes_teacher_and_returns_components() -> None:
    teacher = build_model({"type": "imu_only", "feature_dim": 16, "dropout": 0.0}, 3, 12, 3)
    model = IMUCoarseEMGResidualRegressor(
        teacher,
        TemporalEncoder(3, 8, 12, 16, 0.0),
        feature_dim=16,
        output_dim=3,
        dropout=0.0,
    )
    model.train()
    batch = {"semg": torch.randn(4, 50, 3), "imu": torch.randn(4, 50, 12)}
    final, coarse, delta = model.forward_with_components(batch)
    assert final.shape == coarse.shape == delta.shape == (4, 3)
    final.square().mean().backward()
    assert all(parameter.grad is None for parameter in teacher.parameters())
    assert all(not parameter.requires_grad for parameter in teacher.parameters())
    assert any(parameter.grad is not None for parameter in model.semg_encoder.parameters())


def test_final_and_residual_huber_are_the_same_quantity() -> None:
    coarse = torch.randn(4, 3)
    delta = torch.randn(4, 3)
    target = torch.randn(4, 3)
    huber = torch.nn.HuberLoss()
    final_loss = huber(coarse + delta, target)
    residual_loss = huber(delta, target - coarse)
    assert torch.allclose(final_loss, residual_loss)


def test_early_fusion_rejects_unaligned_time_axes() -> None:
    model = build_model({"type": "early_fusion"}, 3, 6, 3)
    with pytest.raises(ValueError, match="equal batch and time"):
        model({"semg": torch.randn(2, 50, 3), "imu": torch.randn(2, 49, 6)})
