from __future__ import annotations

import numpy as np
import pytest

from bishe_ai.data.preprocessing import (
    find_quietest_window,
    normalize_semg_envelope_per_trial,
    preprocess_imu,
    preprocess_semg_envelope,
    remove_gyro_bias_per_trial,
)


def test_raw_semg_cannot_use_450_hz_band_at_100_hz_sampling() -> None:
    with pytest.raises(ValueError, match="Nyquist"):
        preprocess_semg_envelope(np.zeros((1000, 3)), sample_rate=100.0)


def test_semg_envelope_is_aligned_after_proper_filtering() -> None:
    sample_rate = 2000.0
    time = np.arange(4000) / sample_rate
    values = np.stack(
        (
            np.sin(2 * np.pi * 80 * time),
            np.sin(2 * np.pi * 120 * time),
            np.sin(2 * np.pi * 160 * time),
        ),
        axis=1,
    )
    result = preprocess_semg_envelope(values, sample_rate=sample_rate, target_rate=100.0)
    assert result.shape == (200, 3)
    assert np.isfinite(result).all()
    assert (result >= 0).all()


def test_imu_resampling_is_antialiased() -> None:
    rng = np.random.default_rng(2)
    result = preprocess_imu(rng.normal(size=(1000, 6)), sample_rate=500, target_rate=100)
    assert result.shape == (200, 6)


def test_find_quietest_window_locates_low_energy_region_not_at_start() -> None:
    rng = np.random.default_rng(3)
    energy_channels = rng.normal(scale=5.0, size=(300, 3))
    # A clearly quieter segment sits in the middle of the trial, not at the start.
    energy_channels[120:150] = rng.normal(scale=0.01, size=(30, 3))
    start, end = find_quietest_window(energy_channels, window_frames=20)
    assert 120 <= start <= 130
    assert end - start == 20


def test_find_quietest_window_clamps_to_trial_length() -> None:
    start, end = find_quietest_window(np.zeros((10, 2)), window_frames=50)
    assert (start, end) == (0, 10)


def test_remove_gyro_bias_per_trial_recovers_known_bias_and_spares_accel() -> None:
    rng = np.random.default_rng(4)
    frames = 200
    sensors = 6
    channels_per_sensor = 6
    imu = rng.normal(scale=2.0, size=(frames, sensors * channels_per_sensor))
    accel_before = imu.copy()
    known_bias = rng.normal(scale=3.0, size=(sensors * 3,))
    gyro_indices = [
        sensor * channels_per_sensor + axis
        for sensor in range(sensors)
        for axis in range(3, 6)
    ]
    # True motion signal (large away from rest), near-zero during the rest
    # segment [50, 90), plus a constant bias added throughout the trial.
    quiet = slice(50, 90)
    true_gyro_signal = imu[:, gyro_indices].copy()
    true_gyro_signal[quiet] = rng.normal(scale=0.01, size=(quiet.stop - quiet.start, sensors * 3))
    imu[:, gyro_indices] = true_gyro_signal + known_bias[None, :]
    accel_before = accel_before[:, [i for i in range(imu.shape[1]) if i not in gyro_indices]]

    corrected, report = remove_gyro_bias_per_trial(
        imu, sensors=sensors, channels_per_sensor=channels_per_sensor, sample_rate=100.0,
        quiet_window_ms=400.0,
    )

    recovered_bias = np.asarray(report["gyro_bias_per_channel_deg_s"])
    np.testing.assert_allclose(recovered_bias, known_bias, atol=0.1)
    accel_after = corrected[:, [i for i in range(imu.shape[1]) if i not in gyro_indices]]
    np.testing.assert_allclose(accel_after, accel_before, atol=1e-4)
    # The rest window's corrected gyro should now hover around zero.
    np.testing.assert_allclose(corrected[quiet][:, gyro_indices].mean(axis=0), 0.0, atol=0.05)


def test_remove_gyro_bias_per_trial_rejects_wrong_channel_count() -> None:
    with pytest.raises(ValueError, match="channels"):
        remove_gyro_bias_per_trial(np.zeros((10, 30)))


def test_normalize_semg_envelope_per_trial_centers_and_scales_robustly() -> None:
    rng = np.random.default_rng(5)
    envelope = rng.uniform(low=0.0, high=5.0, size=(500, 3)).astype(np.float64)
    normalized, report = normalize_semg_envelope_per_trial(envelope)
    assert normalized.shape == envelope.shape
    assert np.isfinite(normalized).all()
    # Per-channel median should sit near zero after robust centring.
    np.testing.assert_allclose(np.median(normalized, axis=0), 0.0, atol=1e-4)
    assert len(report["semg_log1p_ratio_median_per_channel"]) == 3


def test_normalize_semg_envelope_per_trial_rejects_negative_values() -> None:
    with pytest.raises(ValueError, match="non-negative"):
        normalize_semg_envelope_per_trial(np.array([[-1.0, 2.0]]))


def test_normalize_semg_envelope_per_trial_epsilon_floors_near_silent_channel() -> None:
    envelope = np.zeros((100, 1))
    normalized, report = normalize_semg_envelope_per_trial(envelope, mad_epsilon=1e-6)
    assert np.isfinite(normalized).all()
    assert report["semg_normalization_scale_per_channel"][0] == pytest.approx(1e-6)


def test_normalize_semg_envelope_per_trial_is_scale_invariant() -> None:
    # Real sEMG RMS envelopes sit around 1e-5-1e-4 V, where log1p(x) ~= x and does
    # no compression at all. Rescaling the same trial (e.g. volts vs millivolts,
    # or just a different gain) must not change the normalized output -- that is
    # what "log1p compression" is supposed to guarantee.
    rng = np.random.default_rng(6)
    envelope_volts = rng.uniform(low=0.0, high=5e-5, size=(400, 3)).astype(np.float64)
    envelope_volts[50:60] *= 12.0  # an occasional burst well above the trial's typical level
    normalized_volts, _ = normalize_semg_envelope_per_trial(envelope_volts)
    normalized_millivolts, _ = normalize_semg_envelope_per_trial(envelope_volts * 1000.0)
    np.testing.assert_allclose(normalized_volts, normalized_millivolts, atol=1e-4)


def test_normalize_semg_envelope_per_trial_compresses_bursts_relative_to_baseline() -> None:
    # A burst 10x above the trial's typical level should compress to log1p(10) in
    # log-ratio space, not pass through linearly as a raw 10x -- that is the whole
    # point of the log1p step. Check this directly on the pre-zscore log-ratio
    # (reconstructed from the report), since the final MAD-based z-score can
    # further rescale by an arbitrary factor depending on the baseline's own
    # variance and is not itself a measure of the compression.
    rng = np.random.default_rng(7)
    baseline = np.full((300, 1), 2e-5) + rng.normal(0.0, 1e-6, size=(300, 1))
    baseline = np.clip(baseline, 1e-7, None)
    baseline[100:110] = 2e-4  # 10x burst
    normalized, report = normalize_semg_envelope_per_trial(baseline)
    scale = np.asarray(report["semg_normalization_scale_per_channel"])
    median = np.asarray(report["semg_log1p_ratio_median_per_channel"])
    reference = np.asarray(report["semg_reference_median_per_channel"])
    log_ratio = normalized.astype(np.float64) * scale[None, :] + median[None, :]
    burst_log_ratio = float(log_ratio[100:110].mean())
    expected = float(np.log1p(2e-4 / reference[0]))
    assert burst_log_ratio == pytest.approx(expected, abs=0.05)
    assert burst_log_ratio < 3.0  # nowhere near an uncompressed 10x

