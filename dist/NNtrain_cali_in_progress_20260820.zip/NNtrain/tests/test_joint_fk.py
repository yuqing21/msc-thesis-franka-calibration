from pathlib import Path

import numpy as np

import torch

from bishe_ai.evaluation.joint_fk import SubjectArmKinematics, TorchJoint8FK, endpoint_metrics


def test_endpoint_metrics_uses_euclidean_centimetres() -> None:
    target = np.zeros((2, 3))
    prediction = np.array([[0.03, 0.04, 0.0], [0.0, 0.0, 0.0]])
    metrics = endpoint_metrics(target, prediction)
    assert metrics["mean_euclidean_cm"] == 2.5
    assert np.isclose(metrics["rmse_euclidean_cm"], np.sqrt(12.5))
    assert metrics["samples"] == 2


def test_subject_fk_is_finite_and_has_plausible_arm_length() -> None:
    model = Path("data/raw/ultra_mocap/ULTRA-MoCap/P12/subject_12.osim")
    if not model.is_file():
        return
    fk = SubjectArmKinematics.from_osim(model)
    xyz = fk.wrist_xyz(np.zeros((1, 4)))
    assert xyz.shape == (1, 3)
    assert np.isfinite(xyz).all()
    assert 0.3 < np.linalg.norm(xyz[0]) < 0.8


def test_joint8_fk_is_differentiable() -> None:
    model = Path("data/raw/ultra_mocap/ULTRA-MoCap/P12/subject_12.osim")
    if not model.is_file():
        return
    parsed = SubjectArmKinematics.from_osim(model)
    fields = TorchJoint8FK.vector_fields
    parameters = {
        f"fk_{field}": np.asarray([getattr(parsed, field)], dtype=np.float32)
        for field in fields
    }
    parameters["fk_shoulder_axes"] = np.asarray([parsed.shoulder_axes], dtype=np.float32)
    parameters["fk_right_sc_axes"] = np.asarray([parsed.right_sc_axes], dtype=np.float32)
    fk = TorchJoint8FK(parameters)
    angles = torch.zeros((2, 8), requires_grad=True)
    xyz = fk(angles, torch.zeros(2, dtype=torch.long))
    assert xyz.shape == (2, 3)
    xyz.square().mean().backward()
    assert angles.grad is not None
    assert torch.isfinite(angles.grad).all()
    assert torch.count_nonzero(angles.grad).item() > 0
