from __future__ import annotations

import importlib.util
from pathlib import Path

import numpy as np


SCRIPT = (
    Path(__file__).resolve().parents[1]
    / "BaselineTest_Mocap"
    / "diagnostics"
    / "analyze_baseline.py"
)
SPEC = importlib.util.spec_from_file_location("baseline_diagnostics", SCRIPT)
assert SPEC is not None and SPEC.loader is not None
diagnostics = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(diagnostics)

LATE_FUSION_SCRIPT = SCRIPT.with_name("evaluate_late_fusion.py")
LATE_FUSION_SPEC = importlib.util.spec_from_file_location(
    "baseline_late_fusion", LATE_FUSION_SCRIPT
)
assert LATE_FUSION_SPEC is not None and LATE_FUSION_SPEC.loader is not None
late_fusion = importlib.util.module_from_spec(LATE_FUSION_SPEC)
LATE_FUSION_SPEC.loader.exec_module(late_fusion)

BODY_FRAME_SCRIPT = SCRIPT.with_name("check_dynamic_body_frame.py")
BODY_FRAME_SPEC = importlib.util.spec_from_file_location(
    "baseline_dynamic_body_frame", BODY_FRAME_SCRIPT
)
assert BODY_FRAME_SPEC is not None and BODY_FRAME_SPEC.loader is not None
dynamic_frame = importlib.util.module_from_spec(BODY_FRAME_SPEC)
BODY_FRAME_SPEC.loader.exec_module(dynamic_frame)


def test_best_lag_positive_means_prediction_trails_target() -> None:
    time = np.linspace(0, 8 * np.pi, 200)
    target = np.column_stack((np.sin(time), np.cos(time), np.sin(0.5 * time)))
    prediction = np.empty_like(target)
    prediction[:2] = target[0]
    prediction[2:] = target[:-2]
    lags, correlations = diagnostics.best_lag_windows(target, prediction, max_lag=4)
    assert lags == [2, 2, 2]
    assert all(value is not None and value > 0.99 for value in correlations)


def test_summary_row_exposes_removable_constant_bias() -> None:
    rng = np.random.default_rng(42)
    target = rng.normal(size=(100, 3))
    bias = np.array([0.2, -0.1, 0.3])
    prediction = target + bias
    row = diagnostics._summary_row("trial", target, prediction)
    np.testing.assert_allclose(
        [row["bias_x_m"], row["bias_y_m"], row["bias_z_m"]], bias
    )
    assert row["centered_rmse_m"] < 1e-12


def test_late_fusion_selects_better_modality() -> None:
    rng = np.random.default_rng(7)
    target = rng.normal(size=(80, 3))
    semg_prediction = target + 0.5
    imu_prediction = target + 0.05
    weight, _ = late_fusion.select_imu_weight(
        target, semg_prediction, imu_prediction
    )
    assert weight == 1.0


def test_dynamic_body_coordinates_tracks_rotated_subject() -> None:
    left = np.array([[-1.0, 0.0, 0.0], [0.0, 0.0, 1.0]])
    right = np.array([[1.0, 0.0, 0.0], [0.0, 0.0, -1.0]])
    sternum = np.array([[0.0, -1.0, 0.0], [0.0, -1.0, 0.0]])
    # In both frames the wrist is 0.5 m farther along the anatomical right axis.
    wrist = right + 0.5 * (right - left) / np.linalg.norm(
        right - left, axis=1, keepdims=True
    )
    result = dynamic_frame.dynamic_body_coordinates(wrist, left, right, sternum)
    np.testing.assert_allclose(result[:, 0], 0.5, atol=1e-7)
    np.testing.assert_allclose(result[:, 1:], 0.0, atol=1e-7)
