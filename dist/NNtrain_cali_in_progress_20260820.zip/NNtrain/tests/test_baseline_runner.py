from __future__ import annotations

import importlib.util
import json
from pathlib import Path

import numpy as np
import pytest


RUNNER_PATH = (
    Path(__file__).resolve().parents[1] / "BaselineTest_Mocap" / "run_baseline.py"
)
SPEC = importlib.util.spec_from_file_location("baseline_runner", RUNNER_PATH)
assert SPEC is not None and SPEC.loader is not None
baseline_runner = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(baseline_runner)


def _write_dataset(path: Path, *, split_override: dict[str, list[str]] | None = None) -> None:
    rng = np.random.default_rng(42)
    arrays: dict[str, np.ndarray] = {}
    for split, samples in (("train", 8), ("val", 4), ("test", 4)):
        arrays[f"semg_{split}"] = rng.normal(size=(samples, 50, 3)).astype(np.float32)
        arrays[f"imu_{split}"] = rng.normal(size=(samples, 50, 36)).astype(np.float32)
        arrays[f"target_{split}"] = rng.normal(size=(samples, 3)).astype(np.float32)
    subjects = split_override or baseline_runner.EXPECTED_SUBJECT_SPLITS
    arrays["metadata_json"] = np.asarray(
        json.dumps(
            {
                "dataset_version": "dynamic_body_frame_v2",
                "subject_splits": subjects,
                "target_definition": {"body_frame_mode": "per_frame_dynamic"},
            }
        ),
        dtype=np.str_,
    )
    np.savez_compressed(path, **arrays)


def test_validate_prepared_dataset_accepts_baseline_contract(tmp_path: Path) -> None:
    path = tmp_path / "ultra.npz"
    _write_dataset(path)
    summary = baseline_runner.validate_prepared_dataset(
        path,
        window_steps=50,
        semg_channels=3,
        imu_channels=36,
        output_dim=3,
    )
    assert summary["splits"]["train"]["samples"] == 8
    assert summary["subject_splits"]["test"] == ["P12", "P13"]


def test_validate_prepared_dataset_rejects_subject_leakage(tmp_path: Path) -> None:
    path = tmp_path / "leaked.npz"
    bad_split = {
        "train": ["P01", "P02", "P03", "P04", "P05", "P06", "P07", "P08", "P12"],
        "val": ["P10", "P11"],
        "test": ["P09", "P13"],
    }
    _write_dataset(path, split_override=bad_split)
    with pytest.raises(ValueError, match="受试者划分不符合"):
        baseline_runner.validate_prepared_dataset(
            path,
            window_steps=50,
            semg_channels=3,
            imu_channels=36,
            output_dim=3,
        )


def test_validate_prepared_dataset_rejects_wrong_imu_shape(tmp_path: Path) -> None:
    path = tmp_path / "wrong_imu.npz"
    _write_dataset(path)
    with np.load(path, allow_pickle=False) as source:
        arrays = {name: source[name] for name in source.files}
    arrays["imu_test"] = arrays["imu_test"][:, :, :18]
    np.savez_compressed(path, **arrays)

    with pytest.raises(ValueError, match="test/IMU"):
        baseline_runner.validate_prepared_dataset(
            path,
            window_steps=50,
            semg_channels=3,
            imu_channels=36,
            output_dim=3,
        )


def test_validate_prepared_dataset_rejects_static_axis_v1(tmp_path: Path) -> None:
    path = tmp_path / "static_v1.npz"
    _write_dataset(path)
    with np.load(path, allow_pickle=False) as source:
        arrays = {name: source[name] for name in source.files}
    arrays["metadata_json"] = np.asarray(
        json.dumps(
            {
                "dataset_version": "static_axis_v1",
                "subject_splits": baseline_runner.EXPECTED_SUBJECT_SPLITS,
                "target_definition": {"body_frame_mode": "static"},
            }
        ),
        dtype=np.str_,
    )
    np.savez_compressed(path, **arrays)
    with pytest.raises(ValueError, match="动态身体坐标v2"):
        baseline_runner.validate_prepared_dataset(
            path,
            window_steps=50,
            semg_channels=3,
            imu_channels=36,
            output_dim=3,
        )


def test_output_root_must_stay_in_baseline_folder() -> None:
    accepted = {
        "run": {"output_root": "BaselineTest_Mocap/outputs/formal"}
    }
    assert baseline_runner._validate_output_root(accepted).is_relative_to(
        baseline_runner.BASELINE_ROOT
    )

    rejected = {"run": {"output_root": "outputs/baseline_ultra_mocap"}}
    with pytest.raises(ValueError, match="BaselineTest_Mocap/outputs"):
        baseline_runner._validate_output_root(rejected)
