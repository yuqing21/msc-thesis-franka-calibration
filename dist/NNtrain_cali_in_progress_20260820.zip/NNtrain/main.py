from pathlib import Path


if __name__ == "__main__":
    guide = Path(__file__).resolve().parent / "START_HERE.md"
    print("Self-recorded sEMG-IMU project. Start with:")
    print(guide)
    print("Confirm hardware models and time synchronization before recording.")
