# sEMG–IMU 上肢姿态估计工程

> 项目状态：**进行中**。本仓库内容仍在持续整合、验证与完善中。

`NNtrain` 的最终目标是在自采数据上，用六路 sEMG 与 IMU 预测上肢关节角，并将
深度相机估计的关节角作为训练标签。公开 ULTRA-MoCap 数据仅用于验证网络结构、
模态融合和跨受试者泛化假设——它不是最终数据集，其指标不能直接写成自采系统的
最终精度。

## 工程边界

| 位置 | 作用 |
|---|---|
| `src/bishe_ai/` | 可复用模型、训练、评估、窗口和数据处理实现；最终服务自采数据。 |
| `scripts/` | 自采数据采集目录创建、校验、准备与通用训练入口。 |
| `configs/self_recorded_xyz.yaml` | 自采数据训练配置模板。 |
| `BaselineTest_Mocap/` | ULTRA-MoCap 公开数据验证场；不代表最终自采实验。 |
| `tests/` | 数据、模型、指标和训练逻辑测试。 |
| `docs/` | 网络与数据集选型对照、手动训练指南等详细参考资料。 |

## 两条工作流

1. **自采主线**：按照 `scripts/create_recording_trial.py`、
   `scripts/validate_recording.py` 和 `scripts/prepare_self_recorded.py` 准备数据，
   再使用 `src/bishe_ai/` 的通用能力训练。入口文件：

   ```text
   scripts/create_recording_trial.py       创建一次采集 trial 的目录结构
   scripts/validate_recording.py           校验时间同步与数据完整性
   scripts/prepare_self_recorded.py        生成训练窗口
   configs/self_recorded_xyz.yaml          自采数据训练配置模板
   src/bishe_ai/data/self_recorded.py      自采数据处理实现
   ```

2. **ULTRA-MoCap 验证**：在 `BaselineTest_Mocap/` 中运行受试者独立实验，验证
   IMU、sEMG 和融合结构的有效性。用于：验证 CNN-GRU、单模态与多模态融合实现；
   用受试者独立划分检查跨人泛化；判断现有传感器覆盖在目标关节角预测中的信息
   上限；在录制自采数据前排查数据泄漏、标准化和评价流程问题。其结果只能作为
   方法验证和论文背景证据。

完整自采方案见
[`BaselineTest_Mocap/SELF_RECORDED_DEPTH_GT_METHOD_ZH.md`](BaselineTest_Mocap/SELF_RECORDED_DEPTH_GT_METHOD_ZH.md)，
当前公开数据实验状态见
[`BaselineTest_Mocap/CURRENT_STATUS_ZH.md`](BaselineTest_Mocap/CURRENT_STATUS_ZH.md)。

## 数据与实验原则

- 原始公开数据与下载包保持不可变；处理后的公开数据存于 `BaselineTest_Mocap/data/`。
- 所有公开数据实验必须受试者独立；每一 fold 的标准化器只能由其训练受试者拟合。
- 自采数据与公开数据的结果必须分开报告；不能将公开数据精度直接描述为自采系统精度。
- 模型选择、early stopping 和超参数选择只使用验证集，不能使用测试集。

详细的数据约定见 `docs/`。

## 开始前检查 / 每次修改训练逻辑前

```powershell
Set-Location F:\bishe_ai_project\NNtrain
.\.venv\Scripts\python.exe scripts\check_cuda.py
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe scripts\train.py --config configs\synthetic_smoke.yaml
```

唯一解释器：

```text
F:\bishe_ai_project\NNtrain\.venv\Scripts\python.exe
```
