﻿<#
NNtrain 文件夹整理脚本
======================
只做"删除/清理"这一半——文档合并（README.md 已经改好、AGENTS.md 已经同步引用）
是直接写好覆盖的，不需要脚本处理。

这个脚本只删除以下几类，全部有据可查、不影响任何当前结果或正在跑的实验：

1. __pycache__ / .cache —— 纯 Python 构建缓存，删了会自动重新生成，零风险。
2. outputs/、BaselineTest_Mocap/outputs/smoke —— 每次跑 synthetic_smoke.yaml
   烟雾测试留下的历史副本，文件名里明确写着 "not_an_experiment"，只保留最新
   一份用于确认"跑得通"，其余按时间戳重复的旧副本删除。
3. BaselineTest_Mocap/outputs/loso_abcd_fast_p13/D_imu_guided_emg_gate —— 这是
   CURRENT_STATUS_ZH.md 里明确写了"已废弃，不纳入新的A/B/C/D定义"的旧模型结果，
   同目录下的 A/B/C 仍在被复用，不受影响，只删 D 这一个子目录。
4. START_HERE.md、PROJECT_CONTEXT.md —— 内容已经合并进新版 README.md（脚本运行
   前请确认 README.md 和 AGENTS.md 已经是新版本，也就是先让 Claude 把这两个文件
   写好之后再跑本脚本）。

不会碰：.venv、.git、.idea、.local_keys、data/、BaselineTest_Mocap/data/、
BaselineTest_Mocap/fixed_results/（明确禁止覆盖）、outputs/formal、
outputs/experiments、outputs/loso_abcd、outputs/loso_abcd_imu_magnitude、
outputs/diagnostics（未核实，本次不动）、任何 src/scripts/tests/configs/docs 代码。

用法：
  Set-Location F:\bishe_ai_project\NNtrain
  .\cleanup_NNtrain.ps1            # 先看一遍会删什么（默认 dry-run，不会真的删）
  .\cleanup_NNtrain.ps1 -Confirm   # 确认无误后加这个参数真正执行删除
#>

param(
    [switch]$Confirm
)

$ErrorActionPreference = "Stop"
$root = Get-Location

function Remove-IfExists {
    param([string]$Path, [string]$Reason)
    if (Test-Path $Path) {
        if ($Confirm) {
            Remove-Item -LiteralPath $Path -Recurse -Force
            Write-Host "[已删除] $Path  ($Reason)" -ForegroundColor Yellow
        } else {
            Write-Host "[将删除] $Path  ($Reason)" -ForegroundColor Cyan
        }
    }
}

Write-Host "=== 当前目录: $root ===" -ForegroundColor Green
if (-not $Confirm) {
    Write-Host "当前是预览模式（dry-run），不会真的删除任何文件。确认无误后加 -Confirm 参数重新运行。" -ForegroundColor Green
}

# 1. Python 构建/测试缓存 -----------------------------------------------
Get-ChildItem -Path . -Directory -Recurse -Force -Filter "__pycache__" -ErrorAction SilentlyContinue |
    Where-Object { $_.FullName -notmatch '\\\.venv\\' } |
    ForEach-Object { Remove-IfExists -Path $_.FullName -Reason "Python 构建缓存" }

Remove-IfExists -Path ".\.cache" -Reason "pytest 缓存目录（pyproject.toml 里定义为 .cache/pytest）"

# 2. 顶层 outputs/ 下的历史 smoke 副本，只保留最新一份 -------------------
$topSmokeDir = ".\outputs\baseline_ultra_mocap_smoke"
if (Test-Path $topSmokeDir) {
    $keepStamp = "20260819_110108"
    Get-ChildItem -Path $topSmokeDir -Recurse -File |
        Where-Object { $_.Name -notmatch [regex]::Escape($keepStamp) } |
        ForEach-Object { Remove-IfExists -Path $_.FullName -Reason "旧版 smoke 测试副本，只留 $keepStamp" }
}

# 3. BaselineTest_Mocap/outputs/smoke 下的历史副本，只保留最新一份 -------
$btmSmokeDir = ".\BaselineTest_Mocap\outputs\smoke"
if (Test-Path $btmSmokeDir) {
    $keepStamp = "20260819_110108"
    Get-ChildItem -Path $btmSmokeDir -Recurse -File |
        Where-Object { $_.Name -notmatch [regex]::Escape($keepStamp) } |
        ForEach-Object { Remove-IfExists -Path $_.FullName -Reason "旧版 smoke 测试副本，只留 $keepStamp" }
}

# 4. 已废弃的旧 D 模型（CURRENT_STATUS_ZH.md 明确标注废弃，A/B/C 不受影响）
Remove-IfExists -Path ".\BaselineTest_Mocap\outputs\loso_abcd_fast_p13\D_imu_guided_emg_gate" `
    -Reason "旧 D_imu_guided_emg_gate 已被 CURRENT_STATUS_ZH.md 标注废弃，不再纳入 A/B/C/D 定义"

# 5. 已合并进 README.md 的旧文档 ------------------------------------------
Remove-IfExists -Path ".\START_HERE.md" -Reason "内容已合并进 README.md"
Remove-IfExists -Path ".\PROJECT_CONTEXT.md" -Reason "内容已合并进 README.md"

Write-Host ""
if (-not $Confirm) {
    Write-Host "以上是预览结果。确认没问题后运行：.\cleanup_NNtrain.ps1 -Confirm" -ForegroundColor Green
} else {
    Write-Host "清理完成。" -ForegroundColor Green
}
